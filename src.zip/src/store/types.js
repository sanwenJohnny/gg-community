import tools from '@/utils'

export default tools.setKeyToValue({
  SET_USERINFO: 'set_userinfo',
  SET_CHOOSEAREA: 'set_chooseArea',
  SET_CARTNUMBER: 'set_cartnumber'
})
