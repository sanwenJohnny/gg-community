export default {
    SET_PAGE_DATA: 'setPageData',
    SET_PARAMS: 'setParams',
    SET_INITED: 'setInited'
}