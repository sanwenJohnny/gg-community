export default {
    pageData: {},
    params: {},
    inited: false
}