import utils from "@/utils"
import types from './types'
import request from '@/service/request'
import api from "@/static/api/common";
const factory = utils.actionRequestFactory
export default {
  //发送验证码
  getValidateCodeAction: factory(api.sendValidateCode),
  //微信授权绑定手机号
  bindMobileByWeChatAction: factory(api.bindMobileByWeChat),
  //通过验证码绑定手机号
  bindMobileByValidateCodeAction: factory(api.bindMobileByValidateCode),
  //个人中心
  homePageInfoAction ({commit}, opts = {}) {
    const { data, showLoading } = opts
    request.post({ url: api.homePageInfo, data, showLoading }).then(res => {
      commit(types.SET_USERINFO, { data: res })
    })
  },
  // 选择地址 对首页操作
  setChooseAreaAction ({commit}, br ){
    commit(types.SET_CHOOSEAREA, br)
  },

  //设置购物车数量
  setCartNumberAction ({commit}, data){
    commit(types.SET_CARTNUMBER, {data})
  },
}
