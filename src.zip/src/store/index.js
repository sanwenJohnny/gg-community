import Vue from 'vue'
import Vuex from 'vuex'
import state from './state'
import getters from './getters'
import actions from './actions'
import mutations from './mutations'
import modAddress from './modules/address'
import modShoppingCart from './modules/shoppingCart'
import modOrderDetail from './modules/order/detail'
import modOrderSubmit from './modules/order/submit'
import modMyOrder from './modules/order/my'
import modOrderRefund from './modules/order/refund'
import modLogistics from './modules/logistics'
import modIndex from './modules/index'
import modProduct from './modules/product'
import modHouse from './modules/house'

Vue.use(Vuex)

const option = {
  state,
  getters,
  actions,
  mutations,
  modules: {
    modAddress,
    modShoppingCart,
    modOrderDetail,
    modOrderSubmit,
    modMyOrder,
    modOrderRefund,
    modLogistics,
    modIndex,
    modProduct,
    modHouse
  },
}
export default new Vuex.Store(option)
