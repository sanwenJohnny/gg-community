import utils from "@/utils"
import types from './types'
import request from '@/service/request'
import api from "@/static/api/house";
const factory = utils.actionRequestFactory

export default {
    // 获取小区长管理首页数据
    getHouseManageDataAction: factory(api.houseManageData),

    // 获取经营数据中心数据
    getBusinessCenterDataAction: factory(api.businessCenterData),

    // 获取单个交易售后详情
    getAfterDetailInfoAction: factory(api.afterDetail),

    // 获取交易记录列表
    getTradeRecordListAction: factory(api.tradeRecordList),

    // 获取单个交易记录详情
    getTradeDetailListAction: factory(api.tradeDetail),

    // 申请催促
    getAfterDetailPrompt: factory(api.afterDetailPrompt),

    // 选择交易记录列表类型
    setTradeRecordTypeAction ({commit}, data) {
        commit(types.SET_TRADERECORDTYPE, {data: data})
    },

    // 获取商品销量中心列表
    getSalesCenterListAction: factory(api.salesCenterList),

    // 选择商品销量中心列表类型
    setSalesCenterTypeAction ({commit}, data) {
        commit(types.SET_SALESCENTERTYPE, {data: data})
    },

    // 获取售后信息列表
    getAfterSalesListAction: factory(api.afterSalesList),

    // 选择售后信息列表类型
    setAfterSalesTypeAction ({commit}, data) {
        commit(types.SET_AFTERSALESTYPE, {data: data})
    },

}
