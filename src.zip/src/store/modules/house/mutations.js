import types from './types'

export default {
    [types.SET_TRADERECORDTYPE] (state, payload) {
        state.sTradeRecordType = payload.data.status
    },
    [types.SET_SALESCENTERTYPE] (state, payload) {
        state.sSalesCenterType = payload.data.type
    },
    [types.SET_AFTERSALESTYPE] (state, payload) {
        state.sAfterSalesType = payload.data.type
    },
}
