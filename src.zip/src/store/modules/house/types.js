import tools from '@/utils'

export default tools.setKeyToValue({
    SET_TRADERECORDTYPE: 'set_tradeRecordType',
    SET_SALESCENTERTYPE: 'set_salesCenterType',
    SET_AFTERSALESTYPE:'set_sAfterSalesType'
})
