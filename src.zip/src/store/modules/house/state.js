export default {
    sTradeRecordType:0,  // 交易记录类型 0 全部 1 待结算 2 已结算 3 已取消
    sSalesCenterType:1,  // 商品销售中心类型 1 昨日 2 近7日 3 近30日 
    sAfterSalesType:0,   // 售后列表类型 0 全部 1 申请中 2 退款成功 3 拒绝退款 
}
