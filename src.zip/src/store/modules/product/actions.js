import utils from "@/utils"
import api from "@/static/api/product";
const factory = utils.actionRequestFactory
// const http = "https://120.55.20.45/"

export default {
    getDetailAction: factory(api.detail),
    getShareQrcodeAction: factory(api.shareQrcode),
    getAddCartAction: factory(api.addCart),
    getCartCountAction: factory(api.cartCount),
    oderConfirmAction: factory(api.orderConfirm)
}
