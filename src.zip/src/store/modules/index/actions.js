import utils from "@/utils"
import api from "@/static/api/index";
const factory = utils.actionRequestFactory
// const http = "https://120.55.20.45/"

export default {
    getHomepageLocationAction: factory(api.getHomepageLocation),
    getHomeInfoAction: factory(api.getHomeInfo),
    getHomeNormalAction: factory(api.getHomeNormal)
}
