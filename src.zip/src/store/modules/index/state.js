export default {
    sApi: {
        list: 'cart/list',
        count: 'cart/count',
        delete: 'cart/delete',
        edit: 'cart/edit'
    }
}
