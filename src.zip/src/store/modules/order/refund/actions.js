import utils from "@/utils"
import api from "@/static/api/order/refund";
const factory = utils.actionRequestFactory
// const http = "https://120.55.20.45/"

export default {
    refundApplyAction: factory(api.applyRefund),
    editListAction: factory(api.editList),
    getApplyInfoAcion: factory(api.getApplyInfo),
    refundListAction: factory(api.refundList),
    refundDetailAction: factory(api.refundDetail),
    refundCancelAction: factory(api.refundCancel)
}

