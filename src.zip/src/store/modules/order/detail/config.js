import api from "a/order/detail"
export default {
    api
}