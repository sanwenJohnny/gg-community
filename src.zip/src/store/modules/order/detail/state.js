import commonState from 'sm/state'
const api = require('./config').default.api
Object.assign(commonState, {
    params: {
        [api.data]: {
            orderId: 3466
        }
    }
})
export default {
    ...commonState
}
