import commonTypes from 'sm/types'

export default {
    ...commonTypes,
    SET_CURRSTATUS: 'setCurrStatus',
    SET_ORDERLIST: "setOrderList",
    SET_PAGENUM: 'setPageNum',
    SET_HASMORE: 'setHasMore',
    SET_TOTAL: 'setTotal'
}