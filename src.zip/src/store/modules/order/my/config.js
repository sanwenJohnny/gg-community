import api from "a/order/my"
export default {
    api
}