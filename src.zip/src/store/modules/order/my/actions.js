const api = require('./config').default.api
const commonActions = require('f/commonActionFactory').default(api)
const createRequest = require('f/requestActionFactory').default
import types from './types'
export default {
    ...commonActions,
    // 付款
    payAction: createRequest(api, 'pay'),
    // 确认订单
    sureAction: createRequest(api, 'sure'),
    // 取消订单
    cancelAction: createRequest(api, 'cancel'),
    setCurrStatusAction(context, index) {
        context.commit(types.SET_CURRSTATUS, index)
    },
    setOrderListAction(context, list) {
        context.commit(types.SET_ORDERLIST, list)
    },
    setPageNumAction(context, num) {
        context.commit(types.SET_PAGENUM, num)
    },
    setHasMoreAction(context, has) {
        context.commit(types.SET_HASMORE, has)
    },
    setTotalAction(context, total) {
        context.commit(types.SET_TOTAL, total)
    }
}



