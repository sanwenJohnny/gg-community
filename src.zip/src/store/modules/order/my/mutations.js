const api = require('./config').default.api
import types from './types'
const commonMutations = require('f/commonMutationFactory').default(api)
export default {
    ...commonMutations,
    [types.SET_CURRSTATUS](state, index) {
        state.currStatus = index
    },
    [types.SET_PAGENUM](state, num) {
        state.pageNum = num
    },
    [types.SET_ORDERLIST](state, list) {
        let l = [...state.pageData.list, ...list]
        state.pageData.list = l
    },
    [types.SET_PAGENUM] (state, num) {
        state.pageNum = num
    },
    [types.SET_HASMORE](state, has) {
        state.hasMore = has
    },
    [types.SET_TOTAL](state, total) {
        state.total = total
    }
}
