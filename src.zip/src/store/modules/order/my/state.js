import commonState from 'sm/state'
const api = require('./config').default.api
Object.assign(commonState, {
    params: {
        [api.data]: {
            status: 0,
            pageSize: 5,
            page: 1
        },
        [api.pay]: {
            batchNumbers: ['3346'],
            payChannel: 3
        },
        [api.cancel]: {
            batchNumber: 5
        },
        [api.sure]: {
            orderId: 5
        }
    }
})
export default {
    ...commonState,
    currStatus: 0,
    pageNum: 1,
    hasMore: true,
    total: 1
}
