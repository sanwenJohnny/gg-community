const api = require('./config').default.api
const commonMutations = require('f/commonMutationFactory').default(api)

import types from './types'
export default {
    ...commonMutations,
    [types.SET_SKUCOUNTLIST](state, payload) {
        state.skuCountList = payload
    },
    [types.SET_ADDRESSTYPE](state, payload) {
        state.pageData.defaultSelectAgent = payload
    },
    [types.SET_USECOIN](state, isUserCoin) {
        state.useCoin = isUserCoin
    },
    [types.SET_LOCKUSECOIN](state, lock) {
        state.lockUseCoin = lock
    },
    [types.RESET_BUYERINFO](state, info) {
        state.buyerInfo = info
    },
}
