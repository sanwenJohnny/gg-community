import commonTypes from 'sm/types'

export default {
    ...commonTypes,
    SET_SKUCOUNTLIST: 'setSkuCountList',
    SET_ADDRESSTYPE: 'setAddressType',
    SET_USECOIN: 'setUseCoin',
    SET_LOCKUSECOIN: 'setLockUseCoin',
    RESET_BUYERINFO: 'resetBuyerInfo'
}