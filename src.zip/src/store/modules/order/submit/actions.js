const api = require('./config').default.api
const commonActions = require('f/commonActionFactory').default(api)
const createRequest = require('f/requestActionFactory').default

import types from './types'
export default {
    ...commonActions,
    addAction: createRequest(api, 'add'),
    setSkuCountListAction(context, list) {
        context.commit(types.SET_SKUCOUNTLIST, list)
    },
    setAddressTypeAction(context, type) {
        context.commit(types.SET_ADDRESSTYPE, type)
    },
    setUseCoinAction(context, isUserCoin) {
        context.commit(types.SET_USECOIN, isUserCoin)

    },
    setLockUseCoinAction(context, lock) {
        context.commit(types.SET_LOCKUSECOIN, lock)
    },
    resetBuyerInfoAction(context, info) {
        context.commit(types.RESET_BUYERINFO, info)
    }
}
