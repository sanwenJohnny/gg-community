import api from "a/order/submit"
export default {
    api
}