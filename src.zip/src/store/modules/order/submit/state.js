import commonState from 'sm/state'
const api = require('./config').default.api
Object.assign(commonState, {
    params: {
        [api.data]: {
            cityCode: '330100',
            skuCountList: [
                {
                    productId: 315,
                    count: 1
                }
            ]
        },
        [api.add]: {
            "confirmIdList": [
                3483
            ],
            "payChannel": 3,
            "cityCode": "330100",
            "useCoin": 0,
            "coinAmount": 100,
            "orderAddress": {
                "addressId": 122,
                "addressType": 1,
                "fullName": "马化腾",
                "mobileNumber": "15088605055"
            }
        }
    }
})
export default {
    ...commonState,
    skuCountList: [], //data接口参数，由购物车页面传入，防止地址页面返回时丢失
    buyerInfo: {
        name: '',
        phone: '',
        note: ''
    },
    useCoin: undefined, //是否使用捕手币
    lockUseCoin: false, //锁定捕手币当前使用状态
}
