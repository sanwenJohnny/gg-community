const api = require('./config').default.api
const commonActions = require('f/commonActionFactory').default(api)
export default {
    ...commonActions
}
