import commonState from 'sm/state'
const api = require('./config').default.api
Object.assign(commonState, {
    params: {
        [api.data]: {
            shipmentCode: '1234567890'
        }
    }
})
export default {
    ...commonState
}
