const api = require('./config').default.api
const commonMutations = require('f/commonMutationFactory').default(api)
export default {
    ...commonMutations
}
