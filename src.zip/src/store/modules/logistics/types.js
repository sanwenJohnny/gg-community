import commonTypes from 'sm/types'

export default {
    ...commonTypes
}