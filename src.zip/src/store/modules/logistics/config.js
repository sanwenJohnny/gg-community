import api from "a/order/logistics"
export default {
    api
}