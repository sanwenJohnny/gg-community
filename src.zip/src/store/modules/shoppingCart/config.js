import api from "a/shoppingCart"
export default {
    api
}