const api = require('./config').default.api
const commonActions = require('f/commonActionFactory').default(api)
const createRequest = require('f/requestActionFactory').default
import types from './types'
import request from 'r'
import utils from 'u'
import db from 'ss'
export default {
    ...commonActions,
    // 更新数量
    updateAction: createRequest(api, 'edit'),
    //删除
    deleteAction: createRequest(api, 'delete'),
    // 更新本地数量
    updateCountAction({ commit }, data) {
        commit(types.UPDATE_COUNT, data)
    },
    //全选
    chooseAllAction({ commit }, bool) {
        commit(types.CHOOSE_ALL, bool)
    },
    // 添加选中的商品
    addChooseItemAction({ commit }, skuId) {
        commit(types.ADD_CHOOSEITEM, skuId)
    },
    // 删除选中的商品
    deleteChooseItemAction({ commit }, skuId) {
        commit(types.DELETE_CHOOSEITEM, skuId)
    },
    setChoosesAction({ commit }, chooses) {
        commit(types.SET_CHOOSES, chooses)
    },
    // 订单提交
    orderConfirmAction({},list) {
        const dbData = utils.get(db.COMMUNITY_INFO) || {}
        const params = {
            ...dbData,
            skuCountList: list
        }
        const url = require('a/order/submit').data
        return request.post({
            url,
            data: params
        })
    }
}



