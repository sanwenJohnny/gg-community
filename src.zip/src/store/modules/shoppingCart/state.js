import commonState from 'sm/state'
const api = require('./config').default.api
Object.assign(commonState, {
    params: {
        [api.data]: {
            cityCode: '330100'
        },
        [api.edit]: {
            cityCode: '330100',
            skuId: 6,
            count: 1
        },
        [api.delete]: {
            cityCode: '330100',
            skuIds: [6]
        }
    }
})
export default {
    ...commonState,
    isMember: false,
    chooses: {},
    isChooseAll: false
}
