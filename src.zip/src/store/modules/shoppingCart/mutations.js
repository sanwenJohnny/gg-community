const api = require('./config').default.api
const commonMutations = require('f/commonMutationFactory').default(api)
import types from './types'
import utils from 'u'
import db from 'ss'
export default {
    ...commonMutations,
    [types.CHOOSE_ALL](state, data) {
        const isChooseAll = data.isChooseAll
        state.isChooseAll = isChooseAll
        utils.set(db.CART_CHOOSEALL, isChooseAll)
        if (data.batch) {
            const goodList = state.pageData.skus
            const newChooses = {}
            for (let i = 0, good; i < goodList.length; i++) {
                good = goodList[i]
                good.choose = isChooseAll
                if (isChooseAll) {
                    newChooses[good.skuId] = true
                }
            }
            state.chooses = newChooses
            utils.set(db.CART_CHOOSES, state.chooses)
        }
    },
    [types.ADD_CHOOSEITEM](state, data) {
        state.chooses[data.skuId] = true
        utils.set(db.CART_CHOOSES, state.chooses)
    },
    [types.DELETE_CHOOSEITEM](state, skuId) {
        delete state.chooses[skuId]
        utils.set(db.CART_CHOOSES, state.chooses)
    },
    [types.SET_CHOOSES](state, chooses) {
        state.chooses = chooses
    },
    [types.UPDATE_COUNT](state, data) {
        state.pageData.skus[data.id].count = data.count
    }
}
