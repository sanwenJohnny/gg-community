import commonTypes from 'sm/types'

export default {
    ...commonTypes,
    CHOOSE_ALL: 'chooseAll',
    ADD_CHOOSEITEM: 'addChooseItem',
    DELETE_CHOOSEITEM: 'deleteChooseItem',
    SET_CHOOSES: "setChooses",
    UPDATE_COUNT: 'updateCount'
}