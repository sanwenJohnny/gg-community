import types from './types'

export default {
  [types.SET_CITY] (state, payload) {
    state.sSelectedCity = payload.data
  },
  [types.SET_COMMUNITY] (state, payload) {
    state.sSelectedCommunity = payload.data
  },
  [types.SET_ORDERADDRESS] (state, payload) {
    state.sOrderAddress = payload.data
  },
  [types.SET_SAGENTADDRESS](state, payload) {
    state.sAgantAddress = payload.data
  }
}
