export default {
  sSelectedCity: {},
  sSelectedCommunity: {},
  sOrderAddress: {
    addressId: undefined,
    addressType: undefined
  },
  sAgantAddress: {}
}
