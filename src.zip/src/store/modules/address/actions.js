import utils from "@/utils"
import types from './types'
import request from '@/service/request'
import api from "@/static/api/address";
const factory = utils.actionRequestFactory

export default {
  selectCommunityAction: factory(api.selectCommunity),
  openedCityListAction: factory(api.openedCityList),
  searchCommunityAction: factory(api.searchCommunity),
  allReceiveAddresslistAction: factory(api.allReceiveAddresslist),
  locationCityAction: factory(api.locationCity),

  //选择城市
  setSelectedCityAction({ commit }, data) {
    commit(types.SET_CITY, { data: data })
  },
  //选择小区
  setSelectedCommunityAction({ commit }, data) {
    commit(types.SET_COMMUNITY, { data: data })
  },
  //设置提交订单收货地址
  setOrderAddressAction({ commit }, data) {
    commit(types.SET_ORDERADDRESS, { data: data })
  },
  // 设置代理地址
  setAgentAddressAction({ commit }, data) {
    commit(types.SET_SAGENTADDRESS, { data: data })
  },
  //获取城市下小区列表
  getCommunityListAction({ commit }, opts = {}) {
    const { data, showLoading } = opts
    return request.post({ url: api.communityList, data, showLoading })
  },

  //保存收货地址
  saveAddressAction({ commit }, opts = {}) {
    const { data, showLoading } = opts
    return request.post({ url: api.saveAddress, data, showLoading })
  },

  //删除收货地址
  deleteAddressAction({ commit }, opts = {}) {
    const { data, showLoading } = opts
    return request.post({ url: api.deleteAddress, data, showLoading })
  },

  //获取收货地址详情
  receiveAddressDetailAction({ commit }, opts = {}) {
    const { data, showLoading } = opts
    return request.post({ url: api.receiveAddressDetail, data, showLoading })
  },

  //获取提交订单收货地址列表
  orderReceiveAddresslistAction({ commit }, opts = {}) {
    const { data, showLoading } = opts
    return request.post({ url: api.orderReceiveAddresslist, data, showLoading })
  },
}
