import tools from '@/utils'

export default tools.setKeyToValue({
  SET_CITY: 'set_city',
  SET_COMMUNITY: 'set_community',
  SET_ORDERADDRESS: 'set_orderaddress',
  SET_SAGENTADDRESS: 'set_sAgentAddress'
})
