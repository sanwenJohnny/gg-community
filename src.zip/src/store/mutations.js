import types from './types'

export default {
  [types.SET_USERINFO] (state, payload) {
    let result = payload.data
    state.sUserInfo = result ? result : {}
  },
  [types.SET_CHOOSEAREA] (state, payload) {
    state.sChooseArea = payload
  },
  [types.SET_CARTNUMBER] (state, payload) {
    state.sCartNumber = payload.data || 0
  },
}
