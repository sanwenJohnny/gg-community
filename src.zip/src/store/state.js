export default {
  sUserInfo:{accountInfoVO:{},communityManagerVO:{}},
  sCartNumber:0,
  $$route:{
    history:[],
    currentPage:{},
    prevPage:{}
  }
}
