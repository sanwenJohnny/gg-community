<template>
  <div class="log" v-if="logInfo.logisticsCompany">
    <div class="wrap f_title title">
      <div class="name">{{logInfo.logisticsCompany}}</div>
      <div>{{logInfo.logisticsNumber}}</div>
    </div>
    <div class="wrap timeline" @click="goDetail">
      <div class="line_wrap">
        <ball-line :isCurr="true" />
      </div>
      <div class="info">
        <div class="f_title text">{{trackInfo.info}}
        </div>
        <div class="f_sub time" v-if="trackInfo.time">{{trackInfo.time}}</div>
      </div>
      <div class="icon">
        <img mode="widthFix" :src="arrowIcon">
      </div>
    </div>
  </div>
</template>

<script>
import imgApi from 'u/imgApi'
import ballLine from 'ordc/ballLine'
import utils from 'u'
import path from 'p'
export default {
  ivs: 'modOrderDetail',
  name: 'log',
  data() {
    return {
      arrowIcon: imgApi.getRes('orderSubmit', 'r_arrow')
    }
  },
  computed: {
    logInfo() {
      return this.pageData.logisticsInfo || {}
    },
    trackInfo() {
      const infos = this.logInfo.trackingList || []
      return infos[0] || {}
    }
  },
  methods: {
    goDetail() {
      utils.go(path.ORDER_LOGISTICS + `?shipmentCode=${this.logInfo.shipmentCode}&time=${this.pageData.payTime}`)
    }
  },
  components: {
    'ball-line': ballLine
  }
}
</script>

<style scoped lang="scss">
.title {
  display: flex;
  height: 30px;
  align-items: flex-end;
  .name {
    margin-right: 8px;
  }
}
.timeline {
  display: flex;
  padding-top: 16px;
  padding-bottom: 16px;
}
.line_wrap {
  width: 15px;
  margin-right: 14px;
}
.info {
  flex: 1;
  min-height: 40px;
  .text {
    color: #5ab37a;
    height: auto;
    line-height: 20px;
  }
  .time {
    font-size: 14px;
    margin-top: 6px;
  }
}

.icon {
  width: 10px;
  margin-left: 26px;
  display: flex;
  align-items: center;
  img {
    width: 100%;
  }
}
</style>
