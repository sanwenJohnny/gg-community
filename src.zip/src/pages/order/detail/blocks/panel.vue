<template>
  <div class="wrap detail_panel">
    <div class="wrapper">
      <icon-text :iconSrc="iconSrc" iconWidth="20px" fontColor="#333" space="11px" :text="orderInfo.orderStatusDesc" />
    </div>
    <div class="f_title serial">
      <div>订单编号：{{pageData.orderNumber}}</div>
      <button class="copy" @click="copy">复制</button>
    </div>
    <div class="f_title time">{{timeView}}</div>
  </div>
</template>

<script>
import imgApi from 'u/imgApi'
import { $ } from 'u'
import orderStatus2panelIcon from '../static/orderStatus2panelIcon'
import iconText from 'c/iconText'
export default {
  ivs: 'modOrderDetail',
  name: 'panel',
  data() {
    return {
      icons: {
        waitPay: imgApi.getRes('orderDetail', 'waitPay'),
        waitReceive: imgApi.getRes('orderDetail', 'waitReceive'),
        deal: imgApi.getRes('orderDetail', 'deal'),
        refund: imgApi.getRes('orderDetail', 'refund'),
        timeout: imgApi.getRes('orderDetail', 'timeout'),
        waitSend: imgApi.getRes('orderDetail', 'waitSend'),
      }
    }
  },
  computed: {
    orderInfo() {
      return this.pageData.orderStatusInfo || {}
    },
    iconSrc() {
      const name = orderStatus2panelIcon[this.orderInfo.orderStatus]
      return this.icons[name]
    },
    timeView() {
      if(!!this.pageData.payTime) {
        return `付款时间：${this.pageData.payTime}`
      }else {
        return `下单时间：${this.pageData.createTime}`
      }
    }
  },
  methods: {
    copy() {
      $(wx.setClipboardData, {
        data: this.pageData.orderNumber + ''
      }).then(res => {
        $(wx.getClipboardData).then(res => {
          console.log(res.data)
        })
        $(wx.showToast, {
          title: '订单编号已复制到剪切板',
          icon: 'none',
          duration: 2000
        })
      })
    }
  },
  components: {
    'icon-text': iconText
  }
}
</script>

<style scoped lang="scss">
.detail_panel {
  background: #FDF6B1;
  box-sizing: border-box;
  padding-top: 13px;
  padding-bottom: 10px;
  margin-bottom: 8px;
}

.wrapper {
  height: 18.5px;
  margin-bottom: 21px;
}

.serial,
.time {
  color: #333;
  font-family: PingFangSC-Regular;
  font-weight: normal;
}
.time.hide {
  opacity: 0;
}
.serial {
  margin-bottom: 8px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.copy {
  border-radius: 57px;
  background: transparent;
  color: #333;
  width: 48px;
}

.copy::after {
  border-radius: 57px;
  border-color: #333;
}
</style>
