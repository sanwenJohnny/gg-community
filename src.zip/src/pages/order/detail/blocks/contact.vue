<template>
  <div class="wrap contact_btn">
    <div class="f_title text" @click="call">联系商家</div>
    <div class="icon">
      <img mode="widthFix" :src="arrowIcon">
    </div>
  </div>
</template>

<script>
import { $ } from "u";
import imgApi from 'u/imgApi'
export default {
  ivs: 'modOrderDetail',
  name: 'contact',
  data() {
    return {
      arrowIcon: imgApi.getRes('orderSubmit', 'r_arrow')
    }
  },
  methods: {
    call() {
      $(wx.makePhoneCall, {
        phoneNumber: this.pageData.shopProductInfo.shopContactNumber
      }).then()
    }
  }
}
</script>

<style scoped lang="scss">
.contact_btn {
  display: flex;
  height: 44px;
  align-items: center;
  margin-bottom: 52px;
  .text {
    flex: 1;
  }
  .icon {
    width: 10px;
    display: flex;
    align-items: center;
    img {
      width: 100%;
    }
  }
}
</style>
