<template>
  <div class="wrap addr">
    <div class="wrapper">
      <div class="title">
        <div class="icon">
          <img mode="widthFix" :src="localIcon">
        </div>
        <div class="f_title text">{{title}}</div>
      </div>
      <div class="info">
        <div class="f_title text">{{addrInfo.detailAddress}}</div>
        <div class="user">
          <!-- 文字 -->
          <div class="f_title text">
            <div v-if="!useSelf">小区团长</div>
            <div>{{useSelf? addrInfo.fullName : adminInfo.communityManager}}</div>
            <div>{{useSelf? addrInfo.mobileNumber :adminInfo.communityManagerMobileNumber}}</div>
          </div>
          <!-- 按钮 -->
          <contact :phone="adminInfo.communityManagerMobileNumber" :hide="useSelf"/>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import imgApi from 'u/imgApi'
import contact from '../components/contact'

const type2title = {
  1: '收货地址',
  2: '提货地址'
}
export default {
  ivs: 'modOrderDetail',
  name: 'addr',
  data() {
    return {
      localIcon: imgApi.getRes('orderDetail', 'lightLocal')
    }
  },
  computed: {
    addrInfo() {
      return this.pageData.orderReceiveAddress || {}
    },
    adminInfo() {
      return this.addrInfo.communityManagerInfoVO || {}
    },
    title() {
      return type2title[this.addrInfo.type]
    },
    useSelf() {
      return this.addrInfo.type == 1
    }
  },
  components: {
    contact: contact
  }
}
</script>

<style scoped lang="scss">
.addr {
  padding-right: 0;
}
.wrapper {
  padding-top: 13px;
  padding-right: 10px;
}
.title {
  display: flex;
  align-items: center;
  margin-bottom: 6px;
  .icon {
    width: 14px;
    margin-right: 10px;
    display: flex;
    align-items: center;
    img {
      width: 100%;
    }
  }
}

.info {
  flex: 1;
  padding-left: 25px;
  & > .text {
    height: auto;
    line-height: 20px;
    font-family: PingFangSC-Regular;
    font-weight: normal;
    margin-bottom: 12px;
  }
  .user {
    display: flex;
    font-family: PingFangSC-Regular;
    font-weight: normal;
    justify-content: space-between;
    align-items: center;
    & > .text {
      flex: 1;
      display: flex;
      div {
        margin-right: 8px;
      }
    }
  }
}
</style>
