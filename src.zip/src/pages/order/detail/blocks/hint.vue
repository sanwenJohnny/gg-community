<template>
  <div class="wrap hint" v-if="show">
    <div class="i_t">
      <!-- icon -->
      <div class="icon">
        <img mode="widthFix" :src="thumpIcon">
      </div>
      <!-- 文字 -->
      <div class="f_title text" v-if="statusInfo.orderStatus == 1">
        <span>请在</span>
        <count-down :restTime="restTime" color="red" fontWeight="bold"  @countEnd="countEnd" />
        <span>内付款，时间结束后订单将会被取消</span>
      </div>
      <div class="f_title text" v-if="statusInfo.orderStatus == 7">提交订单后30:00内未付款，订单已取消</div>
    </div>
  </div>
</template>

<script>

import imgApi from 'u/imgApi'
import utils from 'u'
import iconText from 'c/iconText'
import countDown from 'c/countDown'
export default {
  ivs: 'modOrderDetail',
  name: 'hint',
  data() {
    return {
      thumpIcon: imgApi.getRes('orderDetail', 'lightThump'),
      time: '30:00'
    }
  },
  computed: {
    statusInfo() {
      return this.pageData.orderStatusInfo || {}
    },
    restTime() {
      let t = this.statusInfo.endTime
      if (t) {
        t = t.replace('-', '')
        t *= 1000
      }
      return t || 0
    },
    show() {
      return this.statusInfo.orderStatus == 1 || this.statusInfo.orderStatus == 7
    }
  },
  methods: {
    // 倒计时结束
    countEnd() {
      this.resetPageDataAction()
    }
  },
  mounted() {
    if (this.statusInfo.orderStatus == 1) {
      this.countDown()
    }
  },
  components: {
    'icon-text': iconText,
    'count-down': countDown
  }
}
</script>

<style scoped lang="scss">
.hint {
  background: #fff;
  height: 32px;
  line-height: 32px;
}

.i_t {
  display: flex;
  align-items: center;
  height: 100%;
  // icon
  .icon {
    width: 18px;
    height: 100%;
    display: flex;
    align-items: center;
    margin-right: 8px;
    img {
      width: 100%;
    }
  }
  .text {
    font-size: 12px;
    color: #333;
    font-weight: normal;
  }
}
</style>
