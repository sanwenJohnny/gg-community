<template>
  <div class="order">
    <div class="wrap f_title title">由本地商家发货</div>
    <div class="">
      <good-item v-for="(good, j) in goodList" :key="j" thumbSize="62px" showStatus=1 :good="good" @refund="refund" :subline="j==0?0:1"/>
    </div>
    <div class="wrap b_top stat">
      <div class="f_title">
        <div>订单总计</div>
        <div>￥{{pageData.totalPrice}}</div>
      </div>
      <div class="f_title" v-if="pageData.usedCoin > 0">
        <div>环球G币抵现</div>
        <div>-¥{{pageData.usedCoin}}</div>
      </div>
      <div class="f_title">
        <div>实付金额</div>
        <div>¥{{shopData.realPrice}}</div>
      </div>
    </div>
  </div>
</template>

<script>
import path from 'p'
import utils from 'u'
import goodItem from 'ordc/goodItem'
import { $ } from "u";
export default {
  ivs: 'modOrderDetail',
  name: 'order',
  data() {
    return {}
  },
  computed: {
    shopData() {
      return this.pageData.shopProductInfo || {}
    },
    goodList() {
      return this.shopData.productInfo
    }
  },
  methods: {
    // 跳转退款
    refund(good) {
      $(wx.showModal, {
        content: '售后问题可先与小区长沟通',
        cancelText: '拨打电话',
        confirmText: '去退款'
      }).then(res => {
        if (res.confirm) {
          utils.go(
            path.ORDER_REFUND_APPLY + `?orderProductId=${good.orderProductId}`
          )
        } else if (res.cancel) {
          $(wx.makePhoneCall, {
            phoneNumber: this.pageData.orderReceiveAddress.communityManagerInfoVO.communityManagerMobileNumber
          })
        }
      })
    }
  },
  components: {
    'good-item': goodItem
  }
}
</script>

<style scoped lang="scss">
.order {
  margin-top: 8px;
  margin-bottom: 8px;
}
.title {
  height: 44px;
  line-height: 44px;
}
.stat {
  padding-top: 16px;
  padding-bottom: 16px;
  &.b_top::after {
    transform: translateX(10px) scale(0.25);
  }
}
.stat > div {
  display: flex;
  justify-content: space-between;
  font-family: PingFangSC-Regular;
  font-weight: normal;
  margin-bottom: 14px;
}
.stat > div:last-child {
  margin-bottom: 0;
}
</style>
