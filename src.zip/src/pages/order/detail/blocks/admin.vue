<template>
  <div class="wrap admin" v-if="useSelf">
    <div class="b_top wrapper">
      <div class="f_title text">
        <div>{{adminInfo.communityName}}</div>
        <div class="info">
          <div>{{adminInfo.communityManager}}</div>
          <div>{{adminInfo.communityManagerMobileNumber}}</div>
        </div>
      </div>
      <contact :phone="adminInfo.communityManagerMobileNumber"/>
    </div>
  </div>
</template>

<script>
import contact from '../components/contact'
export default {
  ivs: 'modOrderDetail',
  name: 'admin',
  data() {
    return {}
  },
  computed: {
    addrInfo() {
      return this.pageData.orderReceiveAddress || {}
    },
    adminInfo() {
      return this.addrInfo.communityManagerInfoVO || {}
    },
    useSelf() {
      return this.addrInfo.type == 1
    }
  },
  components: {
    contact
  }
}
</script>

<style scoped lang="scss">
.admin {
  padding-right: 0;
  padding-bottom: 22px;
  padding-top: 13px;
  & > .wrapper {
    display: flex;
    align-items: center;
    padding-left: 25px;
    padding-top: 16px;
    padding-right: 10px;
  }
}

.text {
  flex: 1;
  font-family: PingFangSC-Regular;
  font-weight: normal;
  height: auto !important;
}

.info {
  display: flex;
  margin-top: 12px;
  div {
    margin-right: 10px;
  }
}
</style>
