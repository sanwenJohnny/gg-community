<template>
  <div class="wrap pre" v-if="!useSelf">
    <div class="title">
      <required-info text="预留信息" space="4px" iconWidth="8px" />
    </div>
    <div class="f_title info">
      <div>{{preInfo.fullName}}</div>
      <div>{{preInfo.mobileNumber}}</div>
    </div>
    <div class="f_title note" v-if="preInfo.remark">{{preInfo.remark}}</div>
  </div>

</template>

<script>

import requiredInfo from 'ordc/requiredInfo'

export default {
  ivs: 'modOrderDetail',
  name: 'preInfo',
  data() {
    return {}
  },
  computed: {
    addrInfo() {
      return this.pageData.orderReceiveAddress || {}
    },
    preInfo() {
      return this.addrInfo.reservationInfoVO || {}
    },
    useSelf() {
      return this.addrInfo.type == 1
    }
  },
  components: {
    'required-info': requiredInfo,
  }
}
</script>

<style scoped lang="scss">
.pre {
  padding-bottom: 22px;
  padding-top: 17px;
  position: relative;
}
.title {
  padding-left: 13px;
  margin-bottom: 6px;
}
.info {
  padding-left: 25px;
  display: flex;
  font-family: PingFangSC-Regular;
  font-weight: normal;
  div {
    margin-right: 10px;
  }
}

.note {
  font-family: PingFangSC-Regular;
  font-weight: normal;
  height: auto !important;
  line-height: 16px;
  margin-top: 12px;
  padding-left: 25px;
}
</style>
