<template>
    <div class="stripe"></div>
</template>

<script>
export default {
  name: 'stripe',
  data() {
    return {}
  }
}
</script>

<style scoped lang="scss">
.stripe {
//   position: absolute;
//   bottom: 0;
  width: 100%;
  height: 3px;
  background: #fff
    url(https://img.gegejia.com/life/miniprogram/local/stripe_2x.png) repeat;
    background-size: auto 100%;
}
</style>
