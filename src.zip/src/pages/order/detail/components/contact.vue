<template>
  <button class="f_sub contact" @click="call" v-if="!hide">联系小区长</button>
</template>

<script>
import { $ } from 'u'
export default {
  name: 'contact',
  props: ['phone', 'hide'],
  data() {
    return {}
  },
  methods: {
    call() {
      $(wx.makePhoneCall, {
        phoneNumber: this.phone
      }).then()
    }
  }
}
</script>

<style scoped lang="scss">
.contact {
  color: #000000;
  width: 76px;
  height: 24px;
  border-radius: 57px;
  background: #fff;
}

.contact::after {
  border-color: #000;
  border-radius: 57px;
}
</style>
