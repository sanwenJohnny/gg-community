<template>
  <div>
    <!-- 提示 -->
    <hint/>
    <!-- 头信息 -->
    <panel/>
    <!-- 物流 -->
    <log/>
    <!-- 地址 -->
    <addr/>
    <!-- 小区长信息 -->
    <admin/>
    <!-- 预留信息 -->
    <pre-info/>
    <!-- 条纹 -->
    <stripe/>
    <!-- 订单信息 -->
    <order/>
    <!-- 联系商家 -->
    <contact/>
  </div>
</template>

<script>
import api from 'a/order/detail'
import utils from 'u'
// blocks
import hint from './blocks/hint'
import panel from './blocks/panel'
import log from './blocks/log'
import addr from './blocks/addr'
import admin from './blocks/admin'
import preInfo from './blocks/preInfo'
import order from './blocks/order'
import contact from './blocks/contact'
import stripe from './components/stripe'

export default {
  ivs: 'modOrderDetail',
  data() {
    return {}
  },
  onLoad() {
    utils.loading()
  },
  onShow() {
    const query = this.q()
    this.resetPageDataAction({
      params: {
        orderId: query.orderId
      }
    }).then(res => {
      utils.loaded()
    })
  },
  components: {
    hint,
    panel,
    log,
    addr,
    admin,
    'pre-info': preInfo,
    order,
    contact,
    stripe
  }
}
</script>

<style scoped lang="scss">

</style>
