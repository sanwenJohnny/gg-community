<template>
  <div class="container bg-f0">
    <section class="refund-info-top align-c">
      <!-- 退款中 -->
      <div v-if="refundDetail.refundStatus == 1">
        <p class="title-1 mb-10">
          <i class="revocation-btn right f-12" @tap="cancelRefund(refundDetail.refundNumber)">撤销申请</i>
          你已经成功发起退款申请<br>
          请耐心等待处理
        </p>
        <p>如果处理时间超过24小时，系统将自动为您退款</p>
      </div>
      
      <!-- 退款完成 -->
       <div v-if="refundDetail.refundStatus == 2">
        <p class="title-1 mb-10">退款成功</p>
        <p>
          实际退款: ¥{{refundDetail.realRefundPrice/100}} <br>
          返还G币: {{refundDetail.refundCoin/100}}个 <br>
          退款时间: {{refundDetail.refundTime}}
        </p>
      </div>
      
      <!-- 退款拒绝 -->
      <div v-if="refundDetail.refundStatus == 3">
        <p class="title-1 mb-10">
          你的退款申请被拒绝<br>
          可以重新发起退款
        </p>
        <p>原因: {{refundDetail.rejectReason}}</p>
      </div>

      <!-- 退款取消 -->
      <p class="title-1" v-if="refundDetail.refundStatus == 4">你已撤销退款申请</p>
    </section>
    <section class="info-person" v-if="managerInfo">
      <h1>小区长信息</h1>
      <p class="b_top pt-10 mb-10">姓名: {{managerInfo.name}}</p>
      <p class="clearfix">
        手机号: {{managerInfo.phoneNumber}}
        <i class="detail-btn right" @tap="call(managerInfo.phoneNumber)">联系小区长</i>
      </p>
    </section>
    <section class="refund-list">
      <h1>退款信息</h1>
      <ul class="product-info">
          <li>
              <i class="product-tu" :style="{backgroundImage:'url('+productInfo.productImage+')'}"></i>
              <span>
                  <h2 v-text="productInfo.productName"></h2>
                  <i class="f-12">
                    退款金额: &yen;{{refundDetail.applyRefundPrice/100}}
                    <i class="col-74">(&yen;{{productInfo.singlePrice/100}}x{{productInfo.selectedCount}})</i>
                  </i>
              </span>
              <em class="col-c2">x{{productInfo.selectedCount}}</em>
          </li>
      </ul>
      <div class="b_top refund-info">
        退款原因: {{refundDetail.refundReason}}<br>
        退款金额: &yen;{{refundDetail.applyRefundPrice/100}}<br>
        申请时间: {{refundDetail.applyTime}}<br>
        <p class="clearfix">
          订单编号: {{refundDetail.orderNumber}}
          <i class="detail-btn right" @tap="copyText(refundDetail.orderNumber)">复制</i>
        </p>
      </div>
    </section>
  </div>
</template>
<script>
import { $ } from "@/utils/index";
import { mapActions } from 'vuex';

export default {
  data() {
    return {
      refundDetail: '',
      managerInfo: '',
      productInfo: '',
      refundNumber: ''
    };
  },
  computed: {},
  components: {
  },
  methods: {
    ...mapActions('modOrderRefund',['refundDetailAction','refundCancelAction']),
    getDetail() {
      // const _rNum = this.$root.$mp.query.refundNumber
      // console.log(_rNum)
      const _params = {
        refundNumber: this.refundNumber
      }
      this.refundDetailAction({data:_params}).then(res=> {
        this.refundDetail = res;
        this.managerInfo = res.communityManagerInfo;
        this.productInfo = res.productInfo;
      })
    },
    call(num) {//打电话
      $(wx.makePhoneCall, {
        phoneNumber: num
      })
    },
    copyText(val) {//复制
      $(wx.setClipboardData,{
        data: val
      }).then(res=> {
        this.$wxComps.toast('订单编号已复制剪切板')
      }) 
    },
    cancelRefund(num) {//撤销申请
      const _params = {
        refundNumber: num
      }
      this.refundCancelAction({data:_params}).then(res=> {
        this.$wxComps.toast("撤销成功")
        this.getDetail()
      })
    }
  },
  mounted() {
    this.refundNumber = this.$root.$mp.query.refundNumber || 0
    this.getDetail()
  }
};
</script>

<style scoped lang="scss">
@import "../../../../css/mixins";
@import "../../../../css/common";
.bg-f0 {
  background: #f0f0f0;
}
.p-10 {
  padding: 0 10px;
}
.pt-10 {
  padding-top: 10px;
}
.mb-10 {
  margin-bottom: 10px;
}
.col-74 {
  color: #747474;
}
.col-c2 {
  color: #c2c2c2;
}
.f-12 {
  font-size: 12px;
}
.title-1 {
  font-size: 16px;
  color: #623900;
}
.align-c {
  align-items:center;
}

.refund-info-top {
  display: flex;
  width: 100%;
  min-height: 80px;
  padding: 10px;
  box-sizing: border-box;
  // background: linear-gradient(45deg, #FFCE53 0%, #FFA832 100%);
  background: #FDF6B1;
  color: #915906;
  > div {
    flex: 1;
  }
  .revocation-btn {
    width: 94px;
    @include Height(38);
    @extend .t-c;
    // color: #333;
    background: #FFE000;
    border-radius: 30px;
  }
}

.info-person {
  @extend .p-10;
  margin-bottom: 10px;
  padding-bottom: 10px;
  background: #fff;
  h1 {
    @include Height(44);
  }
}

.detail-btn {
  @include Height(24);
  padding: 0 10px;
  border-radius:  20px;
  border: 1px solid #000;
  box-sizing: border-box;
  @extend .f-12;
  @extend .t-c;
}

.refund-list {
  @extend .p-10;
  margin-bottom: 10px;
  background: #fff;
  color: #333;
  a,
  i,
  em,
  span {
    display: inline-block;
  }

  h1 {
    @include Height(44);
  }
  .product-info {
    @extend .b_top;
    li {
      display: flex;
      padding: 10px 0;
      > span {
        flex: 1;
        margin: 0 10px;
        h2 {
          @include Ellipsis(2);
        }
      }
      > em {
        @extend .right;
      }
    }
    .product-tu {
      width: 62px;
      height: 62px;
      @include Background("", cover);
    }
  }
}
.refund-info {
  line-height: 1.6;
  padding: 15px 0;
}
</style>
