<template>
  <div class="container">
    <!-- 退款商品-->
    <Product v-model="refundCount" :refundProductList="refundProductList" :editurl="editUrl" :isShowEdit="refundInfo.canBatchEdit"></Product>
    <!-- 退款原因-->
    <Reason :reasonData="reasonList" @reasonListIndex="getReasonListIndex"></Reason>
    <!-- 退款金额-->
    <div class="refund_amount">
        <div class="amount">
            <span class="txt">退款金额: </span>
            <div class="price_num">
                <span class="unit">¥</span>
                <input class="num showEditPrice" type="digit" v-model="editRefundPrice" @blur="checkEditPrice"/>
            </div>
        </div>
        <p class="maxPrice">最高金额{{showRefundPrice}}(含现金+G币)<!-- {{refundInfo.totalPrice/100}} --></p>
    </div>
    <!-- 上传凭证-->
    <Upload @updateImg="getUploadImg"></Upload>
    <div class="bottom-btn">
      <button class="primary-btn" @tap="applyBtn">提交</button>
    </div>
  </div>
</template>

<script>
import { mapActions } from 'vuex'
import imgApi from "@/utils/imgApi"
import Product from "./blocks/product"
import Upload from "./blocks/upload"
import Reason from "./blocks/reason"

export default {
  data () {
    return {
      reasonId:'',
      refundProductList:[],
      refundInfo:'',
      reasonText:'请选择',
      refundCount:1,
      editRefundPrice:0,
      chooseIndex:1,
      reasonList:'',
      refundImgList:[],
      isApplying:false,
      isUpLoad:false,
      paramsProductInfo:''
    }
  },
  components:{
    Product,
    Upload,
    Reason
  },
  computed:{
    /**
     * 退货商品金额
     * 根据用户提交的退货商品及数量,
     * 计算退货商品金额
     */
    applyRefundPrice: function(){
        let count = 0;
        let productPrice = 0;
        let refundPrice = 0;
        let product = {};
        let len = this.refundProductList.length;
        for(var i=0; i<len; i++){
            product = this.refundProductList[i];
            count = len == 1 ? this.refundCount : product.selectedCount;

            if(count == product.remainingCount){
                productPrice = product.totalPrice;
            }else{
                productPrice = parseInt(product.singlePrice) * parseInt(count);
            }
            refundPrice += productPrice;
        }
        return refundPrice;
    },
    showRefundPrice: function(){
        return this.totalPrice/100;
    },
    /**
     * 总退款金额
     * 退货商品金额
     */
    totalPrice: function(){
        return this.applyRefundPrice;
    },
    /**
     * 同步退货商品信息
     */
    productInfo: function(){
        let productInfo = [];
        if(this.refundProductList.length == 1){
            productInfo.push({
                orderProductId: this.refundProductList[0].orderProductId,
                selectedCount: this.refundCount,
            });
            //productInfo = JSON.stringify(productInfo);
        }else{
            productInfo = this.paramsProductInfo;
        }
        return productInfo;
    },
    editUrl(){
      let url="/pages/order/refund/edit/main?orderId="+this.orderId
      return url

    },
  },
  watch: {
      /**
       * 监控refundCount是否变动,
       * 如产生变动,
       * 用户手动修改的退款金额(editRefundPrice)需与系统计算的退款金额(showRefundPrice)同步,
       * 并显示系统退款金额
       */
      refundCount: function(newCount, count){
          var buyCount = this.refundProductList[0].remainingCount;
          // if(newCount == ''){
          //     this.$wxComps.toast('退货数量不能为空');
          //     return false
          // }
          if(newCount > buyCount){
              this.$wxComps.toast('退货数量不得超过' + buyCount);
              this.refundCount = buyCount;
          }else{
              this.editRefundPrice = this.showRefundPrice;
          }
      },
      /**
       * 监控退款金额改动
       */
      editRefundPrice: function(newPrice, price){
          //var isPrice = /^(0|([1-9]\d*))(?:\d*|\.\d+)$/;
          let isPrice=/^[0-9]{1}[0-9]*(\.[0-9]{1,2})?$/;
          if(this.accMul(newPrice, 100) > this.totalPrice){
              this.$wxComps.toast('不能大于最大退款金额');
              this.editRefundPrice = this.totalPrice/100;
          }
      }
  },
  methods: {
    ...mapActions('modOrderRefund',['refundApplyAction','getApplyInfoAcion']),
    /**
     * 验证用户编辑价格
     */
    checkEditPrice: function(){
        if(this.editRefundPrice === ''){
            this.editRefundPrice = 0;
        }
    },
    accMul: function(arg1,arg2) {
        var m=0,s1=arg1.toString(),s2=arg2.toString();
        try{m+=s1.split(".")[1].length}catch(e){}
        try{m+=s2.split(".")[1].length}catch(e){}
        return Number(s1.replace(".",""))*Number(s2.replace(".",""))/Math.pow(10,m);
    },
    getReasonListIndex(index){
      this.reasonId = this.reasonList[index].id
    },
    getUploadImg(img){
      this.refundImgList = img
    },
    getRefundData(){
      let data = {}
      if(this.orderProductId){
        data = {
          orderProductId: this.orderProductId
        }
      }
      if(this.paramsProductInfo){
        data = {
          productList: this.paramsProductInfo
        }
      }
      let productInfo=[]
      this.getApplyInfoAcion({data}).then((data)=>{
          this.refundInfo = data;
          this.orderId = data.orderId;
          this.refundProductList = data.productList;
          this.reasonList = data.refundReasonList;
          if(this.refundProductList.length==1){
              if(this.refundProductList[0].selectedCount){
                this.refundCount = this.refundProductList[0].selectedCount
              }else{
                this.refundCount = this.refundProductList[0].remainingCount;
              }
          }else{
              this.refundProductList.forEach((em,index)=>{
                  productInfo.push({
                      orderProductId: em.orderProductId,
                      selectedCount: em.selectedCount
                  })
              })
              this.paramsProductInfo = productInfo
              //this.paramsProductInfo = JSON.stringify(productInfo)
          }
          this.editRefundPrice = this.showRefundPrice
      })
    },
    applyBtn(){
      let isPrice=/^[0-9]{1}[0-9]*(\.[0-9]{1,2})?$/;
      if(!this.reasonId){
        this.$wxComps.toast('请选择退款原因');
        return false;
      }
      if(!this.editRefundPrice){
        this.$wxComps.toast('请填写正确退款金额');
        return false;
      }
      if(!isPrice.test(this.editRefundPrice)){
        this.$wxComps.toast('请填写正确退款金额');
        return false;
      }
      if(this.isApply){
        this.$wxComps.toast('正在申请中...');
        return false
      }
      this.isApplying = true;
      let data = {
        productList: JSON.parse(this.productInfo),
        reasonId: this.reasonId,
        totalRefundPrice: this.editRefundPrice*100,
        imageList: this.refundImgList
      }
      //console.log(data)
      this.refundApplyAction({data}).then((data)=>{
          this.isApplying = false;
          if(data.success){
            this.$wxComps.toast('提交申请成功，请等待商家审核！');
            setTimeout(()=>{
              this.$router.push({url:'/pages/order/refund/list/main'})
            },2000)
          }else{
            this.$wxComps.toast('提交申请失败');
          }
      })
    }
  },
  onLoad(options){
    Object.assign(this.$data, this.$options.data())
    this.orderProductId = this.$root.$mp.query.orderProductId
    this.getRefundData()
    //this.paramsProductInfo = this.$root.$mp.query.productInfo
    //console.log(this.paramsProductInfo,2222)   
  }
}
</script>
<style lang="scss">
  .refund_item {
    padding: 0 10px;
    margin-bottom: 8px;
    background: $whiteBase; 
    font-size: 14px;
    color: $darkBlackBase;
  }
</style>
<style scoped lang="scss">
.container{
  background: $lightWhiteBase;
}
.refund_amount{
  margin-bottom: 0;
    .amount{
        display: flex;
        align-items: center;
        padding: 9px 10px;
        background: #fff;
        .price_num{
            flex: 1;
            height: 30px;
            line-height: 30px;
            margin-left: 10px;
            padding: 0 5px;
            color: #ff6052;
            font-size: 16px;
            .unit{
              vertical-align: top;
            }
            input{
                display: inline-block;
                width: 80%;
                height: 30px;
                color: #ff6052;
                font-size: 16px;
            }
        }
    }
    .maxPrice{
      padding: 8px 10px;
      font-size: 12px;
      color: #747474;
    }
    .des{
        padding: 15px 0;
        span{
            margin-left: 20px;
        }
    }
}
.apply-btn{
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    padding: 10px 0;
    text-align: center;
    background: #f42b52;
    color: #fff;
    font-size: 16px;
}
.bottom-btn{
  margin-top: 20px;
  padding: 5px 10px;
  button{
    width: 100%;
  }
}
</style>
