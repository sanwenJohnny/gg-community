<template>
    <!-- 上传凭证-->
    <div class="refund_item refund_upload">
        <div class="tlt">
            <h4>上传凭证<span>（最多选择3张）</span></h4>
        </div>
        <ul class="upload_list">
            <li v-for="(image, index) in uploadImgs" :key="index">
                <span class="close" @tap="deleteImg(index)" :style="{backgroundImage:'url('+clearImg+')'}"></span>
                <img class="preview" :src="image" alt=""/>
            </li>
            <li class="upload_btn" v-if="uploadImgs.length < 3">
                <span class="upload-icon" @tap="uploadImg">+</span>
            </li>
        </ul>
    </div>
</template>
<script>
import { $ } from "@/utils";
import imgApi from "@/utils/imgApi";
import { TOKEN } from "@/utils/constants";

export default {
  data() {
    return {
      uploadImgs: [],
      clearImg: imgApi.getRes("search", "clear")
    };
  },
  components: {},
  computed: {},
  methods: {
    /**
     * 选择上传图片
     * 上传图片几个限制条件:
     * 1、只能上传单张图片
     * 2、最多能上传三张图片
     */
    uploadImg() {
      $(wx.chooseImage, {
        count: 1,
        sizeType: ["original", "compressed"],
        sourceType: ["album", "camera"]
      }).then(res => {
        this.uploadFile(res.tempFilePaths[0]);
      });
    },
    /**
     * 删除上传图片
     * 需传入删除图片的位置index
     * @param index
     */
    deleteImg: function(index) {
      this.$wxComps.confirm("确认删除图片吗?").then(res => {
        if (!res) return false;
        this.uploadImgs.splice(index, 1);
        this.$emit("updateImg", this.uploadImgs);
      });
    },
    uploadFile(file) {

      const token = wx.getStorageSync(TOKEN);
      $(wx.uploadFile, {
        url: "https://test.gegeselect.com/api/img/imgListUpload/mini",
        filePath: file,
        name: "file",
        header: {
          token: token
        }
      }).then(res => {
        const _res = JSON.parse(res.data)
        if(_res.status == 0) {
          this.$wxComps.toast(_res.errorMessage)
          return false
        }

        const _data = _res.data
        const _img = _data.imgUrlList[0]
        
        this.uploadImgs.push(_img);
        this.$emit("updateImg", this.uploadImgs)
      });
    }
  },
  onShow() {}
};
</script>

<style scoped lang="scss">
.tlt {
  padding: 20px 0;
  h4 {
    font-size: 14px;
    font-weight: normal;
    i {
      width: 2px;
      height: 14px;
      margin-right: 5px;
      vertical-align: middle;
      background: #000;
    }
    span {
      color: #858585;
      font-size: 12px;
    }
  }
}
/* 上传凭证 */
.refund_upload {
  padding: 0 0 0 10px;
  .upload_list {
    display: flex;
    padding-bottom: 20px;
    li {
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      width: 69px;
      height: 69px;
      margin-left: 12px;
      &:first-child {
        margin-left: 0;
      }
      img {
        width: 100%;
        height: 100%;
      }
      .close {
        position: absolute;
        top: -6px;
        right: -6px;
        display: block;
        width: 16px;
        height: 16px;
        background-size: 100%;
      }
    }
    .upload-icon {
      width: 67px;
      height: 67px;
      line-height: 67px;
      text-align: center;
      color: #c0c0c0;
      font-size: 30px;
      border: 1px dashed #c0c0c0;
    }
  }
}
</style>
