<template>
  <!-- 退款原因-->
  <div class="refund_item refund_reason">
      <span class="text">退款原因: </span>
      <div class="reason_select">
          <picker mode="selector" @change="bindPickerChange" :value="chooseIndex" :range="reasonData" range-key="reason" class="select">
            <!-- <view v-for="item in reasonList" style="line-height: 50px">{{item}}</view> -->
            <view>{{reasonText}}</view>
          </picker>
          <div class="trangle"><img :src="arrowIcon" alt=""></div>
      </div>
  </div>
</template>
<script>
import imgApi from "@/utils/imgApi"
export default {
  data () {
    return {
      reasonId:'',
      reasonText:'请选择',
      chooseIndex:1,
      arrowIcon: imgApi.getRes('orderSubmit', 'r_arrow'),
    }
  },
  components:{
  },
  computed:{
  },
  props:{
    reasonData:''
  },
  methods: {
    bindPickerChange: function(e) {
      //console.log('picker发送选择改变，携带值为', e.target.value)
      let index = e.target.value
      this.chooseIndex = index
      this.reasonText = this.reasonData[index].reason
      this.$emit("reasonListIndex",this.chooseIndex)
    }
  },
  onShow(){
  },
  created () {
  }
}
</script>

<style scoped lang="scss">
/* 选择退款原因 */
.refund_reason {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 48px;
    .text {
        color: #333;
        font-size: 14px; 
    }
    .reason_select {
        display: flex;
        align-items: center;
        color: #747474;
        .trangle {
            width: 8px;
            height: 12px;
            margin-left: 8px;
            img{
              display: block;
              width: 100%;
              height: 100%;
            }
        }
    }
}
</style>
