<template>
  <!-- 退款商品-->
  <div class="refund_item pro_module">
      <div class="pro_single" v-if="refundProductList.length == 1">
          <div class="pro_photo"><img :src="refundProductList[0].productImage" alt=""/></div>
          <!-- 单个退款商品-->
          <div class="pro_mes">
              <div class="info_top">
                  <!-- 商品标题-->
                  <p class="pro_title">{{refundProductList[0].productName}}</p>
                  <!-- 商品数量-->
                  <subtractor :count="refundCount" :max="refundProductList[0].remainingCount" id="0" @updateCount="countUpdate"></subtractor>
              </div>
              <div class="info_bottom">
                  <div class="amount" v-if="refundProductList[0].remainingCount == refundCount">合计: ¥{{refundProductList[0].totalPrice/100}} ( ¥{{refundProductList[0].singlePrice/100}}x{{refundCount}} )</div>
                  <div class="amount" v-else>合计: ¥{{refundProductList[0].singlePrice*refundCount/100}} ( ¥{{refundProductList[0].singlePrice/100}}x{{refundCount}} )</div>
                  <a :href="editurl" class="edit" v-if="isShowEdit">批量编辑</a>
              </div>
          </div>
      </div>
      <!-- 批量退款商品-->
      <div class="pro_collect" v-if="refundProductList.length > 1">
          <div class="p_list_module">
            <ul class="p_list">
                <li class="p_photo" v-for="(product,index) in refundProductList" :key="index">
                    <img :src="product.productImage" alt=""/>
                    <!-- <p>¥{{product.refundPrice/100}}</p> -->
                    <p class="price" v-if="product.remainingCount == product.selectedCount">¥ {{product.totalPrice/100}}</p>
                    <p class="price" v-else>¥ {{product.singlePrice*product.selectedCount/100}}</p>
                </li>
                <li><a :href="editurl" class="edit" v-if="isShowEdit">批量编辑</a></li>
            </ul>
          </div>
      </div>
  </div>
</template>

<script>
import subtractor from "../../edit/components/subtractor";

export default {
  data () {
    return {
    }
  },
  components:{
    subtractor
  },
  props:{
    refundProductList:'',
    refundCount:'',
    editurl:'',
    isShowEdit:''
  },
  model:{
    prop:'refundCount',
    event:'count'
  },
  computed:{
  },
  watch: {
  },
  methods: {
    countUpdate(count,id){
      this.refundCount = count;
      this.$emit('count',count);
    }
  },
  onShow(){
  },
  created () {
  }
}
</script>

<style scoped lang="scss">
a:hover{
  background: none;
}
.pro_module {
  padding: 16px 10px 4px 10px; 
  margin-top: 8px;
}
.pro_single {
    display: flex; 
    padding-bottom: 12px;
   .pro_photo {
        display: flex;
        flex: none;
        width: 60px;
        height: 60px;
        margin-right: 10px; 
        img {
            width: 100%;
            height: 100%; 
        }
    }
    .pro_mes {
        display: flex;
        flex: 1;
        flex-direction: column;
        justify-content: space-between;
        .info_top {
            display: flex;
            align-items: flex-start; 
            .pro_title {
                width: 90%;
                height: 40px;
                line-height: 20px;
                /* display: flex; */
                /* flex: 1;*/                
                margin-right: 8px;
                @include Ellipsis(2);
            }
        }
        .info_bottom {
            display: flex;
            justify-content: space-between;
            align-items: flex-end; 
            font-size: 12px;
        }
    }
}
/* 多个退款商品 */
.pro_collect {
    position: relative;
    .p_list_module{
      width: 340px;
    }
}
.p_list {
    overflow: hidden;
    li{
      float: left;
      position: relative;
      width: 60px;
      height: 60px;
      margin: 0 10px 12px 0;
      img{
        width: 100%;
        height: 100%;
      }
      .price {
          position: absolute;
          left: 0;
          bottom: 0;
          color: #fff;
          font-size: 12px;
          width: 100%;
          height: 16px;
          line-height: 16px;
          text-align: center;
          background: rgba(0, 0, 0, 0.5); 
      }
      &:last-child{
        display: flex;
        align-items: flex-end;
        margin-right: 0;
      }
    }
}
</style>
