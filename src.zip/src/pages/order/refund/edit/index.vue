<template>
  <div class="container">
    <div class="refund_products">
        <ul class="products" v-if="products.length > 0">
            <li class="pro_item" v-for="(product, index) in products" :key="index">
                <div @tap="selectItem(product,index)"><checkBox :isChoose="product.checked" /></div>
                <div class="pro_detail">
                    <div class="pro_photo"><img :src="product.productImage" alt=""/></div>
                    <!-- 退款商品-->
                    <div class="pro_mes">
                        <div class="info_top">
                            <!-- 商品标题-->
                            <div class="pro_title">{{product.productName}}</div>
                            <div class="amount" v-if="product.count==product.remainingCount">¥{{product.totalPrice/100}}</div>
                            <div class="amount" v-else>¥{{product.singlePrice*product.count/100}}</div>
                        </div>
                        <div class="info_num">
                            <!-- 商品数量-->
                            <subtractors :count="product.count" :max="product.remainingCount" :id="index" @updateCount="countUpdate"></subtractors>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
    </div>
    <!-- 提交退款-->
    <div class="edit_footer" v-if="products.length > 0">
        <div class="check_all" @click="selectAll()">
            <checkBox :isChoose="select" />
            <span>全选</span>
        </div>
        <button class="apply primary-btn" @tap="editApply()">提交</button>
    </div>
  </div>
</template>
<script>
import { mapActions } from 'vuex'
import { $ } from "@/utils/index"
import imgApi from "@/utils/imgApi"
import checkBox from "./components/checkbox"
import subtractors from "./components/subtractor";

export default {
  data () {
    return {
      chooseIcon: imgApi.getRes('shoppingCart', 'choose'),
      select: false,
      orderId: '',
      editProductInfo: '',
      productInfoList:[],
      products: []
    }
  },
  computed:{
    getSelect(){ //判断是否全选
        let selected = true;
        let products = this.products;
        for(var i=0; i<products.length; i++){
            if(!products[i].checked){
                selected = false;
            }
        }
        return selected
    }
  },
  components:{
    checkBox,
    subtractors
  },
  methods: {
    ...mapActions('modOrderRefund',['editListAction']),
    // 获取订单商品
    getOrderProduct: function(){
        let data = {
            orderId: this.$router.getPrev().vm.orderId
        }
        this.editListAction({data}).then((data)=>{
            this.products = data.productList
            this.products.forEach((em,index)=>{
                let orderProductId = em.orderProductId
                this.products[index].checked = false;
                this.products[index].count = this.products[index].remainingCount;
                this.editProductInfo.forEach((em1,index1)=>{
                    let editOrderProductId = em1.orderProductId;
                    let editCount = em1.selectedCount;
                    if(editOrderProductId == orderProductId){
                        this.products[index].checked = true;
                        this.products[index].count = editCount;
                    }
                })
            })
            this.select = this.getSelect;
        })
    },
    // 选择商品
    selectItem: function(product, index){
        product.checked = !product.checked;
        this.$set(this.products, index, product);
        this.select = this.getSelect;
    },
    // 全选商品
    selectAll: function(){
        let products = this.products;
        this.select = !this.select;
        for(var i=0; i<products.length; i++){
            products[i].checked = this.select;
        }
    },
    editApply: function(){
        this.getApplyUrl();
        //let url = this.getApplyUrl();
        let len = this.productInfoList.length;
        if(len == 0){
            this.$wxComps.toast('请选择您要退款的商品');
            return false;
        }else{  
            this.$router.getPrev().vm.getRefundData();         
            this.$router.back()
            //this.$router.push({url:url})
        }
    },
    getApplyUrl: function(){
        var url = '/pages/order/refund/apply/main';
        this.productInfoList = []
        for(var i=0; i<this.products.length; i++){
            var orderProductId = this.products[i].orderProductId;
            var count = this.products[i].count;
            var checked = this.products[i].checked;
            if(checked){
                this.productInfoList.push({
                    orderProductId: orderProductId,
                    selectedCount: count
                });
            }
        }
        this.$router.getPrev().vm.paramsProductInfo = this.productInfoList
        //console.log(this.$router.getPrev())
        //console.log(this.$router.getPrev().vm.paramsProductInfo,333)
        //url += '?productInfo='+ (JSON.stringify(this.productInfoList));
        //return url
    },
    countUpdate(count,id){ 
      let product = this.products[id]
      product.count = count
      if(count > product.remainingCount){
        product.count = product.remainingCount
      }
      this.$set(this.products, id, product);
    }
  },
  onLoad(option){
    Object.assign(this.$data, this.$options.data())
    //console.log(this.$router.getPrev().vm,11111)
    //let editProductInfo = this.$root.$mp.query.editProductInfo;
    //console.log(editProductInfo)
    this.editProductInfo = this.$router.getPrev().vm.productInfo
    //console.log(typeof this.editProductInfo)
    //this.editProductInfo = JSON.parse(editProductInfo);
    this.getOrderProduct()
  },
  created () {
  }
}
</script>

<style scoped lang="scss">
.container{
  background: $lightWhiteBase;
}
.refund_products{
    padding-bottom: 65px;
}
.pro_item {
  display: flex;
  align-items: center;
  padding: 15px 12px;
  background: #fff;
  border-bottom: 1px solid #f0f0f0;
    &:last-child {
        border-bottom: none; 
    }
   .checkbox {
        flex: none;
    } 
    .pro_detail {
        display: flex;
        flex: 1;
        margin-left: 12px; 
    }
    .pro_photo {
        display: flex;
        flex: none;
        width: 60px;
        height: 60px;
        margin-right: 10px; 
        img {
          /* position: absolute; */
          width: 100%;
          height: 100%;
          /* top: 50%;
          transform: translateY(-50%); */
        }
    }
    .pro_mes {
        display: flex;
        flex: 1;
        justify-content: space-between; 
        .info_top {
            display: flex;
            flex: 1;
            flex-direction: column;
            justify-content: space-between; 
        }
        .info_top {
            display: flex; 
            color: #333;
            .pro_title {
              font-size: 16px;
              line-height: 22px;
              height: 44px;
              margin-right: 5px;
              overflow: hidden; 
            }
            .amount {
                font-size: 12px;
            }
        }
        .info_num {
            display: flex;
            flex: none;
             align-items: center; 
        }
    }
}
.pro_num {
    display: flex;
    border: 1PX solid #e0e0e0; 
    .item {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 28px;
        height: 25px; 
        i {
          color: #979797;
          font-size: 16px;
          font-style: normal;
          line-height: 12px; 
        }
    }
    .num {
      display: flex;
      color: #000;
      font-size: 14px;
      width: 35px;
      height: 25px;
      line-height: 25px;
      text-align: center;
      border: none;
      border-radius: 0;
      border-left: 1PX solid #e0e0e0;
      border-right: 1PX solid #e0e0e0; 
    }
}

/* 提交修改 */
.edit_footer {
    position: fixed;
    bottom: 0;
    left: 0;
    z-index: 20;
    width: 100%;
    height: 55px;
    box-sizing: border-box;
    padding: 0 10px;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between; 
    border-top: 1px solid #eee;
    .check_all {
        display:flex;
        align-items:center;
        span:last-child{
            color: #333;
            font-size: 14px;
            margin-left: 10px; 
        }

    } 
    .apply {
        width: 115px;
        height: 38px;
    }
} 
</style>
