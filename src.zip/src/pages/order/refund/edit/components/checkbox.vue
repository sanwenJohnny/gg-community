<template>
    <div class="checkbox" :class="{checked: isChoose}">
        <img mode="widthFix" :src="chooseIcon" v-show="isChoose">
    </div>
</template>
<script>
import imgApi from "@/utils/imgApi"

export default {
  data () {
    return {
      chooseIcon: imgApi.getRes('shoppingCart', 'choose'),
    }
  },
  props:{
    isChoose:Boolean
  },
  computed:{
  },
  methods: {}
}
</script>

<style scoped lang="scss">
.checkbox{
    display: inline-block;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    border: 1px solid #c0c0c0;
    img{
        width: 100%;
    }
}
.checked{
    border-color: transparent;
}
</style>
