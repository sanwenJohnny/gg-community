<template>
    <div class="b_all counter">
        <!-- 减 -->
        <div class="item b_right col-333" :class="{'col-eee':count==1}" @tap="minus">-</div>
        <!-- 数量 -->
        <input type="number" class="num" v-model="count" pattern="[0-9]*" @blur="checkNum"/>
        <!-- 加 -->
        <div class="item b_left col-333" :class="{'col-eee':count==max}" @tap="add">+</div>
    </div>
</template>

<script>
export default {
  name: "subtractor",
  props: {
    count:'', 
    max:'', 
    id:''
  },
  data() {
    return {}
  },
  methods: {
    /**
     * 验证商品数量
     * 限制商品数量为正整数
     */
    checkNum(){
        let reg = /^[1-9]\d*$/gi;
        if(!reg.test(this.count)){
            this.count = 1;
        }
        this.$emit("updateCount", this.count, this.id);
    },
    minus() {
      if(this.count - 1 < 1) {
        return;
      }
      this.count--;
      this.$emit("updateCount", this.count, this.id);
    },
    add() {
      if(this.count < this.max){
        this.count += 1;
        this.$emit("updateCount", this.count, this.id);
      }
    }
  },
  onShow(){
  }
};
</script>

<style scoped lang="scss">
.col-333{
  color: #333;
}
.col-eee{
  color: #eee;
}
.counter {
    display: flex;
    align-items: center;
    text-align: center;
    .item {
        width: 26px;
        height: 24px; 
        line-height: 24px;
        font-size: 20px;
        z-index:10;
    }
    .num {
      width: 33px;
      height: 24px;
      line-height: 24px;
      font-size: 14px;
      border: none;
      border-radius: 0;
    }
}
</style>
