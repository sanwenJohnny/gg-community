<template>
  <div class="container bg-f0">
    <ul class="product-info">
      <li @tap="trunDetail(productInfo.refundNumber)">
        <i class="product-tu" :style="{backgroundImage:'url('+productInfo.productImage+')'}"></i>
        <span>
          <h2 class="mb-5" v-text="productInfo.productName"></h2>
          <i class="f-12">退款金额: &yen;{{productInfo.refundPrice/100}}</i>
        </span>
        <em class="col-c2">x{{productInfo.refundCount}}</em>
      </li>
    </ul>
  </div>
</template>
<script>
export default {
  data() {
    return {
     productInfo: ''
    };
  },
  props: ['listData'],
  computed: {},
  methods: {
    trunDetail(id) {
      this.$router.push({
        url:"/pages/order/refund/detail/main?refundNumber=" + id
      })
    }
  },
  mounted() {
    this.productInfo = this.listData
  }
};
</script>

<style scoped lang="scss">
@import "../../../../css/mixins";
@import "../../../../css/common";

.col-c2 {
  color: #c2c2c2;
}
.f-12 {
  font-size: 12px;
}
.mb-5 {
  margin-bottom: 5px;
}
.product-info {
  @extend .b_top;
  a,
  i,
  em,
  span {
    display: inline-block;
  }
  li {
    display: flex;
    padding: 10px 0;
    > span {
      flex: 1;
      margin: 0 10px;
      h2 {
        @include Ellipsis(2);
      }
    }
    > em {
      @extend .right;
    }
  }
  .product-tu {
    width: 62px;
    height: 62px;
    @include Background("", cover);
  }
}
</style>
