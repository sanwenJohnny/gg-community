<template>
  <div class="container bg-f0" v-if="isLoad">
    <!-- 退款列表 -->
    <scroll-view class="scroll-wrapper" :scroll-y="true" @scrolltolower="handleLoadMore" v-if="refundList.length > 0">
      <section class="refund-list" v-for="(list,idx) in refundList" :key="idx">
        <h1 class="col-74" v-text="list.applyTime"></h1>
        <Product :list-data = list  v-if="!isRequest"/>
        <p class="b_top" v-text="list.refundStatusStr"></p>
      </section>
      <p class="list-loading t-c col-fff" v-if="isRequest">努力加载中…</p>
      <p class="t-c list-end" v-if="listEnd">已显示全部内容</p>
    </scroll-view>
    <!-- <p v-else class="t-c list-error">暂无数据</p> -->
    <empty :image="emptyImg" message="您还没有相关售后订单" v-else></empty>
    <load-more v-if="loading"></load-more>
  </div>
</template>
<script>
import { $ } from "@/utils/index";
import { mapActions } from 'vuex';
import loadMore from '@/components/loadMore';
import Product from '../components/product';
import utils from 'u'
import empty from 'c/empty'
import imgApi from 'u/imgApi'

export default {
  data() {
    return {
      page: 1,
      pageSize: 10,
      total: 0,
      loading: false,
      isLoad: false,
      listEnd: false,
      isRequest: false,
      refundList: [],
      emptyImg: imgApi.getRes('empty', 'order'),
    };
  },
  computed: {},
  components: {
    loadMore,
    Product,
    empty
  },
  methods: {
    ...mapActions('modOrderRefund',['refundListAction']),
    getList(type) {
      this.isRequest = true
      const _params = {
        page: this.page,
        pageSize: this.pageSize
      }
      this.refundListAction({data:_params}).then(res=> {
        this.isLoad = true
        this.isRequest = false
        utils.loaded()
        if(type == 1) {
          this.refundList = this.refundList.concat(res.productList)
        }else {
          this.refundList = res.productList || []
          this.total = res.total
        }
      })
    },
    handleLoadMore() { 
      if(this.page*this.pageSize < this.total) {
        this.page += 1
        this.listEnd = false
        this.getList(1)
      } else {
        this.listEnd = true
      }
    },
  },
  onShow() {
    utils.loading()
    this.page = 1
    this.getList()
  }
};
</script>

<style scoped lang="scss">
@import "../../../../css/mixins";
@import "../../../../css/common";
.bg-f0 {
  background: #f0f0f0;
}
.p-10 {
  padding: 0 10px;
}
.col-74 {
  color: #747474;
}
.col-c2 {
  color: #c2c2c2;
}
.f-12 {
  font-size: 12px;
}
.refund-list {
  @extend .p-10;
  margin-bottom: 10px;
  background: #fff;
  color: #333;

  h1,
  > p {
    @include Height(44);
  }
}
.scroll-wrapper{
  height: 100%;
}
</style>
