<template>
 <div class="price_view">
   <span v-if="isMinus">-</span><span class="unit">￥</span><span>90</span>
 </div>
</template>

<script>
export default {
  name: "priceView",
  props:['isMinus'],
  data() {
    return {};
  }
};
</script>

<style scoped lang="scss">
.price_view {
  .unit {
    margin-right: 1px;
  }
}
</style>
