<template>
  <div class="f_l">
    <div class="f_title icon" :class="{hide: isRequired == 0}" :style="{width: iconWidth, marginRight: space}">*</div>
    <!-- 文字 -->
    <div v-if="text" class="f_title text" :style="{fontSize: textFontSize, height: textHeight, lineHeight: textHeight}">
      {{text}}
    </div>
  </div>
</template>

<script>
export default {
  name: 'requiredInfo',
  props: {
    text: String,
    iconWidth: {
      type: String,
      default: '14px'
    },
    textFontSize: {
      type: String,
      default: '14px'
    },
    textHeight: {
      type: String,
      default: '14px'
    },
    space: {
      type: String,
      default: '10px'
    },
    isRequired: {
      type: Number,
      default: 1
    }
  },
  data() {
    return {}
  }
}
</script>

<style scoped lang="scss">
.f_l {
  display: flex;
  align-items: center;
  height: 100%;
  .icon {
    width: 14px;
    height: 100%;
    display: flex !important;
    align-items: center;
    color: #ff0000;
    transform: translateY(3px);
  }
  .icon.hide {
    opacity: 0;
  }
  //   文字
  .text {
    font-size: 14px;
    height: 14px;
    // transform: translateY(-2px);
  }
}
</style>
