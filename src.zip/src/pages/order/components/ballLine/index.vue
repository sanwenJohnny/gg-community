<template>
    <div class="ballLine">
        <div class="ball" :class="{curr: isCurr}">
            <div class="inner"></div>
        </div>
        <div class="line"></div>
    </div>
</template>

<script>
export default {
  name: 'ballLine',
  props: ['isCurr'],
  data() {
    return {}
  }
}
</script>

<style scoped lang="scss">
.ballLine {
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100%;
}

.ball {
  width: 9px;
  height: 9px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  background: #eeeeee;
  .inner {
    display: none;
  }
  &.curr {
    width: 15px;
    height: 15px;
    border: 1px solid #7cd79d;
    background: #fff;
  }
  &.curr {
    .inner {
      display: block;
      width: 9px;
      height: 9px;
      border-radius: 50%;
      background: #5ab37a;
    }
  }
}

.line {
  width: 1px;
  flex: 1;
  background: #eeeeee;
}
</style>
