<template>
  <div class="wrap b_top good-item" :class="{subline: subline == 1}" @click="clickItem">
    <!-- 商品图 -->
    <div class="thumbnail" :style="{width: thumbSize, height: thumbSize}">
      <img mode="widthFix" :src="good[fieldMap.thumb]">
    </div>
    <!-- 商品详情 -->
    <div class="detail">
      <!-- 标题 -->
      <div class="f_title title">{{good[fieldMap.title]}}</div>
      <!-- 规格 -->
      <div class="spec" v-if="good.spec">{{good.spec}}</div>
    </div>
    <!-- 价格和数量 -->
    <div class="p_n">
      <!-- 价格 -->
      <div class="f_title price">￥{{good[fieldMap.price]}}</div>
      <!-- 数量 -->
      <div class="f_assist count">x{{good[fieldMap.count]}}</div>
      <!-- 状态信息 -->
      <div class="f_sub status" v-if="shouldShowStatus">{{good.refundStatusDesc}}</div>
      <!-- 退款按钮 -->
      <div class="f_sub b_all status refund" data-role="refund" v-if="shouldShowButton" @click="refund">退款</div>
    </div>
  </div>
</template>

<script>
const buttonTypes = {
  refund: true
}
export default {
  name: 'goodItem',
  props: {
    // 商品信息
    good: {
      type: Object,
      default: {}
    },
    // 缩略图大小
    thumbSize: {
      type: String,
      default: '62px'
    },
    // 商品信息字段映射
    fieldMap: {
      type: Object,
      default: {
        title: 'productName',
        thumb: 'productImg',
        price: 'salePrice',
        count: 'productCount'
      }
    },
    // 是否显示状态 0 否 / 1 是
    showStatus: {
      type: Number,
      default: 0
    },
    // 顶部线右边空出10px
    subline: {
      type: Number,
       default: 0
    }
  },
  data() {
    return {}
  },
  computed: {
    goodStatus() {
      if (this.good.canRefund != 1) {
      }
    },
    shouldShowStatus() {
      return this.good.canRefund == 0 && this.good.refundStatus != 0
    },
    shouldShowButton() {
      return this.showStatus == 1 && this.good.canRefund == 1
    }
  },
  methods: {
    clickItem(e) {
      if (buttonTypes[e.target.dataset.role]) {
        return
      }
      this.$emit('clickItem', this.good)
    },
    refund(e) {
      this.$emit('refund', this.good)
      return false
    }
  }
}
</script>

<style scoped lang="scss">
.good-item {
  display: flex;
  justify-content: space-between;
  padding-top: 12px;
  padding-bottom: 12px;
  overflow: hidden;
  &.b_top.subline::after {
    transform: translateX(10px) scale(0.25);
  }
  /* 商品图 */
  .thumbnail {
    position: relative;
    overflow: hidden;
    margin-right: 8px;
    img {
      position: absolute;
      width: 100%;
      left: 0;
      top: 50%;
      transform: translateY(-50%);
    }
  }

  /* 商品详情 */
  .detail {
    flex: 1;
    // 商品标题
    .title {
      line-height: 16px;
      font-family: PingFangSC-Regular;
      font-weight: normal;
    }
  }

  /* 价格和数量 */
  .p_n {
    margin-left: 8px;
    text-align: right;
    position: relative;
    // 价格
    .price {
      margin-bottom: 4px;
      font-family: PingFangSC-Regular;
    }
    // 状态
    .status {
      color: #ff0000;
      position: absolute;
      right: 0;
      bottom: 0;
      width: 80px;
      text-align: right;
      transform: translateY(6px);
    }
    // 退款按钮
    .status.refund {
      border-radius: 57px;
      padding: 0;
      background: #fff;
      color: #747474;
      width: 64px;
      height: 24px;
      line-height: 24px;
      text-align: center;
      &::after {
        border-color: #747474;
        border-radius: 57px;
      }
    }
  }
}
</style>
