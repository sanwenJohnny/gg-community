<template>
  <div class="wrap log">
    <div class="timeline" v-for="(track, i) in trackingList" :key="i">
      <div class="line_wrap">
        <ball-line :isCurr="i == 0" />
      </div>
      <div class="info">
        <div class="f_title text">{{track.info}}</div>
        <div class="f_sub time">{{track.time}}</div>
      </div>
    </div>
  </div>
</template>

<script>
import imgApi from 'u/imgApi'
import ballLine from 'ordc/ballLine'
export default {
  ivs: 'modLogistics',
  name: 'log',
  data() {
    return {}
  },
  computed: {
    trackingList() {
      return this.pageData.trackingList
    }
  },
  components: {
    'ball-line': ballLine
  }
}
</script>

<style scoped lang="scss">
.log {
  padding-top: 16px;
}
.timeline {
  display: flex;
  //   padding-top: 16px;
}
.line_wrap {
  width: 15px;
  margin-right: 14px;
}
.info {
  flex: 1;
  min-height: 40px;
  padding-bottom: 16px;
  .text {
    color: #5ab37a;
    height: auto;
    line-height: 20px;
  }
  .time {
    font-size: 14px;
    margin-top: 6px;
  }
}

.icon {
  width: 10px;
  margin-left: 26px;
  display: flex;
  align-items: center;
  img {
    width: 100%;
  }
}
</style>
