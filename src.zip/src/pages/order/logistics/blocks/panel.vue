<template>
  <div class="wrap detail_panel">
    <div class="wrapper">
      {{pageData.logisticsCompany}}
    </div>
    <div class="f_title serial">
      <div>订单编号: {{pageData.logisticsNumber}}</div>
    </div>
    <div class="f_title time">付款时间: {{payTime}}</div>
  </div>
</template>

<script>
export default {
  ivs: 'modLogistics',
  name: 'panel',
  data() {
    return {
      payTime: ''
    }
  },
  mounted() {
    const query = this.q()
    this.payTime = query.time
  },
  computed: {
    logInfo() {
      return this.pageData.logisticsInfo || {}
    }
  }
}
</script>

<style scoped lang="scss">
.detail_panel {
  background: #fff;
  box-sizing: border-box;
  padding-top: 13px;
  padding-bottom: 10px;
  color: #333;
  margin-bottom: 8px;
}

.wrapper {
  height: 18.5px;
  margin-bottom: 21px;
}

.serial,
.time {
  color: #333;
  font-family: PingFangSC-Regular;
  font-weight: normal;
}
.time.hide {
  opacity: 0;
}
.serial {
  margin-bottom: 8px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.copy {
  border-radius: 57px;
  background: transparent;
  color: #fff;
  width: 48px;
}

.copy::after {
  border-radius: 57px;
  border-color: #fff;
}
</style>
