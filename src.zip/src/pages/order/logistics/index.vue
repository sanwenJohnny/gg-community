<template>
  <div>
    <panel/>
    <log/>
  </div>
</template>

<script>

import utils from 'u'
import db from 'ss'
// blocks
import panel from './blocks/panel'
import log from './blocks/log'

export default {
  ivs: 'modLogistics',
  data() {
    return {}
  },
  onLoad() {
    utils.loading()
  },
  onShow() {
    const query = this.q()
    this.resetPageDataAction({
      params: {
        shipmentCode: query.shipmentCode
      }
    }).then(res => {
      utils.loaded()
    })
  },
  components: {
    panel,
    log
  }
}
</script>

<style scoped lang="scss">
</style>
