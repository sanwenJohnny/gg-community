<template>
  <div>
    <!-- 占位符 -->
    <div class="placeholder"></div>
    <!-- 导航 -->
    <my-nav/>
    <div v-show="inited && !isEmpty">
      <!-- 订单列表 -->
      <orders/>
      <!-- 底部提示 -->
      <my-foot/>
    </div>
    <empty :image="emptyImg" v-if="inited && isEmpty">您还没有相关的订单</empty>
  </div>
</template>

<script>
import api from 'a/order/my'
import utils from 'u'
import imgApi from 'u/imgApi'

// blocks
import myNav from './blocks/myNav'
import orders from './blocks/orders'
import myFoot from './blocks/myFoot'
import empty from 'c/empty'
export default {
  ivs: 'modMyOrder',
  data() {
    return {
      loaded: false,
      emptyImg: imgApi.getRes('empty', 'order')
    }
  },
  computed: {
    orderList() {
      return this.pageData.list
    },
    isEmpty() {
      return !this.orderList || this.orderList.length == 0
    }
  },
  onLoad() {
    if (!this.inited) {
      utils.loading()
    }
  },
  onShow() {
    if (this.loaded) {
      utils.loading()
      this.setInitedAction(false)
    }
    let status = this.currStatus
    this.setCurrStatusAction(status)
    this.setPageNumAction(1)
    this.setHasMoreAction(true)
    this.resetPageDataAction({
      params: {
        status,
        page: this.pageNum
      }
    }).then(res => {
      setTimeout(() => {
        if (!this.inited) {
          utils.loaded()
          this.loaded = true
        }
        this.setInitedAction(true)
      }, 100)
    })
  },
  onReachBottom() {
    if (this.hasMore) {
      this.setPageNumAction(this.pageNum + 1)
      this.getPageDataAction({
        params: {
          status: this.currStatus,
          page: this.pageNum
        }
      }).then(res => {
        setTimeout(() => {
          this.setOrderListAction(res.list)
        }, 1000)
      })
    }
  },
  components: {
    'my-nav': myNav,
    orders,
    'my-foot': myFoot,
    empty
  },
  watch: {
    orderList() {
      this.setTotalAction(this.pageData.total)
      if (this.orderList.length == this.total) {
        this.setHasMoreAction(false)
      }
    }
  }
}
</script>

<style scoped lang="scss">
.placeholder {
  width: 100%;
  height: 55px;
}
</style>
