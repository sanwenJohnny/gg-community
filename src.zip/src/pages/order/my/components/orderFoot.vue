<template>
  <div class="wrap b_top order_foot">
    <!-- 总计 -->
    <div class="stat">
      <div class="wrapper">
        <!-- <div class="f_sub content">会员已减: ￥{{order.couponPrice}}</div> -->
        <div class="f_title content total">总计￥{{order.realPrice}}</div>
      </div>
    </div>
    <!-- 按钮 -->
    <div class="buttons" v-if="buttonGroup.length > 0">
      <div class="group">
        <button v-for="(button,i) in buttonGroup" :key="i" :class="[button.clazz]" @click="onClick(button.name)" v-if="button">
          <span>{{button.name}}</span>
          <count-down v-if="isCountDown && button.countDown && !isCountEnd" :id="i" :restTime="formatTime(statusInfo.endTime)" @countEnd="countEnd" />
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import utils from 'u'
import { $ } from 'u'
import path from 'p'
import buttonInfo from '../static/buttonInfo'
import serverKeyButtonMap from '../static/serverKeyButtonMap'
import serverKey_buttonGroupIndex from '../static/serverKey_buttonGroupIndex'
import countDown from 'c/countDown'
export default {
  ivs: 'modMyOrder',
  name: 'orderFoot',
  props: ['order'],
  data() {
    return {
      buttonGroup: [],
      isCountEnd: false
    }
  },
  computed: {
    statusInfo() {
      return this.order.orderStatusInfo
    },
    isCountDown() {
      return (
        this.statusInfo.canPay === 1 &&
        String(this.statusInfo.endTime).indexOf('-') == -1
      )
    }
  },
  methods: {
    // 倒计时时间
    formatTime(time) {
      time = String(time).replace('-', '')
      time *= 1000
      return time
    },
    // 点击单个订单底部按钮
    onClick(btnName) {
      switch (btnName) {
        case '去付款':
          this.payAction({
            params: {
              batchNumbers: [this.order.batchNumber + '']
            }
          }).then(res => {
            if (res) {
              res.package = res.pack
              $(wx.requestPayment, {
                ...res
              })
                .then(res => {
                  this.setCurrStatusAction(3)
                  this.resetPageDataAction({
                    params: {
                      status: 3
                    }
                  })
                })
                .catch(ret => {
                  this.setCurrStatusAction(1)
                  this.resetPageDataAction({
                    params: {
                      status: 1
                    }
                  })
                })
            }
          })
          break
        case '取消':
          $(wx.showModal, {
            content: '确定取消订单'
          }).then(res => {
            if (res.confirm) {
              this.setPageNumAction(1)
              this.setHasMoreAction(true)
              this.cancelAction({
                params: {
                  batchNumber: this.order.batchNumber
                }
              }).then(res => {
                this.resetPageDataAction({
                  params: {
                    page: this.pageNum
                  }
                })
              })
            }
          })

          break
        case '确认收货':
          $(wx.showModal, {
            content: '是否确认收货'
          }).then(res => {
            if (res.confirm) {
              this.setPageNumAction(1)
              this.setHasMoreAction(true)
              this.sureAction({
                params: {
                  orderId: this.order.orderId,
                  page: this.pageNum
                }
              }).then(res => {
                this.resetPageDataAction({
                  params: {
                    page: this.pageNum
                  }
                })
              })
            }
          })
          break
        case '查看物流':
          utils.go(path.ORDER_LOGISTICS + `?shipmentCode=${this.order.shipmentCode}&time=${this.order.payTime}`)
          break
        default:
          break
      }
    },
    update() {
      let list = []
      for (let key in this.statusInfo) {
        if (serverKeyButtonMap[key] && this.statusInfo[key] === 1) {
          let index = serverKey_buttonGroupIndex[key]
          list[index] = buttonInfo[serverKeyButtonMap[key]]
        }
      }
      list.filter(button => button)
      this.buttonGroup = list
    },
    // 倒计时结束
    countEnd(id) {
      this.isCountEnd = true
      this.resetPageDataAction()
    }
  },
  mounted() {
    this.update()
  },
  components: {
    'count-down': countDown
  },
  watch: {
    statusInfo() {
      this.update()
    }
  }
}
</script>

<style scoped lang="scss">
.order_foot {
  padding-bottom: 14px;
  padding-top: 13px;
  &.b_top::after {
    transform: translateX(10px) scale(0.25);
  }
  // 统计
  .stat {
    display: flex;
    flex-direction: row-reverse;
    .wrapper {
      display: flex;
      align-items: center;
      .content {
        margin-left: 15px;
        &.total {
          @include Font('', 16, '');
        }
      }
    }
  }
  // 按钮
  .buttons {
    display: flex;
    flex-direction: row-reverse;
    margin-top: 12px;
    .group {
      display: flex;
      button {
        height: 30px;
        border-radius: 32px;
        margin-left: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      button::after {
        border-radius: 0;
      }

      // 取消
      .btn_cancel,
      .btn_look {
        width: 64px;
        background: #fff;
        color: $lightBlackBase;
        font-size: 14px;
        // border: 1px solid #c0c0c0;
      }
      .btn_cancel::after,
      .btn_look::after {
        border-radius: 32px;
        border-color: $lightBlackBase;
      }

      // 付款
      .btn_pay {
        height: 30px;
        width: 104px;
        font-size: 14px;
        color: #333;
      }
      .btn_pay::after {
        border: none;
      }

      // 查看物流&确认收货
      .btn_sure,
      .btn_look {
        width: 82px !important;
      }
      .btn_sure::after,
      .btn_look::after {
        border: none;
      }

      .btn_sure {
        background: #ffe900;
        color: #333;
        border: none;
      }
    }
  }
}
</style>
