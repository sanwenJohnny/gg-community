<template>
  <div class="order_nav">
    <!-- tab -->
    <div class="tab" v-for="(name,i) in tabs" :key="i" :class="{active: statusNameMap[currStatus] == indexNameMap[i]}" @click="changeTab(i)">
      <!-- 字段 -->
      <div class="f_sub text">{{name}}</div>
      <!-- 下划线 -->
      <div class="underline"></div>
    </div>
  </div>
</template>

<script>
import api from 'a/order/my'
// static
import statusNameMap from '../static/statusNameMap'
import indexNameMap from '../static/indexNameMap'
import indexStatusMap from '../static/indexStatusMap'

export default {
  ivs: 'modMyOrder',
  name: 'myNav',
  data() {
    return {
      tabs: ['全部', '待付款', '待发货', '配送中', '交易成功'],
      statusNameMap,
      indexNameMap
    }
  },
  methods: {
    changeTab(i) {
      this.setPageNumAction(1)
      this.setHasMoreAction(true)
      const status = indexStatusMap[i]
      this.setCurrStatusAction(status)
      this.resetPageDataAction({
        params: {
          status,
          page: this.pageNum
        }
      })
    }
  }
}
</script>

<style scoped lang="scss">
.order_nav {
  position: fixed;
  top: 0;
  width: 100%;
  z-index: 999;
  display: flex;
  justify-content: space-around;
  background: #fff;
  padding-top: 16px;
  padding-bottom: 8px;
  // margin-bottom: 8px;
  // tab
  .tab {
    // 选中
    &.active {
      .text {
        color: #000;
      }
      .underline {
        opacity: 1;
      }
    }
    // 文字
    .text {
      font-size: 14px;
      margin-bottom: 6px;
      height: 17px;
    }
    // 下划线
    .underline {
      width: 100%;
      height: 2px;
      background: #000;
      opacity: 0;
    }
  }
}
</style>
