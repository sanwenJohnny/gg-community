<template>
  <div class="orders" v-if="orderList && orderList.length > 0">
    <!-- 订单 -->
    <div class="order" v-for="(order, i) in orderList" :key="i">
      <!-- 头信息 -->
      <div class="wrap head">
        <!-- 状态 -->
        <div class="f_theme b_right status">{{order.orderStatusInfo.orderStatusDesc}}</div>
        <!-- 时间 -->
        <div class="f_sub time">{{order.createTime}}</div>
      </div>

      <!-- 商品列表 -->
      <div class="goods">
        <!-- 商品 -->
        <good-item v-for="(good, j) in order.productDTOList" :key="j" thumbSize="62px" showStatus=1 :good="good" @refund="refund" @clickItem="goDetail" :subline="j==0?0:1"/>
      </div>

      <!-- foot -->
      <order-foot :order="order" />
    </div>
  </div>
</template>

<script>
import path from 'p'
import utils from 'u'
import goodItem from 'ordc/goodItem'
import orderFoot from '../components/orderFoot'
export default {
  ivs: 'modMyOrder',
  name: 'orders',
  data() {
    return {}
  },
  computed: {
    orderList() {
      return this.pageData.list
    }
  },
  methods: {
    // 跳转订单详情
    goDetail(good) {
      utils.go(path.ORDER_DETAIL + '?orderId=' + good.orderId)
    },
    // 跳转退款
    refund(good) {
      utils.go(
        path.ORDER_REFUND_APPLY + `?orderProductId=${good.orderProductId}`
      )
    }
  },
  components: {
    'order-foot': orderFoot,
    'good-item': goodItem
  }
}
</script>

<style scoped lang="scss">
.orders {
  // 单个订单
  .order {
    margin-bottom: 8px;
    // 头信息
    .head {
      display: flex;
      // 状态
      .status {
        padding-right: 10px;
        height: 34px;
        line-height: 34px;
        color: #ff6052;
        font-size: 14px;
      }
      // 时间
      .time {
        font-size: 14px;
        padding-left: 10px;
        height: 34px;
        line-height: 34px;
        color: #c2c2c2;
      }
    }
  }
}
</style>
