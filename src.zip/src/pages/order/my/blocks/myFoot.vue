<template>
    <div class="f_sub foot">
        <div v-if="hasMore">正在载入更多...</div>
        <div v-else>已经到底啦~</div>
    </div>
</template>

<script>

export default {
  ivs: 'modMyOrder',
  name: 'myFoot',
  data() {
    return {}
  }
}
</script>

<style scoped lang="scss">
.foot {
  color: #c0c0c0;
  height: 73px;
  line-height: 73px;
  text-align: center;
}
</style>
