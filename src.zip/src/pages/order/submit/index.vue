<template>
  <div class="page" :style="{paddingBottom:xStyle}">
    <!-- 提示 -->
    <hint/>

    <!-- 选择收货地址 -->
    <addr-choose/>

    <!-- 地址 -->
    <addr/>

    <!-- 提货人预留信息 -->
    <buyer-info/>

    <!-- 订单列表 -->
    <orders/>

    <!-- 优惠减免 -->
    <discount/>

    <!-- 底部固定bar -->
    <foot-bar/>

  </div>
</template>

<script>
import api from 'a/order/submit'

import utils from 'u'
import db from 'ss'
// blocks
import hint from './blocks/hint'
import addrChoose from './blocks/addrChoose'
import addr from './blocks/addr'
import buyerInfo from './blocks/buyerInfo'
import orders from './blocks/orders'
import discount from './blocks/discount'
import footbar from './blocks/footbar'

export default {
  ivs: {
    id: 'orderSubmit',
    mods: [
      'modOrderSubmit',
      {
        mod: 'modAddress',
        state: ['sOrderAddress', 'sAgantAddress'],
        actions: ['setAgentAddressAction', 'setOrderAddressAction']
      },
      {
        mod: 'modMyOrder',
        actions: ['payAction', 'setCurrStatusAction']
      }
    ]
  },
  data() {
    return {
      xStyle: '64px'
    }
  },
  created() {
    if (this.isx) {
      this.xStyle = '98px'
    }
  },
  onLoad() {
    utils.loading()
  },
  onShow() {
    console.log(this.useCoin)
    const query = this.q()
    let skuCountList = []
    if (query.skus) {
      // from shoppingCart
      skuCountList = JSON.parse(query.skus)
    } else if (query.count) {
      // from goodDetail
      skuCountList.push({
        count: query.count,
        skuId: query.productId
      })
    }
    this.setSkuCountListAction(skuCountList)
    const dbData = utils.get(db.COMMUNITY_INFO) || {}
    const params = {
      ...dbData,
      skuCountList
    }

    // 从选择地址返回
    if (this.lockUseCoin) {
      // 保留进入地址之前的G币用户选择
      if (this.useCoin !== undefined) {
        params.useCoin = this.useCoin
      }
      // 接口传入地址信息
      if (this.sOrderAddress.addressId) {
        params.addressId = this.sOrderAddress.addressId
      }
      if (this.sOrderAddress.addressType) {
        params.addressType = this.sOrderAddress.addressType
      }
    } else {
      // 正常进入
      // 清空之前的用户输入
      this.resetBuyerInfoAction({
        name: '',
        phone: '',
        note: ''
      })
    }

    this.resetPageDataAction({
      params,
      replaceOldParam: !this.lockUseCoin //覆盖老数据结构，防止传入残留的useCoin字段
    }).then(res => {
      let addrData = res.receiveAddress || {}
      let addressType, addressId
      if (addrData.defaultSelectAgent == 1) {
        //代收
        addressId = addrData.agentAddress && addrData.agentAddress.addressId
        addressType = 2
      } else {
        addressId = addrData.userAddress && addrData.userAddress.addressId
        addressType = 1
      }
      this.setOrderAddressAction({
        addressId,
        addressType
      })
      let preInfo = addrData.agentAddress
      if (preInfo) {
        this.resetBuyerInfoAction({
          name: preInfo.reservationFullName,
          phone: preInfo.reservationMobileNumber,
          note: preInfo.remark
        })
      }
      if (this.useCoin !== undefined) {
        this.setUseCoinAction(this.pageData.coin.showType == 2 ? 1 : 0)
      }
      utils.loaded()
    })
    if (this.lockUseCoin) {
      this.setLockUseCoinAction(false)
    }
  },
  components: {
    hint,
    'addr-choose': addrChoose,
    addr,
    'buyer-info': buyerInfo,
    orders,
    discount,
    'foot-bar': footbar
  }
}
</script>

<style scoped lang="scss">
.page {
  padding-bottom: 69px;
}
</style>
