<template>
  <div class="wrap choose" v-if="!addrInfo" @click="goAddr">
    <!-- icon和文字 -->
    <icon-text :iconSrc="localIcon" text="请选择收货地址" />
    <!-- 箭头 -->
    <icon-text :iconSrc="arrowIcon" iconWidth="10px" />
  </div>
</template>

<script>

// utils
import imgApi from 'u/imgApi'
import utils from 'u'
import path from 'p'
//components
import iconText from 'c/iconText'

export default {
  ivs: { use: 'orderSubmit' },  
  name: 'addrChoose',
  data() {
    return {
      localIcon: imgApi.getRes('orderSubmit', 'local'),
      arrowIcon: imgApi.getRes('orderSubmit', 'r_arrow')
    }
  },
  computed: {
    addrInfo() {
      return this.pageData.receiveAddress
    },
    agentData() {
      if (this.addrInfo) {
        return this.addrInfo.agentAddress
      } else {
        return {}
      }
    },
    hadAddr() {

    }
  },
  methods: {
    goAddr() {
      this.setAgentAddressAction(this.agentData)
      this.setLockUseCoinAction(true)
      utils.go(path.ORDER_ADDRESS)
    }
  },
  components: {
    'icon-text': iconText
  }
}
</script>

<style scoped lang="scss">
.choose {
  display: flex !important;
  height: 56px;
  justify-content: space-between;
  align-items: center;
  // margin-bottom: 9px;
  padding-left: 14px;
  // icon和文字
  .i_t {
    display: flex;
    align-items: center;
    height: 100%;
    // icon
    .icon {
      width: 16px;
      height: 100%;
      display: flex;
      align-items: center;
      img {
        width: 100%;
      }
    }
    // 文字
    .text {
      font-size: 16px;
      line-height: 56px;
      margin-left: 7px;
    }
  }
}
</style>
