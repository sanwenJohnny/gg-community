<template>
  <div class="wrap hint">
    <span class="f_sub" v-if="pageData.receiveAddress != null && useAgent">已享受免费代收服务,到货后请到代理点自提</span>
    <div class="noagent" v-else>
      <div class="f_sub">选择小区代理点，可享受免费代收服务。</div>
      <button class="collect" @click="collect" v-if="pageData.receiveAddress != null">免费代收</button>
    </div>
  </div>
</template>

<script>

export default {
  ivs: { use: 'orderSubmit' },  
  name: 'hint',
  data() {
    return {
      hasAddr: true
    }
  },
  computed: {
    addrData() {
      return this.pageData.receiveAddress || {}
    },
    useAgent() {
      return this.sOrderAddress.addressType === 2
    }
  },
  methods: {
    collect() {
      // let addressType, addressId
      // if (this.addrData.defaultSelectAgent == 1) {
      //   //代收
      //   addressId =
      //     this.addrData.agentAddress && this.addrData.agentAddress.addressId
      //   addressType = 2
      // } else {
      //   addressId =
      //     this.addrData.userAddress && this.addrData.userAddress.addressId
      //   addressType = 1
      // }
      this.setOrderAddressAction({
        addressId: this.addrData.agentAddress.addressId,
        addressType: 2
      })
    }
  }
}
</script>

<style scoped lang="scss">
.hint {
  height: 40px;
  background: $orangeBase;
  margin-bottom: 8px;
  display: flex;
  align-items: center;
  & .f_sub {
    color: $darkBlackBase;
  }
}

.noagent {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.collect {
  background: rgba(255, 255, 255, 0.8);
  border-radius: 12px;
  color: #4c2c00;
  width: 74px;
  height: 24px;
  font-size: 12px;
}

.collect::after {
  border: none;
  color: #4c2c00;
}
</style>
