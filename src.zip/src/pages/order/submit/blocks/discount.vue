<template>
  <div class="discount" v-if="coinData.maxCanUseCoin > 0">
    <!-- title -->
    <div class="wrap f_sub title">优惠减免</div>
    <!-- 会员减免 -->
    <!-- <div class="wrap b_top item vip">
      <div class="f_title">会员减免</div>
      <div class="f_sub val">立减￥{{pageData.memberDisCountShow}}</div>
    </div> -->
    <!-- G币抵现 -->
    <div class="wrap b_top item gb" v-if="coinData.showType != 1">
      <div class="f_title">G币抵现</div>
      <div class="f_sub val use">
        <div>可用G币数量：{{coinData.maxCanUseCoinShow}}</div>
        <switch class="switch" checked v-if="showCoinUse" @change="switchChange" />
        <switch class="switch" v-else @change="switchChange" />
      </div>
    </div>
  </div>
</template>

<script>
import utils from 'u'
import db from 'ss'
export default {
  ivs: { use: 'orderSubmit' },
  name: 'discount',
  data() {
    return {}
  },
  computed: {
    coinData() {
      return this.pageData.coin || {}
    },
    showCoinUse() {
      if (this.useCoin !== undefined) {
        return this.useCoin == 1
      } else {
        return this.coinData.showType == 2
      }
    }
  },
  methods: {
    switchChange(e) {
      const useCoin = e.mp.detail.value ? 1 : 0
      this.setUseCoinAction(useCoin)
      const dbData = utils.get(db.COMMUNITY_INFO) || {}
      this.resetPageDataAction({
        params: {
          ...dbData,
          skuCountList: this.skuCountList,
          useCoin
        }
      })
    }
  }
}
</script>

<style scoped lang="scss">
.title {
  height: 34px;
  line-height: 34px;
  font-size: 14px;
}
.discount {
  // items
  .item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 48px;
    line-height: 48px;
    // 右边
    .val {
      font-size: 14px;
    }
  }

  .item.gb {
    position: relative;
    padding-right: 3px;
    .use {
      display: flex !important;
      align-items: center;
      justify-content: space-between;
      .switch {
        margin-left: 6px;
        // transform: scale(0.9);
      }
    }
  }
}
</style>
