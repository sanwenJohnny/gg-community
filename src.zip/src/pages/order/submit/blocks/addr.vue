<template>
  <div class="wrap addr" :class="{'b_bottom':!isSelf}" @click="goAddr" v-if="pageData.receiveAddress != null">
    <!-- 地址信息和小区代理 -->
    <div class="a_a">
      <!-- 地址信息 -->
      <div class="text">
        <span class="f_theme" v-if="!isSelf">[提货地址]</span>{{addrData.detailAddress}}</div>
      <!-- 小区代理 -->
      <div class="f_sub agent">
        <!-- 名字 -->
        <span class="name" :class="{self: isSelf}">
          <span v-if="!isSelf">小区代理: </span>{{addrData.fullName}}</span>
        <!-- 手机 -->
        <span class="phone">{{addrData.mobileNumber}}</span>
      </div>
    </div>
    <!-- 箭头 -->
    <icon-text :iconSrc="arrowIcon" space="0px" iconWidth="10px" />
  </div>
</template>

<script>
// utils
import utils from 'u'
import path from 'p'
import imgApi from 'u/imgApi'
// components
import iconText from 'c/iconText'

export default {
  ivs: { use: 'orderSubmit' },
  name: 'addr',
  data() {
    return {
      arrowIcon: imgApi.getRes('orderSubmit', 'r_arrow')
    }
  },
  computed: {
    isSelf() {
      return this.sOrderAddress.addressType === 1
    },
    addrInfo() {
      return this.pageData.receiveAddress || {}
    },
    addrData() {
      if (this.isSelf) {
        return this.addrInfo.userAddress || {}
      } else {
        return this.addrInfo.agentAddress || {}
      }
    },
    agentData() {
      return this.addrInfo.agentAddress || {}
    }
  },
  methods: {
    goAddr() {
      this.setAgentAddressAction(this.agentData)
      this.setLockUseCoinAction(true)
      utils.go(path.ORDER_ADDRESS)
    }
  },
  components: {
    'icon-text': iconText
  }
}
</script>

<style scoped lang="scss">
.addr {
  width: 100%;
  padding-bottom: 16px;
  padding-top: 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  // 地址信息和小区代理
  .a_a {
    margin-right: 30px;
    // 地址信息
    .text {
      font-family: PingFangSC-Medium,Roboto-Medium,Noto-Medium;
      font-size: 16px;
      color: #151515;
      letter-spacing: 0;
      line-height: 20px;
      font-weight: bold;
      .f_theme {
        color: $darkOrangeBase;
        font-size: 14px;
      }
    }
    // 小区代理
    .agent {
      font-size: 16px;
      line-height: 16px;
      margin-top: 8px;
      height: auto;
      // 名字
      .name {
        margin-right: 30px;
        // 代理是本人
        &.self {
          margin-right: 10px;
        }
      }
    }
  }
}
</style>
