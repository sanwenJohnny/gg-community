<template>
  <div class="list">
    <!-- 单个订单 -->
    <div class="item" v-for="(order, i) in orderList" :key="i">
      <!-- title -->
      <div class="wrap f_sub title" v-if="orderList.length > 1">订单{{i+1}}</div>
      <!-- 订单 -->
      <good-item v-for="(good,j) in order.opDTOList" :key="j" thumbSize="62px" :good="good" :fieldMap="goodItemFieldMap" :subline="j==0?0:1"/>
    </div>
  </div>
</template>

<script>
// components
import goodItem from 'ordc/goodItem'

export default {
  ivs: { use: 'orderSubmit' },  
  name: 'orders',
  data() {
    return {
      goodItemFieldMap: {
        title: 'skuName',
        thumb: 'skuImg',
        price: 'realPriceSingleShow',
        count: 'skuCount'
      }
    }
  },
  computed: {
    orderList() {
      return this.pageData.orderList || []
    }
  },
  components: {
    'good-item': goodItem
  }
}
</script>

<style scoped lang="scss">
.title {
  height: 34px;
  line-height: 34px;
  font-size: 14px;
}
.list {
  margin-top: 9px;
  // 单个订单
  .item {
    margin-bottom: 8px;
  }
}
</style>
