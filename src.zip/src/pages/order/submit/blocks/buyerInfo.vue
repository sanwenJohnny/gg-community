<template>
  <div class="wrap buyer" v-if="!isSelf">
    <!-- 姓名 -->
    <div class="b_bottom form">
      <required-info text="提货人：" textHeight="16px" />
      <input type="text" class="input" placeholder="请输入姓名" placeholder-class="f_assist" v-model.lazy="buyerInfo.name">
    </div>
    <!-- 手机 -->
    <div class="b_bottom form">
      <required-info text="手机号：" />
      <input type="number" maxlength="11" class="input" placeholder="请输入手机号" placeholder-class="f_assist" v-model.lazy="buyerInfo.phone">
    </div>
    <!-- 备注 -->
    <div class="form note">
      <required-info text="备注：" textHeight="14px" isRequired=0 />
      <textarea cols="30" rows="3" class="f_sub input textarea" v-model.lazy="buyerInfo.note"></textarea>
    </div>
  </div>
</template>

<script>
// components
import requiredInfo from 'ordc/requiredInfo'

export default {
  ivs: { use: 'orderSubmit' },  
  name: 'buyerInfo',
  data() {
    return {}
  },
  computed: {
    isSelf() {
      return this.sOrderAddress.addressType === 1
    }
  },
  components: {
    'required-info': requiredInfo
  }
}
</script>

<style scoped lang="scss">
.buyer {
  padding-right: 0;
  margin-bottom: 8px;
  .form {
    display: flex;
    align-items: center;
    padding: 15px 0;
  }
  // 备注
  .form.note {
    align-items: flex-start;
    .textarea {
      height: 32px;
      margin-left: 22px;
    }
  }
  .input {
    flex: 1;
    margin-left: 8px;
    margin-right: 10px;
  }
}
</style>
