<template>
  <div class="foot_wrap" :style="{paddingBottom: xStyle}">
    <div class="wrap b_top foot">
      <!-- 总计和减免 -->
      <div class="t_d">
        <!-- 总计 -->
        <div class="f_theme total">总计 ¥{{pageData.totalPriceShow}}</div>
        <!-- 优惠 -->
        <div class="f_sub disres" v-if="pageData.memberDisCountShow">会员已减：￥{{pageData.memberDisCountShow}}</div>
      </div>
      <!-- 付款按钮 -->
      <div class="primary-btn pay" @click="addOrder">去付款</div>
    </div>
  </div>

</template>

<script>
import utils from 'u'
import db from 'ss'
import { $ } from 'u'
import path from 'p'
export default {
  ivs: { use: 'orderSubmit' },
  name: 'footbar',
  data() {
    return {
      xStyle: '0'
    }
  },
  computed: {
    coinData() {
      return this.pageData.coin || {}
    },
    isSelf() {
      return this.sOrderAddress.addressType === 1
    },
    showCoinUse() {
      if (this.useCoin !== undefined) {
        return this.useCoin == 1
      } else {
        return this.coinData.showType == 2
      }
    }
  },
  methods: {
    // 生成订单
    addOrder() {
      if (!this.sOrderAddress.addressId) {
        wx.showToast({
          title: '请选择收货地址',
          icon: 'none',
          duration: 2000
        })
        return
      }
      if (!this.isSelf) {
        if (!this.buyerInfo.name) {
          wx.showToast({
            title: '名字不能为空',
            icon: 'none',
            duration: 2000
          })
          return
        }
        if (!/1\d{10}/.test(this.buyerInfo.phone)) {
          wx.showToast({
            title: '请输入正确的手机号',
            icon: 'none',
            duration: 2000
          })
          return
        }
      }

      const dbData = utils.get(db.COMMUNITY_INFO) || {}
      this.addAction({
        params: {
          confirmIdList: this.pageData.confirmIdList,
          useCoin: this.showCoinUse ? 1 : 0,
          cityCode: dbData.cityCode,
          coinAmount: this.pageData.coin.maxCanUseCoin,
          orderAddress: {
            addressId: this.sOrderAddress.addressId,
            addressType: this.sOrderAddress.addressType,
            fullName: this.buyerInfo.name,
            mobileNumber: this.buyerInfo.phone,
            remark: this.buyerInfo.note
          }
        }
      }).then(res => {
        this.pay(res)
      })
    },
    // 付款
    pay(info) {
      this.payAction({
        params: {
          batchNumbers: [info.batchNumber + '']
        }
      }).then(params => {
        if (params) {
          params.package = params.pack
          $(wx.requestPayment, {
            ...params
          })
            .then(res => {
              this.setCurrStatusAction(3)
              // utils.rd(path.ORDER_MY)
              wx.redirectTo({
                url: path.ORDER_MY
              })
            })
            .catch(ret => {
              this.setCurrStatusAction(1)
              // utils.rd(path.ORDER_MY)
              wx.redirectTo({
                url: path.ORDER_MY
              })
            })
        }
      })
    }
  },
  created() {
    if (this.isx) {
      this.xStyle = '34px'
    }
  }
}
</script>

<style scoped lang="scss">
.foot_wrap {
  position: fixed;
  bottom: 0;
  width: 100%;
  background: #fff;
}
.foot {
  height: 56px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  // 总计和减免
  .t_d {
    display: flex;
    flex: 1;
    height: 50px;
    line-height: 50px;
    align-items: center;
    .total {
      margin-right: 6px;
      color: $darkOrangeBase;
      font-size: 16px;
      font-weight: bold;
    }
    .disres {
      height: 12px;
      line-height: 12px;
      transform: translateY(1px);
    }
  }

  .pay {
    width: 94px;
    height: 38px;
    line-height: 38px;
  }
}
</style>

