<template>
  <div class="container">
    <div class="page">
      <div class="info">
        <img :src="sUserInfo.accountInfoVO.avatarUrl">
        <span class="ellipsis">昵称: {{sUserInfo.accountInfoVO.nickName}}</span>
      </div>
      <div class="order">
        <div class="top">
          <div>
            <span class="title f_bold">我的订单</span>
            <span class="arr" @tap="toMyOrder(0)">全部订单</span>
            <i class="icon" :style="{ backgroundImage: arrowImg }"></i>
          </div>
        </div>
        <div class="bot">
          <div class="item" @tap="toMyOrder(1)">
            <div>
              <img :src="mywaitpayImg">
              <span>待付款</span>
            </div>
          </div>
          <div class="item" @tap="toMyOrder(3)">
            <div>
              <img :src="mywaitsendImg">
              <span>待发货</span>
            </div>
          </div>
          <div class="item" @tap="toMyOrder(4)">
            <div>
              <img :src="mydeliveryImg">
              <span>配送中</span>
            </div>
          </div>
          <div class="item" @tap="toMyOrder(5)">
            <div>
              <img :src="mytradeImg">
              <span>交易成功</span>
            </div>
          </div>
          <div class="item" @tap="toRefund">
            <div>
              <img :src="myrefundImg">
              <span>退货/退款</span>
            </div>
          </div>
        </div>
      </div>

      <ul class="entrance-list b_top">
        <li class="b_bottom" v-if="communityId !== 0">
          <div class="entrance-item" @tap="toContact">
            <span>联系我们</span>
            <i class="icon" :style="{ backgroundImage: arrowImg }"></i>
          </div>
        </li>
        <li class="b_bottom" v-if="sUserInfo.accountInfoVO.isCommunityManager===1">
          <div class="entrance-item" @tap="toCommunityManage">
            <span>小区管理</span>
            <i class="icon" :style="{ backgroundImage: arrowImg }"></i>
          </div>
        </li>
        <li class="b_bottom">
          <div class="entrance-item" @tap="toAddress">
            <span>我的收货地址</span>
            <i class="icon" :style="{ backgroundImage: arrowImg }"></i>
          </div>
        </li>
      </ul>
    </div>
    <v-tab :current-page="page" ref="tab"/>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import checkSessionMixin from '@/mixin/checkSession'
import imgApi from '@/utils/imgApi'
import vTab from '@/components/tab'
export default {
  data() {
    return {
      page:3,
      arrowImg: 'url(' + imgApi.getRes('orderSubmit', 'r_arrow') + ')',
      mydeliveryImg: imgApi.getRes('mine', 'mydelivery'),
      myrefundImg: imgApi.getRes('mine', 'myrefund'),
      mytradeImg: imgApi.getRes('mine', 'mytrade'),
      mywaitpayImg: imgApi.getRes('mine', 'mywaitpay'),
      mywaitsendImg: imgApi.getRes('mine', 'mywaitsend'),
      accountInfo: {},
      communityManager: {},
      communityId: 0
    }
  },
  computed: {
    ...mapState(['sUserInfo'])
  },
  mixins: [checkSessionMixin],
  components: {vTab},
  mounted() {},
  methods: {
    ...mapActions(['homePageInfoAction']),
    ...mapActions('modMyOrder', ['setCurrStatusAction']),
    init() {
      this.personDetail()
    },
    personDetail() {
      const data = {
        communityId: this.communityId
      }
      this.homePageInfoAction({
        data
      })
    },
    toContact() {
      this.$router.push({
        url: '/pages/mine/contact/main'
      })
    },
    toCommunityManage() {
      this.$router.push({
        url: '/pages/house/houseManage/main'
      })
    },
    toAddress() {
      this.$router.push({
        url: '/pages/address/list/main'
      })
    },
    onSessionChecked() {
      const info = wx.getStorageSync('communityInfo') || {}
      this.communityId = info.communityId || 0
      this.init()
    },
    // 跳转我的订单
    toMyOrder(type) {
      this.setCurrStatusAction(type)
      this.$router.push({
        url:`/pages/order/my/main?type=${type}`
      })
    },
    toRefund() {
      this.$router.push({
        url:`/pages/order/refund/list/main`
      })
    }
  },
  onShow() {
    this.checkAuthMix()
  }
}
</script>

<style scoped lang="scss">
.page {
  width: 100%;
  height: 100%;
  background: $whiteBase;
  overflow-x: hidden;
}
.info {
  display: flex;
  align-items: center;
  width: 100%;
  height: 90px;
  img {
    width: 52px;
    height: 52px;
    border-radius: 50%;
    margin-left: 18px;
  }
  span {
    width: 240px;
    color: $darkBlackBase;
    font-size: 16px;
    margin-left: 16px;
  }
}
.order {
  padding-top: 22px;
  padding-bottom: 16px;
  .top {
    position: relative;
    .title {
      margin-left: 18px;
      color: $darkBlackBase;
      font-size: 16px;
    }
    .arr {
      position: absolute;
      right: 32px;
      top: 4px;
      display: inline-block;
      color: $lightBlackBase;
      font-size: 14px;
    }
    .icon {
      position: absolute;
      right: 18px;
      top: 8px;
      display: inline-block;
      width: 8px;
      height: 12px;
      background-image: image();
      background-repeat: no-repeat;
      background-size: 100%;
    }
  }
}
.bot {
  width: 100%;
  margin-top: 24px;
  overflow: hidden;
  .item {
    float: left;
    width: 20%;
    color: $darkBlackBase;
    font-size: 12px;
    text-align: center;
    img {
      display: block;
      width: 28px;
      height: 26px;
      margin: auto auto 7px;
    }
  }
}
.entrance-list {
  box-sizing: border-box;
  width: 100%;
  margin-left: 10px;
  margin-top: 32px;
  li {
    box-sizing: border-box;
    width: 365px;
  }
}
.entrance-item {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 54px;
  margin-left: 8px;
  margin-right: 18px;
  span {
    color: $darkBlackBase;
    font-size: 16px;
  }
  .icon {
    display: inline-block;
    width: 8px;
    height: 12px;
    background-image: image();
    background-repeat: no-repeat;
    background-size: 100%;
  }
}
</style>
