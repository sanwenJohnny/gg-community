<style scoped lang="scss">
.page{
  width: 100%;
  height: 100%;
  background: $whiteBase;
  text-align: center;
  color: $darkBlackBase;
  font-size: 16px;
  overflow: hidden;
}
.title{
  margin-top: 33px;
}
.avater{
  width: 93px;
  height: 93px;
  border-radius: 50%;
  margin-left: auto;
  margin-right: auto;
  margin-top: 22px;
}
.info{
  width: 100%;
  margin-top: 30px;
  li{
    position: relative;
    width: 100%;
    margin-bottom: 10px;
    .l-part{
      display: inline-block;
      width: 125px;
      text-align: right;
      vertical-align: top;
    }
    .r-part{
      display: inline-block;
      width: 140px;
      text-align: left;
    }
  }
}
</style>

<template>
  <div class="container">
    <div class="page">
      <p class="title">小区长联系方式</p>
      <img :src="sUserInfo.communityManagerVO.avatarUrl" class="avater">
      <ul class="info">
        <li>
          <span class="l-part">姓名: </span>
          <span class="r-part">{{sUserInfo.communityManagerVO.name}}</span>
        </li>
        <li>
          <span class="l-part">电话: </span>
          <span class="r-part">{{sUserInfo.communityManagerVO.phoneNumber}}</span>
        </li>
        <li>
          <span class="l-part">小区: </span>
          <span class="r-part">{{sUserInfo.communityManagerVO.communityName}}</span>
        </li>
        <li>
          <span class="l-part">详细地址: </span>
          <span class="r-part">{{sUserInfo.communityManagerVO.address}}</span>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
export default {
  data () {
    return {
    }
  },
  computed:{
    ...mapState(['sUserInfo'])
  },
  methods: {
  },

}
</script>
