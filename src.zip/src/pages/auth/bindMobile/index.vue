<template>
  <div class="container">
    <div class="bind-view">
      <div class="input-view b_bottom phone">
        <input class="input-label left" maxlength="11" type="number" placeholder="请输入手机号码" v-model="mobilePhone" placeholder-style="color:#747474;" />
        <button open-type="getPhoneNumber" @getphonenumber="handleGetPhoneNumber" class="negative-btn left wxauth">一键授权</button>
      </div>
      <div class="input-view b_bottom code">
        <input class="input-label left" type="number" placeholder="请输入验证码" v-model="valiCode" placeholder-style="color:#747474;" />
        <a class="tap-link" :class="{ unuse: !canSend }" @tap="getValiCode">{{codeTxt}}</a>
      </div>
    </div>
    <p class="primary-btn bind-btn" :class="{ disabled: !canBind }" @tap="toBind">立即绑定</p>
  </div>
</template>

<script>
import { mapState, mapGetters, mapActions } from 'vuex'
import request from '@/service/request'
import { $ } from "@/utils";
import tools from "@/utils";
import { TOKEN,BINDMOBILE } from '@/utils/constants'
export default {
  data () {
    return {
      mobilePhone:'',
      valiCode:'',
      codeTxt:'获取验证码',
      counter:0,
      redirectUrl:''
    }
  },
  computed:{
    canBind() {
      return this.mobilePhone && this.valiCode
    },
    canSend() {
      return new RegExp(this.$regExps.Tel).test(this.mobilePhone) && this.counter<=0
    }
  },
  methods: {
    ...mapActions(['getValidateCodeAction','bindMobileByWeChatAction','bindMobileByValidateCodeAction']),
    //获取验证码
    getValiCode() {
      if(this.counter > 0) {
        return false
      }
      if(!tools.checkFormat({regExp: this.$regExps.Tel,val: this.mobilePhone,msg: '手机号'}).status){
        return false
      }
      const data = {
        mobileNumber: this.mobilePhone,
        countryCode: '86'
      }
      this.getValidateCodeAction({data}).then(res => {
        this.$wxComps.toast('已发送')
        this.counter = 60
        const task = setInterval(() => {
          if(this.counter === 0) {
            clearInterval(task)
            this.codeTxt = '发送验证码'
          }else{
            this.counter--
            this.codeTxt = this.counter + 's重发'
          }
        },1000)
      })
    },
    //获取手机号授权回调
    handleGetPhoneNumber(e) {
      if(e.target.encryptedData && e.target.iv) {
        const opts = {
          encryptedData: e.target.encryptedData,
          iv: e.target.iv
        }
        this.bindMobile(opts)
      }
    },
    //微信授权绑定手机号
    bindMobile(data) {
      this.bindMobileByWeChatAction({data, showLoading: true}).then(res => {
        if(res.token) {
          this.onBindSuccess(res)
        }
      })
    },
    //手机号绑定
    toBind() {
      if(!tools.checkFormat([{regExp: this.$regExps.Tel,val: this.mobilePhone,msg: '手机号'},{regExp: this.$regExps.Empty,val: this.valiCode,msg: '验证码'}]).status){
        return false
      }
      const data = {
        mobileNumber: this.mobilePhone,
        countryCode: '86',
        validateCode: this.valiCode
      }
      this.bindMobileByValidateCodeAction({data,showLoading: true}).then(res => {
        this.$wxComps.toast('绑定成功')
        this.onBindSuccess(res)
      })
    },
    onBindSuccess(res) {
      wx.setStorageSync(BINDMOBILE, 0)
      wx.setStorageSync(TOKEN,res.token)
      if(this.redirectUrl){
        this.$router.replace({
          url:this.redirectUrl
        })
      }else{
        this.$router.back({
          delta: 1
        })
      }
    }
  },
  onShow () {
    this.redirectUrl = this.$root.$mp.query.redirectUrl
    this.$root.$mp.query.redirectUrl = undefined
  }
}
</script>

<style scoped lang="scss">
.bind-view{
  box-sizing: border-box;
  width: 100%;
  overflow: hidden;
  padding: 0 30px;
}
.input-view{
  width: 100%;
  height: 62px;
  overflow: hidden;
  &.phone{
    margin-top: 70px;
  }
  &.code{
    .tap-link{
      display: inline-block;
      width: 94px;
      height: 100%;
      line-height: 62px;
      text-decoration: underline;
      color: $darkBlackBase;
      text-align: center;
      &.unuse{
        color: $moreLightBlackBase;
      }
    }
  }
  .input-label{
    display: inline-block;
    width: 210px;
    height: 100%;
  }
  .wxauth{
    margin-top: 14px;
  }
}
.bind-btn{
  width: 315px;
  height: 44px;
  margin-top: 40px;
  margin-left: auto;
  margin-right: auto;
  &.disabled{
    opacity: .5;
  }
}
</style>
