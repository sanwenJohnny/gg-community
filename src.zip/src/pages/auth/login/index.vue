<template>
  <div class="container">
    <div class="login-view">
      <button open-type="getUserInfo" @getuserinfo="handleGetUserInfo" class="primary-btn login">立即登录</button>
    </div>
  </div>
</template>

<script>
import request from '@/service/request'
import user from '@/service/user'
import { $ } from "@/utils";
import { TOKEN,BINDMOBILE } from '@/utils/constants'
export default {
  data () {
    return {
      redirectUrl:''
    }
  },
  computed:{
  },
  methods: {
    handleGetUserInfo(e){
      //授权登录
      if(!e.target.encryptedData || !e.target.iv){
        this.$wxComps.toast('登录授权失败')
      }else{
        $(wx.login).then(res => {
          const data = {
            code: res.code,
            encryptedData:e.target.encryptedData,
            iv:e.target.iv
          }
          user.login(data,{showLoading:true}).then(res => {
            wx.setStorageSync(TOKEN,res.token)
            if(res.needBindMobile === 1) {
              //跳转绑定手机号
              wx.setStorageSync(BINDMOBILE, 1)
              this.$router.replace({
                url: `/pages/auth/bindMobile/main`
              })
            }else if(res.token){
              //登录成功返回上一页
              wx.setStorageSync(BINDMOBILE, 0)
              if(this.redirectUrl) {
                this.$router.replace({
                  url:this.redirectUrl
                })
              }else{
                this.$router.back({
                  delta: 1
                })
              }
            }
          }).catch((err) => {
            console.log('fal:',err)
          })
        })
      }
    }
  },

  onShow () {
    this.redirectUrl = this.$root.$mp.query.redirectUrl
    this.$root.$mp.query.redirectUrl = undefined
  }
}
</script>

<style scoped lang="scss">

.login-view{
  width: 100%;
  height: 100%;
  overflow: hidden;
  text-align: center;
  background-image: url('https://img.gegejia.com/life/miniprogram/local/login_bg.jpg');
  background-repeat: no-repeat;
  background-size: 100%;
  .login{
    color: $whiteBase;
    background-color: $blackBase;
    margin: auto;
    margin-top: 460px;
  }
}
</style>
