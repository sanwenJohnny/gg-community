<template>
  <div class="chooser_wrap" :style="{height}" @click="choose">
    <div class="chooser" :class="{choose: isChoose}" :style="{marginRight: space}">
      <img mode="widthFix" :src="chooseIcon" v-show="isChoose">
    </div>
  </div>
</template>

<script>
import imgApi from 'u/imgApi'
export default {
  name: 'chooser',
  props: {
    height: {
      type: String,
      default: '84px'
    },
    space: {
      type: String,
      default: '16px'
    },
    isChoose: Boolean,
    id: [Number, String]
  },
  data() {
    return {
      chooseIcon: imgApi.getRes('shoppingCart', 'choose')
    }
  },
  methods: {
    choose() {
      this.$emit('choose', this.id)
    }
  }
}
</script>

<style scoped lang="scss">
.chooser_wrap {
  height: 84px;
  display: flex;
  align-items: center;
  .chooser {
    width: 20px;
    height: 20px;
    border-radius: 50%;
    border: 1px solid #c0c0c0;
    margin-right: 16px;
    // 勾选icon
    img {
      width: 100%;
    }
  }
  /*  勾选状态  */
  .chooser.choose {
    border-color: transparent;
  }
}
</style>
