<template>
  <div class="page">
    <div class="wrapper" :class="{show: inited}">
      <div v-if="show" class="main">
        <!-- 商品列表 -->
        <good-list/>
        <!-- 底部固定bar -->
        <foot-bar/>
      </div>
      <empty :image="emptyImg" v-if="!show">购物车没有商品哦~快去挑选吧</empty>
    </div>
    <!-- 占位符 -->
    <div class="placeholder" :style="{height: xStyle}"></div>
    <!-- 底部切换栏 -->
    <tab-bar :currentPage="tabBarNum" />
  </div>
</template>

<script>
import mixin from './mixin'
import api from 'a/shoppingCart'
import utils from 'u'
import db from 'ss'
import imgApi from 'u/imgApi'

// blocks
import goodList from './blocks/goodList'
import footBar from './blocks/footBar'
import tabBar from 'c/tab'
import empty from 'c/empty'

import checkSession from 'm/checkSession'
export default {
  ivs: {
    id: 'cart',
    mods: [
      'modShoppingCart',
      {
        mod: 'modProduct',
        actions: ['getCartCountAction']
      },
      {
        mod: '$root',
        actions: ['setCartNumberAction']
      }
    ]
  },
  mixins: [mixin, checkSession],
  data() {
    return {
      tabBarNum: 2,
      emptyImg: imgApi.getRes('empty', 'cart'),
      xStyle: '110px'
    }
  },
  computed: {
    goodList() {
      return this.pageData.skus || []
    },
    show() {
      return this.goodList && this.goodList.length > 0
    }
  },
  onLoad() {
    this.setInitedAction(false)
    if (!this.inited) {
      utils.loading()
    }
  },
  onShow() {
    this.checkAuthMix()
  },
  methods: {
    onSessionChecked() {
      this.setChoosesAction(utils.get(db.CART_CHOOSES) || {})
      this.chooseAllAction(utils.get(db.CART_CHOOSEALL) || false)
      this.resetPageData().then(res => {
        let num = 0
        for (let key in this.chooses) {
          if (this.chooses[key]) {
            num++
          }
        }
        if (num == this.goodList.length) {
          this.chooseAllAction({
            isChooseAll: true,
            batch: true
          })
        }
        setTimeout(() => {
          if (!this.inited) {
            utils.loaded()
          }
          this.setInitedAction(true)
        }, 300)
      })
      this.updateButtomTabCartNum()
    },
    // 更新底部tab购物车数量
    updateButtomTabCartNum() {
      const communityInfo = wx.getStorageSync('communityInfo') || {}
      const data = {
        cityCode: communityInfo.cityCode
      }
      this.getCartCountAction({
        data
      }).then(res => {
        this.setCartNumberAction(res)
      })
    }
  },
  created() {
    if (this.isx) {
      this.xStyle = '140px'
    }
  },
  components: {
    'good-list': goodList,
    'foot-bar': footBar,
    'tab-bar': tabBar,
    empty
  }
}
</script>

<style scoped lang="scss">
.page {
  height: 100%;
  background-color: #fff;
  // padding-bottom: 150px;
  display: flex;
  flex-direction: column;
}

.wrapper {
  flex: 1;
  opacity: 0;
  overflow: scroll;
  display: flex;
  flex-direction: column;
  // -webkit-overflow-scrolling: touch;

  &.show {
    opacity: 1;
  }

  & .main {
    flex: 1;
    display: flex;
    flex-direction: column;
  }
}

.placeholder {
  height: 110px;
  width: 100%;
}

.placeholder.isx {
  height: 140px;
}
</style>
