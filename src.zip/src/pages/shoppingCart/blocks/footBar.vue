<template>
  <div class="wrap b_top foot" :style="{bottom: xStyle}">

    <!-- 勾选框和文字 -->
    <div class="r_t" @click="chooseAll">
      <chooser :isChoose="isChooseAll" height="56px" space="10px" />
      <div class="text">全选</div>
    </div>

    <!-- 总价和结算按钮 -->
    <div class="t_s">
      <!-- 价格 -->
      <div class="price">
        <!-- 总价 -->
        <div class="f_theme total">
          <span class="text">总计</span>
          <span>￥{{total}}</span>
        </div>
        <!-- 会员已减 -->
        <div class="f_sub discount" v-if="pageData.isMember && discount>0">会员已减: ￥{{discount}}</div>
      </div>
      <!-- 结算按钮 -->
      <div class="primary-btn settle" @click="goOrderSubmit">去结算</div>
    </div>
  </div>
</template>

<script>
import path from 'p'
import utils from 'u'
import chooser from '../components/chooser'

export default {
  ivs: 'modShoppingCart',
  name: 'footBar',
  data() {
    return {
      buyList: [],
      xStyle: '54px'
    }
  },
  computed: {
    goodList() {
      return this.pageData.skus || []
    },
    totals() {
      let priceKey
      if (this.pageData.isMember) {
        priceKey = 'memberPrice'
      } else {
        priceKey = 'salesPrice'
      }
      let ordinaryRes = 0,
        memberRes = 0
      for (let i = 0, good; i < this.goodList.length; i++) {
        good = this.goodList[i]
        if (good.choose) {
          ordinaryRes += good.count * good.salesPrice
          memberRes += good.count * good.memberPrice
        }
      }
      return {
        ordinaryRes,
        memberRes
      }
    },
    total() {
      if (this.pageData.isMember) {
        return this.totals.memberRes.toFixed(2)
      } else {
        return this.totals.ordinaryRes.toFixed(2)
      }
    },
    discount() {
      return Number(this.totals.ordinaryRes - this.totals.memberRes).toFixed(2)
    }
  },
  methods: {
    // 全选
    chooseAll() {
      let isChooseAll = !this.isChooseAll
      this.chooseAllAction({
        isChooseAll,
        batch: true
      })
    },
    // 去提交订单页面
    goOrderSubmit() {
      let num = 0,
        list = []
      for (let i = 0, good; i < this.goodList.length; i++) {
        good = this.goodList[i]
        if (this.chooses[good.skuId]) {
          list.push({
            skuId: good.skuId,
            count: good.count
          })
        }
      }
      for (let skuId in this.chooses) {
        if (this.chooses[skuId]) {
          num++
        }
      }
      if (num == 0) {
        wx.showToast({
          title: '至少选择一个商品',
          icon: 'none',
          duration: 2000
        })
        return
      }
      this.orderConfirmAction(list).then(res => {
        if (res && !res.errorMessage) {
          utils.go(
            path.ORDER_SUBMIT +
              utils.objectToQueryString({
                skus: JSON.stringify(list)
              })
          )
        }
      })
    }
  },
  created() {
    if (this.isx) {
      this.xStyle = '84px'
    }
  },
  components: {
    chooser
  }
}
</script>

<style scoped lang="scss">
.foot {
  position: fixed;
  bottom: 54px;
  width: 100%;
  display: flex !important;
  justify-content: space-between;
  align-items: center;
  background: #fff;
  padding-top: 9px;
  padding-bottom: 9px;
  // z-index: 999;
  height: 56px;
  box-sizing: border-box;
}
.foot.isx {
  bottom: 84px;
}
// 勾选框和文字
.r_t {
  display: flex;
  align-items: center;
  // 勾选框
  .check_wrap {
    height: 38px;
    .check {
      margin-right: 10px;
    }
  }
  // 文字
  .text {
    font-family: PingFangSC-Regular;
    font-weight: normal;
    font-size: 14px;
    color: #747474;
    letter-spacing: 0;
  }
}

// 总价和结算按钮
.t_s {
  display: flex;
  align-items: center;
  // 总价
  .total {
    text-align: right;
    color: $darkOrangeBase;
    font-size: 16px;
    font-weight: bold;
    .text {
      margin-right: 5px;
    }
  }
  .discount {
    margin-top: 5.5px;
  }
  // 结算按钮
  .settle {
    width: 94px;
    height: 38px;
    line-height: 38px;
    margin-left: 10px;
  }
}
</style>
