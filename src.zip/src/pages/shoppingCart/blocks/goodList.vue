<template>
  <div class="wrap list">
    <div class="b_bottom item" v-for="(good, i) in goodList" :key="i" @click="goGoodDetail($event, good.skuId)">

      <!-- 勾选框 -->
      <chooser :isChoose="good.choose" :id="i" @choose="choose" />

      <!-- 商品图 -->
      <div class="thumbnail">
        <img mode="widthFix" :src="good.image">
      </div>

      <!-- 商品详情和操作按钮 -->
      <div class="dtl_opt">
        <!-- 商品标题和删除按钮 -->
        <div class="tl_dte">
          <!-- 商品标题 -->
          <div class="f_title title">{{good.skuName}}</div>
          <!-- 删除按钮 -->
          <div class="delete" @click="deleteItem(good.skuId)" data-role="delete">
            <img mode="widthFix" :src="deleteIcon" data-role="delete">
          </div>
        </div>

        <!-- 价格和加减器 -->
        <div class="prc_am">
          <!-- 价格 -->
          <div class="price">
            <!-- 数字 -->
            <div class="f_theme">￥{{pageData.isMember?good.memberPrice:good.salesPrice}}</div>
            <!-- 会员团购价 -->
            <div class="text" v-if="pageData.isMember">会员团购价</div>
          </div>
          <!-- 加减器 -->
          <subtractor :count="good.count" :max="good.limitCount" :id="i" @updateCount="onCountUpdate" @crossMin="crossMin" @crossMax="crossMax" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import mixin from '../mixin'
// components
import imgApi from 'u/imgApi'
import utils from 'u'
import { $ } from 'u'

import subtractor from 'c/subtractor'
import chooser from '../components/chooser'

export default {
  ivs: { use: 'cart' },
  name: 'goodList',
  mixins: [mixin],
  data() {
    return {
      deleteIcon: imgApi.getRes('shoppingCart', 'delete')
    }
  },
  computed: {
    goodList() {
      return this.pageData.skus || []
    }
  },
  methods: {
    // 选中、取消选中
    choose(i) {
      let good = this.goodList[i]
      let val = !good.choose
      good.choose = val
      if (val) {
        this.addChooseItemAction({
          skuId: good.skuId
        })
        let num = 0
        for (let key in this.chooses) {
          if (this.chooses[key]) {
            num++
          }
        }
        if (num == this.goodList.length) {
          this.chooseAllAction({
            isChooseAll: true,
            batch: true
          })
        }
      } else {
        this.deleteChooseItemAction(good.skuId)
        this.chooseAllAction({
          isChooseAll: false
        })
      }
    },
    // 删除
    deleteItem(skuId, e) {
      $(wx.showModal, {
        content: '确定删除吗'
      }).then(res => {
        if (res.confirm) {
          this.deleteAction({
            params: {
              skuIds: [skuId]
            }
          }).then(res => {
            this.resetPageData()
            this.deleteChooseItemAction(skuId)
            this.updateButtomTabCartNum()
          })
        }
      })
    },
    // 加减器数量更新钩子
    onCountUpdate(count, id) {
      this.updateAction({
        params: {
          count,
          skuId: this.goodList[id].skuId
        }
      }).then(res => {
        this.updateCountAction({
          count,
          id
        })
        this.updateButtomTabCartNum()
      })
    },
    // 加减器小于最小值钩子
    crossMin(id) {
      this.deleteItem(this.goodList[id].skuId)
    },
    // 加减器大于最大值钩子
    crossMax(id) {
      $(wx.showToast, {
        title: `该商品限购${this.goodList[id].limitCount}件`,
        icon: 'none',
        duration: 2000
      })
    },
    // 跳转商品详情
    goGoodDetail(e, skuId) {
      if(e.target.dataset.role) {
        return
      }
      utils.go("/pages/product/detail/main?pid=" + skuId)
    },
    // 更新底部tab购物车数量
    updateButtomTabCartNum() {
      const communityInfo = wx.getStorageSync('communityInfo') || {}
      const data = {
        cityCode: communityInfo.cityCode
      }
      this.getCartCountAction({
        data
      }).then(res => {
        this.setCartNumberAction(res)
      })
    }
  },
  components: {
    chooser,
    subtractor
  }
}
</script>

<style scoped lang="scss">
.list {
  padding-right: 0;
  flex: 1;
  overflow: scroll;
  -webkit-overflow-scrolling: touch;
}
.item {
  display: flex;
  align-items: center;
  width: 100%;
  background: #fff;
  padding-top: 18px;
  padding-bottom: 16px;
  padding-right: 10px;
  box-sizing: border-box;
}

/*  商品详情和操作按钮  */
.dtl_opt {
  flex: 1;
  position: relative;
  height: 82px;
}

/*  商品图  */
.thumbnail {
  position: relative;
  width: 82px;
  height: 82px;
  overflow: hidden;
  margin-right: 10px;

  img {
    position: absolute;
    width: 100%;
    top: 50%;
    transform: translateY(-50%);
  }
}

/*  商品标题和删除按钮  */
.tl_dte {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  // 商品标题
  .title {
    flex: 1;
  }
  // 删除按钮
  .delete {
    position: relative;
    width: 16px;
    height: 17px;
    margin-left: 10px;
    img {
      width: 100%;
    }
  }
}

/*  价格和加减器  */
.prc_am {
  position: absolute;
  bottom: -2px;
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  // 价格
  .price {
    position: relative;
    .f_theme {
      color: $darkOrangeBase;
    }
    // 会员团购价
    .text {
      position: absolute;
      top: 0;
      left: 3px;
      width: 50px;
      transform: translateY(-100%);
      font-family: PingFangSC-Regular;
      font-weight: normal;
      font-size: 10px;
      color: $darkOrangeBase;
      letter-spacing: 0;
      line-height: 10px;
    }
  }
}
</style>
