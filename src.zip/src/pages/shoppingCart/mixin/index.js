import utils from 'u'
import db from 'ss'

export default {
    methods: {
        resetPageData() {
            const dbData = utils.get(db.COMMUNITY_INFO) || {}
            return this.getPageDataAction({
                params: {
                    cityCode: dbData.cityCode
                }
            }).then(res => {
                const skus = res.skus
                const newChooses = {}
                for (let i = 0; i < skus.length; i++) {
                    if (this.chooses[skus[i].skuId]) {
                        skus[i].choose = true
                        newChooses[skus[i].skuId] = true
                    } else {
                        skus[i].choose = false
                    }
                }
                this.setChoosesAction(newChooses)
                return res
            }).then(res => {
                return this.setPageDataAction(res)
            })
        }
    }
}
