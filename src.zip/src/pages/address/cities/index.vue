<template>
  <div class="container">
    <ul class="city-list">
      <li class="city-group" v-for="(item,index) in cityList" :key="index">
        <p class="title">{{item.firstSpell}}</p>
        <div class="city-view">
          <div class="city line" v-for="(ite, ide) in item.citys" :key="ide" @tap="handleSelected(ite)">{{ite.cityName}}</div>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
export default {
  data () {
    return {
      cityList:[]
    }
  },
  computed:{

  },
  mounted() {
    this.init()
  },
  methods: {
    ...mapActions('modAddress',['setSelectedCityAction','openedCityListAction']),
    init() {
      this.cityList = []
      this.openedCityListAction()
      .then(data=>{
        this.cityList = data
      })
    },
    handleSelected(item) {
      this.setSelectedCityAction({code:item.cityCode,name:item.cityName})
      this.$router.back()
    }
  },
  onShow () {
  },

}
</script>

<style scoped lang="scss">
.city-list{
  .city-group{
    background-color: #fff;
    .title{
      height: 28px;
      line-height: 28px;
      background-color: #f5f5f5;
      color: $lightBlackBase;
      font-size: 12px;
      padding-left: 10px;
    }
    .city{
      color: $darkBlackBase;
      margin-left: 10px;
      height: 44px;
      line-height: 44px;
      font-size: $largeFontSize;
    }
  }
}
.city-view{
  width: 100%;
}
</style>
