<template>
  <div class="container">
    <ul class="city-list">
      <li class="city-group" v-for="(item,index) in cityList" :key="index">
        <p class="title">{{item.firstSpell}}</p>
        <div class="city" v-for="(ite, ide) in item.citys" :key="ide" @click="selectCity(ite)">{{ite.cityName}}</div>
      </li>
    </ul>
  </div>
</template>

<script>
import imgApi from "@/utils/imgApi";
import { mapActions } from 'vuex';
import { communityInfo } from "../address";
import { $ } from "@/utils/index";

export default {
  data () {
    return {
      clearImg: imgApi.getRes("search","clear"),
      communityInfo: "",
      cityList:[]
    }
  },
  onLoad (){
    wx.hideShareMenu()
    Object.assign(this.$data, this.$options.data())
    this.communityInfo = wx.getStorageSync("communityInfo") || {}
    this.initPage()
  },
  methods: {
    ...mapActions(["setChooseAreaAction"]),
    ...mapActions("modAddress",["openedCityListAction"]),
    initPage(){
      this.getCityInfoData()
      if(this.communityInfo.cityCode){
        this.cityList.push({
          firstSpell: "当前定位城市",
          citys: [
            {
              cityCode: this.communityInfo.cityCode,
              cityName: this.communityInfo.cityName
            }
          ]
        })
      }
    },
    // 获取城市信息
    getCityInfoData(){
      this.openedCityListAction()
      .then(data=>{
        this.cityList = [...this.cityList,...data]
      })
    },
    // 选择城市
    selectCity (item) {
      console.log(item)
      const community = {
        cityCode: item.cityCode,
        cityName: item.cityName,
        communityId: "",
        communityName: "",
        detailAddress: ""
      }
      wx.setStorageSync("communityInfo",community)
      this.setChooseAreaAction(true)
      this.$router.back({
        delta: 1
      })
      // this.$router.push({
      //   url: "/pages/address/chooseArea/main"
      // })
    }
  }
}
</script>

<style scoped lang="scss">

.container{
  .city-list{
    .city-group{
      background-color: #fff;
      .title{
        height: 28px;
        line-height: 28px;
        background-color: #f5f5f5;
        color: $lightBlackBase;
        font-size: 12px;
        padding-left: 10px;
      }
      .city{
        color: $darkBlackBase;
        padding-left: 10px;
        height: 44px;
        line-height: 44px;
        font-size: $largeFontSize;
      }
    }
  }
}
</style>
