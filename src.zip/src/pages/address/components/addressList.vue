<style scoped lang="scss">
.disabled{
  span,p{
    color: $moreLightBlackBase !important;
  }
}
.view-cont{
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-left: 10px;
}
.address-item{
  width: 100%;
  background-color: $whiteBase;
  .info{
    box-sizing: border-box;
    width: 295px;
    padding: 16px 0;
    padding-right: 10px;
    p{
      color: $blackBase;
    }
    span{
      display: inline-block;
      margin-top: 8px;
      color: $lightBlackBase;
      vertical-align: middle;
      &.ellipsis{
        width: 60px;
      }
      &:last-child{
        margin-left: 10px;
      }
    }
  }
}
.edit{
  width: 58px;
  height: 42px;
  line-height: 42px;
  text-align: center;
}

</style>

<template>
  <div class="address-list">
    <div class="address-item" v-for="(item,index) in list" :key="index">
      <div class="view-cont" :class="{'b_bottom': index !== list.length-1}">
        <div class="info" :class="{'disabled': disabled}" @tap="handleSelect(item)">
          <p class="ellipsis">{{item.detailAddress}}</p>
          <span class="ellipsis">{{item.fullName}}</span>
          <span>{{item.mobileNumber}}</span>
        </div>
        <div class="edit b_left" @tap="handleTap(item)" v-if="!disabled">
          编辑
        </div>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  data () {
    return {

    }
  },
  props:{
    list:{
      type: Array
    },
    disabled:{
      type: Boolean,
      default: false
    }
  },
  computed:{
  },
  methods: {
    handleTap(item) {
      this.$router.push({
        url: '/pages/address/edit/main?type=edit&addressId='+item.addressId
      })
    },
    handleSelect(item) {
      if(this.disabled) return
      this.$emit('selected',item)
    }
  },

}
</script>
