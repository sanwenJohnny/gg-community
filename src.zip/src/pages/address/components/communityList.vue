<template>
  <div class="community-components">
    <div class="community">
      <p class="tip" v-if="tip !== 'none'">{{type==="current"?"当前小区":"热门小区"}}</p>
      <div class="community-detail line" v-for="(item, index) in list" :key="index" @click="goHome(item)">
        <p class="community-name" :class="{ bold : type==='current' }">{{item.communityName}}</p>
        <p class="community-address">{{item.communityAddress}}</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {

    }
  },
  props:["type", "tip", "list"],
  computed:{
  },
  mounted (){},
  methods: {
    // 去首页
    goHome(item){
      const communityInfo = wx.getStorageSync("communityInfo") || {}
      communityInfo.communityId=item.communityId
      communityInfo.communityName=item.communityName
      communityInfo.detailAddress=item.communityAddress
      wx.setStorageSync("communityInfo",communityInfo)
      this.$router.reLaunch({
        url: "/pages/index/main"
      })
    }
  }
}
</script>

<style scoped lang="scss">
.bold{
  font-weight: bold;
}
.community-components{
  background-color: #fff;
  padding: 0 10px;
  margin-bottom: 8px;
  .tip{
    color: $moreLightBlackBase;
    font-size: 12px;
    padding-top: 12px;
  }
  .community-detail{
    padding: 12px 0;
    .community-name{
      color: $darkBlackBase;
      font-size: 16px;
    }
    .community-address{
      color: $lightBlackBase;
      margin-top: 3px;
      font-size: 14px;
    }
  }
}
</style>
