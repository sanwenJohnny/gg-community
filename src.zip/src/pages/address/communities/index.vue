<template>
  <div class="container">
    <div class="list">
      <scroll-view class="scroll-wrapper" :scroll-y="true" @scrolltolower="handleLoadMore">
        <div class="item-view" v-for="(item,index) in list" :key="index">
          <div class="item" :class="{'b_bottom': index !== list.length-1}" @tap="handleSelected(item)">
            <p>{{item.communityName}}</p>
            <span>{{item.communityAddress}}</span>
          </div>
        </div>
      </scroll-view>
      <load-more v-if="loading"></load-more>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import loadMore from '@/components/loadMore'
export default {
  data () {
    return {
      page:1,
      pageSize:20,
      code:'',
      list:[],
      total:0,
      loading:false
    }
  },
  computed:{

  },
  components:{loadMore},
  mounted() {

  },
  methods: {
    ...mapActions('modAddress', ['getCommunityListAction','setSelectedCommunityAction']),
    init() {
      this.code = this.$root.$mp.query.citycode
      this.getList()
    },
    getList() {
      let data = {cityCode: this.code,page: this.page,pageSize: this.pageSize}
      this.getCommunityListAction({data}).then(res => {
        this.list = this.list.concat(res.list)
        this.total = res.total
        this.loading = false
      })
    },
    handleSelected(item) {
      this.setSelectedCommunityAction({code:item.communityId,name:item.communityName})
      this.$router.back()
      // this.$router.back()
    },
    handleLoadMore() {
      if(Math.ceil(this.total / this.pageSize) > this.page) {
        this.page++
        this.loading = true
        this.getList()
      }
    }
  },
  onShow () {
    this.page = 1
    this.list = []
    this.init()
  },
  // onReachBottom() {
  //   console.log('meiyi=====')
  //   if(Math.ceil(this.total / this.pageSize) > this.page) {
  //     this.page++
  //     this.getList()
  //   }
  // }

}
</script>

<style scoped lang="scss">
.list{
  width: 100%;
  height: 100%;
  background-color: $lightWhiteBase;
  .item-view{
    padding-left: 10px;
    background-color: $whiteBase;
  }
}
.item{
  box-sizing: border-box;
  width: 100%;
  padding: 10px 0;
  padding-right: 10px;
  line-height: 19px;
  p{
    color: $darkBlackBase;
    font-size: 16px;
  }
  span{
    color: $moreLightBlackBase;
    font-size: 14px;
  }
}
.scroll-wrapper{
  height: 100%;
}
</style>
