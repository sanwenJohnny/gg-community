export const communityInfo = wx.getStorageSync("communityInfo") || {}

export default {
  communityInfo
}