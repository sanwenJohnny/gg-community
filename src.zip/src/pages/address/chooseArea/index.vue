<template>
  <div class="container">
    <!-- 头部搜索框 -->
    <div class="header">
      <div class="search-input">
        <div class="area" @click="goChooseCity">
          <span class="city ellipsis">{{communityInfo.cityName || "请选择城市"}}</span>
          <img class="arrow" mode="widthFix" :src="arrowImg">
        </div>
        <div class="search" @click="goSearchComunity">
          <img class="search-icon" mode="widthFix" :src="searchImg">
          <div class="search-input">输入小区名称搜索社区</div>
        </div>
      </div>
    </div>
    <!-- 城市已开通 -->
    <template v-if="pageType === 0">
      <!-- 当前小区 -->
      <community type="current" :list="currentCommunity" v-if="currentCommunity.length>0"></community>
      <!-- 我的收货地址 -->
      <div class="my-address" v-if="receiveAddressList.length>0">
        <p class="tip co-c2">我的收货地址</p>
        <ul class="address-list">
          <li class="address-item line" v-for="(item, index) in addresList" :key="index" @click="goHome(item)">
            <div class="address">
              <!-- <span class="default">默认地址</span> -->
              <span class="info">{{item.detailAddress}}</span>
            </div>
            <div class="user-info">
              <span class="user-name co-74">{{item.fullName}}</span>
              <span class="user-phone co-74">{{item.mobileNumber}}</span>
            </div>
          </li>
        </ul>
        <div class="more-address" v-if="receiveAddressList.length > 3" @click="changeAddressShow">
          <span>{{addresList.length === 3? "更多收货地址" : "收起"}}</span>
          <img class="open" :class="{rotate: addresList.length !== 3}" :src="openImg" mode="widthFix">
        </div>
      </div>
      <!-- 热门小区 -->
      <community :list="hotCommunityList" v-if="hotCommunityList.length>0"></community>
    </template>
    <!-- 定位失败 -->
    <template  v-else-if="pageType === 1">
      <v-empty :image="locationFail">
        <div class="slot-msg">
          <p class="tip">定位失败，请选择城市或开启定位授权</p>
          <div class="location-btn" @click="showModel">开通定位</div>
        </div>
      </v-empty>
    </template>
    <!-- 城市未开通 -->
    <template v-else>
      <v-empty :image="location">
        <div class="slot-msg">
          <p class="tip">当前城市暂未开通服务，请更换城市或<span class="jump" @click="apply">申请开通></span></p>
        </div>
      </v-empty>
    </template>
    <!-- 授权弹框 -->
    <div class="author-model" v-if="authorModelShow">
      <div class="mask"></div>
      <div class="body">
        <div class="title">授权提示</div>
        <p class="content">您未开通定位权限,当前无法获取定位.</p>
        <div class="footer">
          <div class="cancle" @click="hideModel">拒绝</div>
          <div class="sure">
            授权
            <button open-type="openSetting" @opensetting="getLocationInfo"></button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import imgApi from "@/utils/imgApi";
import { mapActions } from 'vuex';
import { $ } from "@/utils/index";
import community from "../components/communityList";
import vEmpty from "@/components/empty";

export default {
  data () {
    return {
      arrowImg: imgApi.getRes("chooseArea","arrow"),
      searchImg: imgApi.getRes("chooseArea","search"),
      openImg: imgApi.getRes("chooseArea","open"),
      locationFail: imgApi.getRes("empty","locationFail"),
      location: imgApi.getRes("empty","location"),
      addressShowList: 3,
      communityInfo: {},
      currentCity: '',
      currentCommunity:[],
      hotCommunityList:[],
      receiveAddressList:[],
      pageType: 0,// 默认有数据 0 当前城市已开通 1未定位到城市 2当前城市未开通
      authorModelShow: false,
      addresList:[] // 显示地址列表
    }
  },
  components: {
    community,
    vEmpty
  },
  mounted (){
    wx.hideShareMenu()
  },
  onShow(){
    Object.assign(this.$data, this.$options.data())
    this.initPage()
  },
  methods: {
    ...mapActions(["setChooseAreaAction"]),
    ...mapActions("modAddress",["selectCommunityAction","locationCityAction"]),
    initPage (){
      // 初始化数据
      Object.assign(this.$data, this.$options.data())
      this.communityInfo = wx.getStorageSync("communityInfo") || {}
      const communityInfo = this.communityInfo
      // 未定位到城市先定位
      if( !this.communityInfo.cityCode ) {
        this.pageType = 1
        this.showModel()
        return
      }
      this.getSelectCommunityData()
      if(communityInfo && communityInfo.communityId){
        this.currentCommunity.push({
          "communityId": communityInfo.communityId,
          "communityName": communityInfo.communityName,
          "communityAddress": communityInfo.detailAddress
        })
      }
    },
    // 用户未定位去定位
    getLocationInfo(res){
      // 用户手动允许
      if(res && res.mp.detail.authSetting['scope.userLocation']){
        this.getLocation()
      }
    },
    // 获取页面信息
    getSelectCommunityData(){
      const cityCode = this.communityInfo && this.communityInfo.cityCode || ""
      if (!cityCode) return
      this.selectCommunityAction({
        data:{
          cityCode: cityCode
        }
      })
      .then(data=>{
        this.pageType = 0
        // 小区未开通
        if(!data.cityIsAvailable) this.pageType = 2

        this.hotCommunityList = data.hotCommunityList || []
        this.receiveAddressList = data.receiveAddressList || []
        this.receiveAddressListHandle()
      })
    },
    // 收货地址处理
    receiveAddressListHandle(){
      this.addresList = this.receiveAddressList.slice(0, this.addressShowList)
    },
    // 更多收获地址
    changeAddressShow(){
      this.addressShowList = this.addressShowList === 3 ? this.receiveAddressList.length : 3
      this.receiveAddressListHandle()
    },
    // 去首页
    goHome(item){
      const communityInfo = this.communityInfo
      communityInfo.communityId=item.communityId
      communityInfo.communityName=item.communityName
      communityInfo.detailAddress=item.communityAddress
      wx.setStorageSync("communityInfo",communityInfo)
      console.log(communityInfo)
      this.$router.reLaunch({
        url: "/pages/index/main"
      })
    },
    // 去选择城市页
    goChooseCity(){
      this.$router.push({
        url: '/pages/address/chooseCity/main'
      })
    },
    // 前往搜索小区页
    goSearchComunity(){
      const communityInfo = this.communityInfo
      if(!communityInfo.cityCode){
        this.$router.push({
          url: "/pages/address/chooseCity/main"
        })
      }else{
        this.$router.push({
          url: "/pages/address/searchCommunity/main"
        })
      }
    },
    // 隐藏弹框
    hideModel(){
      this.authorModelShow = false
    },
    // 显示弹框
    showModel(){
      this.authorModelShow = true
    },
    // 申请开通小区
    apply(){
      this.$router.push({
        url: "/pages/house/apply/main"
      })
    },
    // 定位
    getLocation(){
      $(wx.getLocation,{type: 'wgs84'}).then(res=>{
        console.log(res)
        const param = {
          latitude: res.latitude,
          longitude: res.longitude
        }
        this.getlocationCity(param)
      })
    },
    // 获取定位城市
    getlocationCity(data){
      this.locationCityAction({
        data
      })
      .then(data=>{
        const community = {
          cityCode: data.cityCode,
          cityName: data.cityName,
          communityId: "",
          communityName: "",
          detailAddress: ""
        }
        wx.setStorageSync("communityInfo",community)
        this.communityInfo = community
        this.setChooseAreaAction(true)
        this.getSelectCommunityData()
        this.hideModel()
      })
    }
  }
}
</script>

<style scoped lang="scss">
.co-74{
  color: #747474;
}
.co-333{
  color: #333;
}
.co-c2{
  color: #c2c2c2;
}
.container{
  background-color: transparent;
  // 头部搜索框
  .header{
    padding: 12px 10px 12px;
    background-color: #fff;

    .search-input{
      background-color: #f3f3f3;
      height: 32px;
      display: flex;
      align-items: center;
      .area{
        display: inline-block;
        position: relative;
        width: 95px;
        text-align: center;
        height: 16px;
        // line-height: 32px;
        font-size: 14px;
        color: #333;
        border-right: 1px solid #d9d9d9;
        .city{
          max-width: 67px;
          display: inline-block;
        }
        .arrow{
          position: absolute;
          top: 50%;
          width: 6px;
          height: auto;
          margin-left: 4px;
          transform: translateY(-50%)
        }
      }
      .search{
        position: relative;
        flex: 1;
        padding-left: 36px;
        .search-icon{
          position: absolute;
          left: 10px;
          top: 50%;
          transform: translateY(-50%);
          width: 16px;
          height: auto;
        }
        .search-input{
          @extend .co-74;
          font-size: 13px;
        }
      }
    }
  }
  // 当前小区
  .current-community{
    margin-bottom: 8px;
  }
  // 我的收货地址
  .my-address{
    padding: 12px 10px 0;
    background-color: #fff;
    margin-bottom: 8px;
    .tip{
      font-size: 12px;
    }
    .address-item{
      .address{
        padding-top: 10px;
        .default{
          font-size: 16px;
          color: #FFA832;
        }
        .info{
          font-size: 16px;
        }
      }
      .user-info{
        font-size: 14px;
        padding: 4px 0 14px;
        .user-name{
          margin-right: 18px;
        }
      }
    }
    .more-address{
      height: 40px;
      text-align: center;
      line-height: 40px;
      color: $darkBlackBase;
      font-size: $largeFontSize;
      .open{
        width: 14px;
        height: auto;
        margin-left: 4px;
        transition: transform .3s;
        transform: rotate(0)
      }
      .rotate{
        transform: rotate(180deg)
      }
    }
  }
  // 授权弹框
  .author-model{
    position: fixed;
    z-index: 99;
    .mask{
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: rgba($color: #000000, $alpha: .4)
    }
    .body{
      position: fixed;
      top: 179px;
      left: 50%;
      transform: translateX(-50%);
      width: 270px;
      background-color: #fff;
      border-radius: 12px;
      .title{
        padding-top: 20px;
        font-size: 18px;
        text-align: center;
        line-height: 25px;
        font-weight: bold;
      }
      .content{
        padding: 19px 12px 25px;
        font-size: 14px;
        color: $lightBlackBase;
      }
      .footer{
        display: flex;
        border-top: 1px solid #eee;
        height: 44px;
        line-height: 44px;
        text-align: center;
        font-size: 17px;
        .cancle{
          border-right: 1px solid #eee;
          flex: 1;
        }
        .sure{
          position: relative;
          flex: 1;
          color: #59CD41;
          button{
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            opacity: 0;
          }
        }
      }
    }
  }
  // 空白页面 样式
  .slot-msg{
    .location-btn{
      margin: 16px auto;
      width: 200px;
      height: 44px;
      border-radius: 22px;
      background-color: $orangeBase;
      color: $darkBlackBase;
      line-height: 44px;
    }
    .jump{
      color: $hyperlink;
    }
  }
}
</style>
