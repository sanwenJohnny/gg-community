<template>
  <div class="container">
    <div class="list2" v-if="canSelect.length + canNotSelect.length > 0">

      <div class="" v-if="sAgantAddress.addressId">
        <span class="tip red">选择小区代理点，可享受免费代收服务。</span>
        <div class="agant-view" @tap="handleAgantSelected">
          <span class="title">小区代理点</span>
          <p class="community-name">{{sAgantAddress.detailAddress}}</p>
          <span class="agant-info">小区代理: {{sAgantAddress.fullName}}  {{sAgantAddress.mobileNumber}}</span>
        </div>
      </div>

      <div v-if="canSelect.length > 0">
        <span class="tip">可用收货地址</span>
        <address-list :list="canSelect" :disabled="false" @selected="handleSelected"/>
      </div>

      <div v-if="canNotSelect.length > 0">
        <span class="tip">以下地址不在购买范围</span>
        <address-list :list="canNotSelect" :disabled="true"/>
      </div>

    </div>
    <div class="list2" v-else>
      <v-empty :image="emptyImg" message="您还没有收货地址哟~">
      </v-empty>
    </div>
    <div class="btn-view" :class="computedClass">
      <p class="primary-btn add" @tap="handleAdd">新增收货地址</p>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import tools from '@/utils'
import addressList from "../components/addressList"
import vEmpty from "@/components/empty"
import imgApi from "@/utils/imgApi"
export default {
  data () {
    return {
      canNotSelect:[],
      canSelect:[],
      emptyImg: imgApi.getRes('empty', 'location'),
    }
  },
  components:{ addressList, vEmpty },
  computed:{
    ...mapState('modAddress', ['sAgantAddress','sOrderAddress']),
    computedClass() {
      return tools.isIphoneX() ? 'iphonex' : ''
    },
  },
  methods: {
    ...mapActions('modAddress', ['orderReceiveAddresslistAction','setOrderAddressAction']),

    handleAdd(e) {
      if(this.canSelect.length + this.canNotSelect.length>=15) {
        this.$wxComps.warn('最多添加15个地址，请删除后再添加')
        return
      }
      this.$router.push({
        url: '/pages/address/edit/main?type=add'
      })
    },
    handleAgantSelected() {
      this.setAddress({addressId:this.sAgantAddress.addressId,addressType:2})
    },
    handleSelected(item) {
      this.setAddress({addressId:item.addressId,addressType:1})

    },
    setAddress(data) {
      this.setOrderAddressAction(data)
      this.$router.back()
    }
  },
  onShow () {
    const info = wx.getStorageSync("communityInfo") || {}
    const data = { cityCode: info.cityCode }
    this.orderReceiveAddresslistAction({data,showLoading:true}).then(res => {
      this.canSelect = res.canSelect
      this.canNotSelect = res.canNotSelect
    })
  },

}
</script>

<style scoped lang="scss">
.list2{
  box-sizing: border-box;
  height: 100%;
  padding-bottom: 56px;
  overflow-y: auto;
  background: $lightWhiteBase;
}
.tip{
  width: 100%;
  height: 32px;
  line-height: 32px;
  padding-left: 10px;
  color: $lightBlackBase;
  font-size: 12px;
  &.red{
    color: $darkOrangeBase;
  }
}
.btn-view{
  position: fixed;
  bottom: 0;
  width: 100%;
  height: 56px;
  .add{
    width: auto;
    margin: 6px 10px;
  }
}
.agant-view{
  box-sizing: border-box;
  width: 100%;
  background-color: $whiteBase;
  padding: 14px 10px;
  .title{
    height: 20px;
    line-height: 20px;
    background: $orangeBase;
    color: $blackBase;
    font-size: 12px;
    padding: 0 4px;
  }
  .community-name{
    font-size: 18px;
    color: $blackBase;
    margin-top: 15px;
  }
  .agant-info{
    color: $lightBlackBase;
    font-size: 16px;
    margin-top: 8px;
  }
}
</style>
