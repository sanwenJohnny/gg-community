<template>
  <div class="container">
    <div class="list" v-if="addrList.length>0">
      <address-list :list="addrList" :disabled="false"/>
    </div>
    <div class="list" v-else>
      <v-empty :image="emptyImg">
          <span>您还没有收货地址哟~</span>
      </v-empty>
    </div>
    <div class="btn-view" :class="computedClass">
      <p class="primary-btn add" @tap="handleAdd">新增收货地址</p>
    </div>
  </div>
</template>

<script>

import { mapState, mapActions } from 'vuex'
import tools from '@/utils'
import addressList from "../components/addressList"
import vEmpty from "@/components/empty"
import imgApi from "@/utils/imgApi"
export default {
  data () {
    return {
      addrList:[],
      emptyImg: imgApi.getRes('empty', 'location'),
    }
  },
  components:{ addressList, vEmpty },
  computed:{
    computedClass() {
      return tools.isIphoneX() ? 'iphonex' : ''
    },
  },
  methods: {
    ...mapActions('modAddress', ['allReceiveAddresslistAction']),

    handleAdd(e) {
      if(this.addrList.length>=15) {
        this.$wxComps.warn('最多添加15个地址，请删除后再添加')
        return
      }
      this.$router.push({
        url: '/pages/address/edit/main?type=add'
      })
    }
  },
  onShow () {
    this.allReceiveAddresslistAction().then(res => {
      this.addrList = res
    })
  }
}
</script>

<style scoped lang="scss">
.list{
  box-sizing: border-box;
  height: 100%;
  padding-bottom: 56px;
  overflow-y: auto;
  background: $lightWhiteBase;
}
.btn-view{
  position: fixed;
  bottom: 0;
  width: 100%;
  height: 56px;
  .add{
    width: auto;
    margin: 6px 10px;
  }
}
</style>
