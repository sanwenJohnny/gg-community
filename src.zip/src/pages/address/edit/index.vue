<template>
<div class="container" :class="{'ios': isIOS}">
  <div class="edit-view">
    <div class="edit-form">

      <div class="item b_bottom" @tap="toCityList">
        <span class="title">城市: </span>
        <span class="info ellipsis" :class="{'place-holder': isEmptyCity}">{{formData.city.name}}</span>
        <i class="icon" :style="{ backgroundImage: arrowImg }"></i>
      </div>

      <div class="item b_bottom" @tap="toCommunityList">
        <span class="title">小区: </span>
        <span class="info ellipsis" :class="{'place-holder': isEmptyCommunity}">{{formData.community.name}}</span>
        <i class="icon" :style="{ backgroundImage: arrowImg }"></i>
      </div>

      <div class="item b_bottom area">
        <span class="title">详细地址: </span>
        <textarea class="info txt-area" v-model="formData.detailAddress" maxlength="50" placeholder-style="color: #c2c2c2;" placeholder="如楼栋号，单元室，门牌号等"></textarea>
      </div>

      <div class="item b_bottom">
        <span class="title">联系人: </span>
        <input class="info" maxlength="10" v-model="formData.contact" placeholder-style="color: #c2c2c2;" placeholder="请输入" />
      </div>

      <div class="item">
        <span class="title">手机号: </span>
        <input class="info" maxlength="11" type="number" v-model="formData.phone" placeholder-style="color: #c2c2c2;" placeholder="请输入" />
      </div>

    </div>
    <div class="delete" v-if="editType === 'edit'" @tap="handleRemove">
      删除此收货地址
    </div>
    <button class="primary-btn save" :class="{'disabled': !canSave}" @tap="handleSave">保存</button>
  </div>
</div>
</template>

<script>
import {
  $
} from "@/utils"
import imgApi from "@/utils/imgApi"
import {
  mapState,
  mapActions
} from 'vuex'
export default {
  data() {
    return {
      editType: '',
      addressId: '',
      arrowImg: 'url(' + imgApi.getRes('orderSubmit', 'r_arrow') + ')',
      formData: {
        city: {
          code: '',
          name: '请选择收货城市'
        },
        community: {
          code: '',
          name: '请选择收货小区'
        },
        detailAddress: '',
        contact: '',
        phone: ''
      }
    }
  },
  components: {},
  computed: {
    ...mapState('modAddress', ['sSelectedCity', 'sSelectedCommunity']),
    isEmptyCity() {
      return this.formData.city.code === ''
    },
    isEmptyCommunity() {
      return this.formData.community.code === ''
    },
    canSave() {
      return this.formData.city.code !== '' && this.formData.community.code !== '' &&
        this.formData.detailAddress !== '' && this.formData.contact !== '' && this.formData.phone !== ''
    },
    isIOS() {
      const info = wx.getSystemInfoSync()
      return info.system.indexOf('iOS') > -1
    }
  },
  watch: {
    'sSelectedCity' (newV, oldV) {
      if (newV.code !== this.formData.city.code && newV.code) {
        this.formData.community = {
          code: '',
          name: '请选择收货小区'
        }
        this.formData.detailAddress = ''
      }
    },
    'sSelectedCommunity' (newV, oldV) {
      if (newV.code !== this.formData.community.code && newV.code) {
        this.formData.detailAddress = ''
      }
    },
  },
  methods: {
    ...mapActions('modAddress', ['setSelectedCityAction', 'setSelectedCommunityAction', 'saveAddressAction', 'deleteAddressAction', 'receiveAddressDetailAction']),
    toCityList() {
      this.$root.$mp.query = {
        type: 'city'
      }
      this.$router.push({
        url: '/pages/address/cities/main'
      })
    },
    toCommunityList() {
      if (!this.formData.city.code) {
        this.$wxComps.toast('请先选择城市')
        return false
      }
      this.$root.$mp.query = {
        type: 'community'
      }
      this.$router.push({
        url: '/pages/address/communities/main?citycode=' + this.formData.city.code
      })
    },
    handleRemove() {
      this.$wxComps.confirm('确认要删除此收货地址吗？').then(res => {
        if (!res) return
        const data = {
          addressId: this.addressId
        }
        this.deleteAddressAction({
          data
        }).then(res => {
          this.$wxComps.toast('删除成功')
          this.resetPage()
          this.$router.back()
        })
      })
    },
    handleSave(e) {
      if(!this.canSave) return
      let data = {
        cityCode: this.formData.city.code,
        communityId: this.formData.community.code,
        detailAddress: this.formData.detailAddress,
        fullName: this.formData.contact,
        mobileNumber: this.formData.phone
      }
      if (this.addressId) data = Object.assign(data, {
        addressId: this.addressId
      })
      this.saveAddressAction({
        data,
        showLoading: true
      }).then(res => {
        this.$wxComps.toast('保存成功')
        this.resetPage()
        this.$router.back()
      })
    },
    //重置页面
    resetPage() {
      this.formData = {
        city: {
          code: '',
          name: '请选择收货城市'
        },
        community: {
          code: '',
          name: '请选择收货小区'
        },
        detailAddress: '',
        contact: '',
        phone: ''
      }
    },
    getAddressDetail() {
      const data = {
        addressId: this.addressId
      }
      this.receiveAddressDetailAction({
        data,
        showLoading: true
      }).then(res => {
        this.formData = {
          city: {
            code: res.cityCode,
            name: res.cityName
          },
          community: {
            code: res.communityId,
            name: res.communityName
          },
          detailAddress: res.detailAddress,
          contact: res.fullName,
          phone: res.mobileNumber
        }
      })
    },
    onShowHandle() {
      switch (this.editType) {
        case 'edit':
          //编辑模式
          this.resetPage()
          this.getAddressDetail()
          break;
        case 'add':
          //新增模式
          this.resetPage()
          break;
        case 'city':
          //城市数据回填
          this.formData.city = Object.assign(this.formData.city, this.sSelectedCity)
          this.setSelectedCityAction({})
          break;
        case 'community':
          //小区数据回填
          this.formData.community = Object.assign(this.formData.community, this.sSelectedCommunity)
          this.setSelectedCommunityAction({})
          break;
        default:
          break;
      }
    }
  },
  mounted() {
    if (this.$root.$mp.query.type !== 'add') return
    const info = wx.getStorageSync("communityInfo") || {}
    this.formData.city = info.cityCode ? {
      code: info.cityCode,
      name: info.cityName
    } : {
      code: '',
      name: '请选择收货城市'
    }
    this.formData.community = info.communityId ? {
      code: info.communityId,
      name: info.communityName
    } : {
      code: '',
      name: '请选择收货小区'
    }
  },
  onShow() {
    console.log(this.$router.getPrev());
    this.editType = this.$root.$mp.query.type || ''
    this.onShowHandle()
  },
  onLoad() {
    this.addressId = this.$root.$mp.query.addressId || ''
    if (this.$root.$mp.query.type === 'add') {
      wx.setNavigationBarTitle({
        title: '新增收货地址'
      })

    }
  }
}
</script>

<style scoped lang="scss">
.txt-placeholder {
    color: $moreLightBlackBase;
    font-size: 16px;
}
.edit-view {
    width: 100%;
    height: 100%;
    background-color: $lightWhiteBase;
}
.edit-form {
    width: 100%;
    background: $whiteBase;
    .item {
        box-sizing: border-box;
        position: relative;
        display: flex;
        width: 100%;
        height: 54px;
        font-size: 16px;
        // padding: 19px 10px;
        &.area {
            height: 72px;
            .info {
                height: 50px;
            }
        }
        .title {
            position: absolute;
            left: 10px;
            top: 17px;
            font-family: PingFangSC-Medium,Roboto-Medium,Noto-Medium;
        }
        .info {
            position: absolute;
            display: inline-block;
            width: 232px;
            height: 22px;
            left: 98px;
            top: 17px;
            &.place-holder {
                color: $moreLightBlackBase;
            }
        }
        .icon {
            position: absolute;
            right: 10px;
            top: 19px;
            display: inline-block;
            width: 8px;
            height: 12px;
            margin-top: 2px;
            background-image: image();
            background-repeat: no-repeat;
            background-size: 100%;
        }
    }
}
.save {
    width: 355px;
    height: 44px;
    margin-top: 30px;
    margin-left: auto;
    margin-right: auto;
    &.disabled {
        opacity: 0.5;
    }
}
.delete {
    width: 100%;
    height: 54px;
    line-height: 54px;
    background-color: $whiteBase;
    color: #ff0000;
    font-size: 16px;
    padding: 0 10px;
    margin-top: 8px;
}
.ios .txt-area{
  top: 12px !important;
}
</style>
