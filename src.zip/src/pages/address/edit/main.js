import Vue from 'vue'
import App from './index'

const app = new Vue(App)
console.log('app:',app);
app.$mount()

export default {
  config: {
    "navigationBarTitleText": "修改收货地址"
  }
}
