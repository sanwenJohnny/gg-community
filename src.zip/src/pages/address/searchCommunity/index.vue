<template>
  <div class="container">
    <!-- 头部搜索框 -->
    <div class="header">
      <div class="search-input">
        <div class="search">
          <input class="input" type="text" confirm-type="搜索" @confirm="searchCommunity" v-model="communityName" placeholder="请输入小区名称">
          <img class="clear" mode="widthFix" :src="clearImg" @click="clear">
        </div>
        <div class="cancle" @click="goChooseArea">取消</div>
      </div>
    </div>
    <div class="no-result" v-if="resultCommunityList.length === 0 && over">
      <span class="result-tip">没有搜索到该小区</span>
      <span class="goAddCommunity" @click="goAddCommunity">创建该小区></span>
    </div>
    <!-- 搜索小区 -->
    <community v-if="resultCommunityList.length > 0" tip="none" :list="resultCommunityList"></community>
    <!-- 热门小区 -->
    <community v-if="hotCommunityList.length > 0" :list="hotCommunityList"></community>
  </div>
</template>

<script>
import imgApi from "@/utils/imgApi";
import { mapActions } from 'vuex';
import { $ } from "@/utils/index";
import community from "../components/communityList";

export default {
  data () {
    return {
      clearImg: imgApi.getRes("search","clear"),
      over: false,// 是否完成搜索
      communityName: "",
      hotCommunityList: [],
      resultCommunityList: []
    }
  },
  components: {
    community
  },
  mounted (){
    wx.hideShareMenu()
  },
  methods: {
    ...mapActions("modAddress",["searchCommunityAction"]),
    initPage (){},
    // 搜索小区
    searchCommunity (){
      const communityInfo = wx.getStorageSync("communityInfo") || {}
      this.searchCommunityAction({
        data:{
          cityCode: communityInfo.cityCode,
          communityName: this.communityName
        }
      })
      .then(data=>{
        this.over = true
        this.hotCommunityList = data.hotCommunityList || []
        this.resultCommunityList = data.resultCommunityList || []
      })
    },
    // 前往选择地区页
    goChooseArea(){
      this.$router.back({delta: 1})
    },
    // 前往创建小区
    goAddCommunity(){
      this.$router.push({url: "/pages/house/apply/main"})
    },
    // 清空数据
    clear(){
      Object.assign(this.$data, this.$options.data())
    }
  }
}
</script>

<style scoped lang="scss">

.container{
  // 头部搜索框
  .header{
    padding: 9px 10px ;
    background-color: #fff;

    .search-input{
      height: 32px;
      display: flex;
      align-items: center;
      .cancle{
        width: 40px;
        text-align: right;
      }
      .search{
        background-color: #f3f3f3;
        position: relative;
        flex: 1;
        padding-right: 36px;
        border-radius: 2px;
        .clear{
          position: absolute;
          top: 50%;
          right: 10px;
          transform: translateY(-50%);
          width: 14px;
        }
        .input{
          color: $lightBlackBase;
          font-size: 13px;
          padding-left: 8px;
          height: 32px;
        }
      }
    }
  }
  // 没有数据
  .no-result{
    height: 64px;
    line-height: 64px;
    text-align: center;
    .result-tip{
      color: $lightBlackBase;
      font-size: 14px;
      margin-right: 5px;
    }
    .goAddCommunity{
      color: #0076FF;
    }
  }
}
</style>
