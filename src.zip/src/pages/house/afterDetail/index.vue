<template>
  <div class="after-detail">
    <!-- 退款状态 -->
    <section class="refund-info-top align-c">

      <!-- 退款中 -->
      <div v-if="afterDetailInfo.status == 1">
        <p class="title-1 mb-10">
          {{ afterDetailInfo.statusDesc }}
        </p>
        <p>
          <i class="revocation-btn right f-12" :class="{'disabled': promptStatus == 0}" @tap="toUrge">{{ promptStatus == 1 ? '催促' : '已催促' }}</i>            
          {{ afterDetailInfo.promptDesc }}
        </p>
      </div>

      <!-- 退款取消 -->
      <p v-if="afterDetailInfo.status == 4" class="title-1">{{ afterDetailInfo.statusDesc }}</p>

      <!-- 退款拒绝 -->
      <div v-if="afterDetailInfo.status == 3">
        <p class="title-1 mb-10">
          {{ afterDetailInfo.statusDesc }}
        </p>
        <p>拒绝原因：{{ afterDetailInfo.rejectReason }}</p>
      </div>

      <!-- 退款完成 -->
      <div v-if="afterDetailInfo.status == 2">
        <p class="title-1 mb-10">退款成功</p>
        <div>
          <span class="refund-text">实际退款金额：¥{{ afterDetailInfo.realRefundMoney }}</span> <br>
          <span class="refund-text">返还G币：{{ afterDetailInfo.refundCoin }}个</span> <br>
          <span class="refund-text last-text">退款时间：{{ afterDetailInfo.refundTime }}</span>
        </div>
      </div>
    </section>

    <!-- 退款信息 -->
    <div class="refund-info">
        <div class="info-title b_bottom">退款信息</div>
        <div class="content-spacing">        
            <!-- 商品信息 -->
            <div class="goods-info b_bottom item">
                <!-- 商品图 -->
                <div class="goods-thumbnail">
                    <img class="good-pic" :src="afterDetailInfo.productImg" alt="" />
                </div>
                <!-- 右侧商品信息 -->
                <div class="goods-right">
                    <!-- 商品详情 -->
                    <div class="goods-detail">
                        <div class="goods-title">{{ afterDetailInfo.productName }}</div>
                        <div class="goods-count">x{{ afterDetailInfo.productCount }}</div>
                    </div>
                    <div class="refund-amount">
                        <span>合计:</span><span class="unit">￥</span><span class="number">{{ afterDetailInfo.productTotalPrice }}</span>
                        <span>(¥{{ afterDetailInfo.productSalesPrice }}x{{ afterDetailInfo.productCount }})</span>
                    </div>
                </div>
            </div>
            <!-- 退款信息 -->
            <div class="order-info b_bottom">
                <div class="order-left">
                    <div class="row">
                        <span class="name">退款原因：</span><span class="text">{{ afterDetailInfo.refundReason }}</span>
                    </div>
                    <div class="row">
                        <span class="name">退款金额：¥</span><span class="text">{{ afterDetailInfo.refundMoney }}</span>
                    </div>
                    <div v-if="afterDetailInfo.applyTime" class="row">
                        <span class="name">申请时间：</span><span class="text">{{ afterDetailInfo.applyTime }}</span>
                    </div>
                    <div class="row last-row">
                        <span class="name">订单编号：</span><span class="text">{{ afterDetailInfo.orderNumber }}</span>
                    </div>
                </div>
                <button class="order-right btn copy" @tap="copy">复制</button>
            </div>
            <!-- 人员信息 -->
            <div class="person-info">
                <div class="consignee">
                    <div class="row">
                        <span class="name">{{ receiveInfo.type === 1 ? '收货人：': '提货人：' }}</span>
                        <span class="text">{{ receiveInfo.receiver }}</span>
                    </div>            
                    <div class="row">
                        <span class="name">{{ receiveInfo.type === 1 ? '收货手机号：': '提货手机号：' }}</span>
                        <span class="text">{{ receiveInfo.mobileNumber }}</span>
                    </div>            
                    <div class="row last-row">
                        <span class="name">{{ receiveInfo.type === 1 ? '收货地址：': '备注：' }}</span>
                        <span class="text textarea">{{ receiveInfo.receiveAddress || '无'  }}</span>  
                    </div>
                </div>                   
            </div>
        </div>
        <!-- 商家信息 -->
        <div class="seller-info">
            <div class="seller-left">
                <div class="row">
                    <span class="name">商家名称：</span>
                    <span class="text">{{ afterDetailInfo.shopName }}</span>
                </div>
                <div class="row">
                    <span class="name">商家联系方式：</span>
                    <span class="text">{{ afterDetailInfo.shopContactNumber }}</span>
                </div>
                <div class="row last-row">
                    <span class="name">当天营业时间：</span>
                    <span class="text textarea">{{ afterDetailInfo.workTime || '无' }}</span>
                </div>
            </div>
            <button class="seller-right btn" @tap="contactSeller">联系商家</button>
        </div>
        <!-- 联系商家 -->
        <div class="contact-seller" @tap="contactService">
            <span>联系平台客服</span>
            <span class="img-content">
                <img class="contact-icon" :src="arrowIcon" alt="">        
            </span>
        </div>
        <!-- 间距 -->
        <div class="space-height"></div>
    </div>
  </div>
</template>

<script>
import imgApi from "@/utils/imgApi"
import { mapState, mapActions } from 'vuex'
import { $ } from "@/utils/index";

export default {
  name:'afterDetail',    
  data () {
    return {
      arrowIcon: imgApi.getRes('orderSubmit', 'r_arrow'),
      // urgeText: '催促',  
      disabled: false,
      afterDetailInfo: {},
      // 收货人、提货人信息
      receiveInfo: '',
      refundNumber:'',
      promptStatus: ''
    }
  },
  components: {
  },
  computed: {
  },
  methods: {
    ...mapActions('modHouse', ['getAfterDetailInfoAction','getAfterDetailPrompt']),    
    // 催促
    toUrge() {
        if(this.afterDetailInfo.canPrompt === 0) return
        const data = {refundNumber: this.refundNumber}      
        this.getAfterDetailPrompt({data, showLoading:true}).then(res => {
            this.promptStatus = 0
        })
    },
    // 复制订单编号  
    copy() {
      $(wx.setClipboardData, {
        data: this.afterDetailInfo.orderNumber+''
      }).then(res => {
        $(wx.getClipboardData).then(res => {            
          console.log(res.data)
        })
        $(wx.showToast, {
          title: '订单编号已复制到剪切板',
          icon: 'none',
          duration: 2000
        })
      })
    },
    // 联系商家
    contactSeller() {
      $(wx.makePhoneCall, {
        phoneNumber: this.afterDetailInfo.shopContactNumber+''
      })
    },
    // 联系客服
    contactService() {
      $(wx.makePhoneCall, {
        phoneNumber: this.afterDetailInfo.platformCS
      })
    }
  },
  mounted() {
  },
  onShow () {
    this.refundNumber = this.$root.$mp.query.refundNumber || ''      
    const data = { refundNumber: this.refundNumber }
    this.getAfterDetailInfoAction({data,showLoading:true}).then(res => {
      this.receiveInfo = res.receiveInfo
      this.afterDetailInfo = res
      this.promptStatus = res.canPrompt
    })
  },
}
</script>

<style scoped lang="scss">
@import "../../../css/mixins";
@import "../../../css/common";
.mb-10 {
  margin-bottom: 10px;
}
.title-1 {
  font-size: 16px;
  color: #333;
  font-weight: bold;
}
.align-c {
  align-items:center;
}
p {
    color: #333;
}
.btn {
    background: #FFF;
    @include Height(24);    
    font-size: 12px;
    color: #333;
    border: 1px solid #333;
    border-radius: 57px;
    text-align: center                  
}
.refund-info-top {
  display: flex;
  width: 100%;
  min-height: 80px;
  padding: 16px 10px;
  box-sizing: border-box;
  background: #FDF6B1;
  color: #915906;
  margin-bottom:8px;
  > div {
    flex: 1;
  }
  .refund-text {
      color:#333;
      font-size: 14px;
      line-height: 18px;
      margin-bottom: 10px;
      display: inline-block;
  }
  .last-text {
      margin-bottom: 0;
  }
  .revocation-btn {
    width: 78px;
    margin-left: 27px;
    @include Height(38);
    @extend .t-c;
    color: #333;
    background: #FFE000;
    border-radius: 71px;
    &.disabled{
        opacity: .5;
    }
  }
}
.after-detail {
    .refund-info {
        height: 153px;
        .info-title {
            font-size: 14px;
            color: #333;
            @include Height(44);
            padding-left: 10px;
            background-color: #FFF;
            box-shadow: inset 0 0 0 0 #EEEEEE;
        }
        .row {
            margin-bottom: 14px;
            font-size: 14px;
            color: #333;
            line-height: 14px;
            .textarea {
                height: auto;
                line-height: 16px;
            }
        }
        .last-row {
            margin-bottom: 0;            
            display: flex;                    
            .text {
                flex: 1;
                margin-right: 10px;
            }
        } 
        .goods-info {
            padding: 16px 10px 18px 10px;
            box-sizing: border-box;
            width: 100%;
            height: 96px;
            background: #FFF;          
            box-shadow: inset 0 0 0 0 #EEE;
            display: flex;
            justify-content: space-between;
            .goods-thumbnail {
                position: relative;
                width: 62px;
                height: 62px;
                overflow: hidden;
                margin-right: 8px;
                background: #ccc;
                .good-pic {
                    position: absolute;
                    width: 100%;
                    height: 100%;
                    left: 0;
                    top: 50%;
                    transform: translateY(-50%);
                }
            }
            .goods-right {
                flex: 1;
                .goods-detail {
                    height: 32px;
                    .goods-title {
                        display: inline-block;                    
                        font-size: 14px;
                        line-height: 16px;
                        width: 85%;
                    }
                    .goods-count {
                        float: right;              
                        font-size: 14px;
                        color: #C2C2C2;
                        text-align: right;
                        line-height: 14px;
                    }
                }
                .refund-amount {
                    height: 46px;
                    line-height: 46px;
                    font-size: 12px;
                    color: #333;
                    text-align: left;
                    .unit {      
                        margin: 0 -3px;
                    }
                }
            }
        }
        .content-spacing {
            padding-left: 10px;
            background-color:#fff;
            .order-info {
                display: flex;
                height: 135px;
                box-sizing: border-box;
                padding: 16px 10px 21px 0;       
                .order-left {
                    flex: 1;                
                }
                .order-right {
                    align-self: flex-end;
                    width: 48px;
                    &.copy {
                        position: relative;
                        top: 7px;
                    }
                }
            }
            .person-info {
                min-height: 102px;
                padding: 16px 0;
                box-sizing: border-box;
                margin-bottom: 8px;      
            }
        }
        .seller-info {
            height: 102px;
            padding: 0 10px;
            margin-bottom: 8px;
            background: #FFF;
            display: flex;
            align-items: center;
            .seller-left {
                flex: 1;
            }
            .seller-right {
                width: 76px;
            }
        }
        .contact-seller {
            padding: 0 10px;
            background: #FFF;
            @include Height(44);
            font-size: 14px;
            color: #333;
            .img-content {
                float: right;
                .contact-icon {
                    width: 10px;
                    height: 16px;
                    vertical-align: middle;
                    line-height: 44px;
                }
            }
        }
        .space-height {
            height: 30px;
        }
    }
}

</style>
