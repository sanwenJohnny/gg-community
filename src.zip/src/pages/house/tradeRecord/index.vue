<template>
  <div class="trade-record">
    <!-- 交易记录头部内容 -->
    <div class="trade-top">
        <!-- 搜索 -->
        <div class="search-content">
            <search-bar ref="searchBar" @getList="getList"></search-bar>
        </div>
        <!-- 交易记录状态切换 -->
        <nav-tab @clearSearch="clearSearchValue" @getTradeRecord="init" :tabType="tabType" :navName="tabList"></nav-tab>
    </div>
    <!-- 交易记录信息列表 -->
    <div class="trade-content">
      <div v-if="tradeLists.length>0">
        <div class="trade-list" v-for="(item,i) in tradeLists" :key="i" @tap="toTradeDetail(item)">
            <trade-list :tradeInfo="item"></trade-list>
        </div>
      </div>
      <div class="empty" v-show="!tradeLists.length && showEmpty">
          <v-empty :image="emptyImg">您还没有相关的订单哟~</v-empty>            
      </div>
      <load-more v-if="loading"></load-more>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import utils from 'u'
import searchBar from "@/pages/house/components/searchBar/index"
import tradeList from "@/pages/house/components/tradeList/index"
import navTab from "@/pages/house/components/navTab/index"
import loadMore from '@/components/loadMore'
import imgApi from "@/utils/imgApi"
import vEmpty from "@/components/empty"
export default {
  name:'tradeRecord',    
  components: {
    searchBar,
    tradeList,
    navTab,
    loadMore,
    vEmpty
  },
  data () {
    return {
      emptyImg: imgApi.getRes("empty","order"),                    
      tabList: ['全部', '待结算', '已结算', '已取消'],
      tabType: 'tradeRecord',
      tradeLists: [],   
      page:1,
      pageSize:20,
      status:0,
      total:0,
      loading:false,
      showEmpty:false
    }
  },
  computed: {
    ...mapState('modHouse', ['sTradeRecordType']),      
  },
  methods: {
    ...mapActions('modHouse', ['getTradeRecordListAction']),
    init() {
      this.page = 1
      this.tradeLists = []
      this.showEmpty = false      
      this.getList()
    },
    getList(searchValue) {
      let data = {
        page: this.page,
        pageSize: this.pageSize,
        status: this.sTradeRecordType,
        queryId: searchValue || ''
      }
      if(!this.loading){
        utils.loading()   
      }         
      if (searchValue) {
        this.showEmpty = false        
        this.tradeLists = []
      }
      this.getTradeRecordListAction({data}).then(res => {
        utils.loaded()                                     
        wx.stopPullDownRefresh()        
        this.tradeLists = [
          ...this.tradeLists,
          ...res.list
        ]
        this.showEmpty = this.tradeLists.length>0?false:true       
        this.total = res.total
        this.loading = false
      })
    },
    // 跳转到详情页并清空搜索值
    toTradeDetail(item){
      this.clearSearchValue()
      this.$router.push({
        url: `/pages/house/tradeDetail/main?orderNumber=${item.orderNumber}`            
      })
    },
    // 清空搜索值
    clearSearchValue() {
      this.$refs.searchBar.clearSearchValue()
    }
  },
  // 下拉刷新
  onPullDownRefresh(){
    this.init()
  },
  // 上拉加载
  onReachBottom(){
    if(Math.ceil(this.total / this.pageSize) > this.page) {
      this.page++
      this.loading = true
      setTimeout(()=> {
        this.getList()
      },200)
    }
  },
  mounted() {
    this.clearSearchValue()
    this.init()  
  },
  onShow () {
  },
}
</script>

<style scoped lang="scss">
.empty {
  box-sizing: border-box;
  height: 100%;
  padding-bottom: 56px;
  overflow-y: auto;
  background: $lightWhiteBase;
}
.trade-record {
  .trade-top {
      position: fixed;
      top: 0;
      left: 0;
      z-index: 9;
      width: 100%;
      height: 84px;
      background-color: #fff;
      .search-content {
        height: 40px;
        line-height: 40px;
        padding: 0 10px;
      }
  }
  .trade-content {
    width: 100%;
    position: absolute;
    top: 84px;
    left: 0;
  }
}

</style>
