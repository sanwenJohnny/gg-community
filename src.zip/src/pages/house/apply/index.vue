<template>
  <div>开通小区 好处多多</div>
</template>

<script>
export default {
  
}
</script>

<style scoped lang="scss">

</style>
