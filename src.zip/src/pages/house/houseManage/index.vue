<template>
  <div class="house-container">
    <!--上半内容部分 -->
    <div class="up-content">
        <!-- 数据卡片 -->
        <div class="card">
            <div class="card-header">
                <span class="manage-data f_bold">经营数据</span>
                <span class="manage-more more-data" @tap="toBusinessCenter">
                    <span>更多数据</span>
                    <img class="afterSalesImg-icon" :src="jumpArrowImg" alt="">
                </span>   
            </div>
            <div class="static">
                <!-- 访问量 -->
                <span class="flex-item">
                    <span class="number ellipsis f_bold">{{ staticNumber.todayVisit || '0' }}人</span>
                    <span class="name">今日访问</span>
                </span>
                <!-- 订单 -->
                <span class="flex-item">
                    <span class="number ellipsis f_bold">{{ staticNumber.todayOrders || '0' }}笔</span>
                    <span class="name">今日订单</span>
                </span>
                <!-- 收入 -->
                <span class="flex-item">
                    <span class="number ellipsis f_bold">{{ staticNumber.todayIncoming || '0' }}</span>
                    <span class="name">今日收入</span>
                </span>
                <!-- 销售额 -->
                <span class="flex-item">
                    <span class="number ellipsis f_bold">{{ staticNumber.todaySalesAmount || '0' }}</span>
                    <span class="name">今日销售额</span>
                </span>
            </div>
        </div>
        <!-- 交易订单和售后 -->
        <div class="other-opera">
            <!-- 交易订单 -->
            <div class="opera-flex trading-order" @tap="toTradeRecord">
                <!-- icon -->
                <img class="transOrder-icon" :src="transOrderImg" alt="">
                <div>交易订单</div>
            </div>
            <!-- 售后 -->
            <div class="opera-flex after-sales" @tap="toAfterSales">
                <!-- icon -->
                <img class="afterSales-icon" :src="afterSalesImg" alt="">
                <div>售后</div>
            </div>
        </div>
    </div>
    <div class="house-center"></div>
    <!-- 商品销量top3部分 -->
    <div class="goods-top">
        <div class="top-header">
            <span class="top-title f_bold">昨日商品销量TOP3</span>
            <span class="top-more more-data" @tap="toSalesCenter">
                <span>更多数据</span>
                <img class="afterSalesImg-icon" :src="jumpArrowImg" alt="">
            </span> 
        </div>
        <!-- 前3商品列表 -->
        <div class="goods-list" v-show="goodLists.length>0" v-for="(item, i) in goodLists" :key="i">
            <good-list :goodInfo='item'></good-list>
        </div>
        <div class="empty" v-show="!goodLists.length">
            <v-empty :image="emptyImg" :topHeight='50'>暂无销量，快去推广吧~</v-empty>
        </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import imgApi from "@/utils/imgApi"
import goodList from "@/pages/house/components/goodList/index"
import vEmpty from "@/components/empty"
export default {
  name:'houseManage',    
  data () {
    return {
      transOrderImg: imgApi.getRes("houseManage","transOrder"),
      jumpArrowImg: imgApi.getRes("houseManage","jumpArrow"),
      afterSalesImg: imgApi.getRes("houseManage","afterSales"),
      emptyImg: imgApi.getRes("empty","houseManage"),
      // top3商品列表
      goodLists: [],
      // 访问统计
      staticNumber: ''
    }
  },
  components: {
    goodList,
    vEmpty
  },
  computed:{

  },

  onShow () {
    this.initPage()
  },

  // 下拉刷新
  onPullDownRefresh(){
    this.initPage()
  },

  methods: {
    ...mapActions('modHouse', ['getHouseManageDataAction','setTradeRecordTypeAction', 'setSalesCenterTypeAction', 'setAfterSalesTypeAction']),   
       
    // 初始化页面
    initPage() {
        this.getHouseManageDataAction().then(res => {
            wx.stopPullDownRefresh()            
            this.staticNumber = res.todaySummaryVO || ''
            this.goodLists = res.todayTop3 || []
        });
    },

    // 跳转到经营数据中心
    toBusinessCenter(){
        this.$router.push({
            url: '/pages/house/businessCenter/main'
        })
    },

    // 跳转到商品销售中心
    toSalesCenter(){
        this.setSalesCenterTypeAction({type:1})              
        this.$router.push({
            url: '/pages/house/salesCenter/main'
        })
    },

    // 跳转到订单交易记录
    toTradeRecord(){
        this.setTradeRecordTypeAction({status:0})      
        this.$router.push({
            url: '/pages/house/tradeRecord/main'
        })
    },

    // 跳转到售后
    toAfterSales(){
        this.setAfterSalesTypeAction({type:0})          
        this.$router.push({
            url: '/pages/house/afterSales/main'
        })
    },

  },
  created () {
  },
  mounted() {
  }
}
</script>

<style scoped lang="scss">
@import "../../../css/mixins";
@import "../../../css/common";
.empty{
  background: $whiteBase;
}
.house-container {
   box-sizing: border-box; 
   height: 100%;
   width: 100%;
    background: $whiteBase;   
    .up-content {
        padding: 10px 10px 0;
        .card {
        background-image: linear-gradient(45deg, #FFD300 0%, #FFBC00 100%);
        border-radius: 6px;
        opacity:0.8;
        padding: 20px 14px 0;
        .card-header {
            height: 16px;
            line-height: 16px;   
            color: #333;                   
            .manage-data {
                font-size: 16px;
            }
        }
        .static {
            height: 94px;
            width:100%;
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
            .flex-item {
                width: 25%;
                display: inline-block;
                text-align: center;            
                .number {
                    width: 100%;
                    display: inline-block;
                    font-size: 18px;
                    color: $darkBlackBase;
                    line-height: 18px;
                }
                .name {
                    font-size: 12px;
                    color: #998433;
                    position:relative;
                    top:-2px;
                }
            }
        }
        }
        .other-opera {
        width: 100%;
        height: 106px;
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
        align-items: center;      
        text-align: center;
        color: #747474;
        .opera-flex {
            width: 25%;
            .transOrder-icon,.afterSales-icon {
            width: 38px;
            height: 38px;
            vertical-align: middle;
            display: inline-block;
            margin-bottom: 8px;
            }
        }
        }
    }
    .house-center {
        height: 8px;
        width: 100%;
        background: #F3F3F3;
    }
    .more-data {
        float: right;
        font-size: 12px;
        margin-bottom: 10px;
        .afterSalesImg-icon {
            width: 6px;
            height: 10px;
            vertical-align: middle;
            margin-left: 5px;
        }
    }
    .goods-top {
        box-sizing: border-box;
        padding: 20px 0 10px 10px;
        background-color: $whiteBase;
        .top-header {
        padding-right: 10px;
        height: 22px;
        line-height: 22px;
        .top-title {
            font-size: 16px;
            color: #333;
        }
        .top-more {
            color: #747474;
        }
        }
    }
}
</style>
