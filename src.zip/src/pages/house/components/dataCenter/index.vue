<template>
 <div class="data-center">
     <!-- 名称 -->
    <div class="title-name">
        <div v-if="type === 1" class="static-header f_bold">{{ staticData.communityName }}</div>
        <div v-if="type === 0" class="static-header f_bold">{{ staticData.summaryMonth || '销售概括' }}</div>        
    </div>
    
    <!-- 数据 -->
    <div class="data-content">
        <!-- 访问量 -->
        <span class="flex-item">
            <span class="number ellipsis f_bold">{{ staticData.todayVisit }}人</span>
            <span class="name">{{ type === 1 ? '今日访问' : '访问量' }}</span>
        </span>
        <!-- 订单 -->
        <span class="flex-item">
            <span class="number ellipsis f_bold">{{ staticData.todayOrders }}笔</span>
            <span class="name">{{ type === 1 ? '今日订单' : '订单' }}</span>
        </span>
        <!-- 收入 -->
        <span class="flex-item">
            <span class="number ellipsis f_bold">{{ staticData.todayIncoming }}</span>
            <span class="name">{{ type === 1 ? '今日收入' : '收入' }}</span>
        </span>
        <!-- 销售额 -->
        <span class="flex-item">
            <span class="number ellipsis f_bold">{{ staticData.todaySalesAmount }}</span>
            <span class="name">{{ type === 1 ? '今日销售额' : '销售额' }}</span>
        </span> 
    </div>
 </div>
</template>

<script>
export default {
  name: 'dataCenter',
  props: {
    // 统计数据
    staticData: {
        type: Object,
        default: {}
    },
    // 统计类型
    type:{
        type: String,
        default: ''
    }
  },
  data () {
    return {
    }
  },
  computed:{
  },
  methods: {
  },
  created () {
  }
}
</script>

<style scoped lang="scss">
.data-center {
  height: 127px;
  width: 100%;
  background: #fff;
  margin-top: 8px;
  .title-name {
    padding:20px 0 0 10px;
    height: 36px;
    line-height: 36px;
    .static-header {
        border-left: 2px solid #747474;
        padding-left: 6px;
        font-size: 16px;
        color: #747474;
        line-height: 16px;
        height: 16px;
    }
  }
  .data-content {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    height: 91px;
    width: 100%;
    text-align: center;
    .flex-item {
        width: 25%;
        display: inline-block;
    }
    .number {
        display:inline-block;
        font-size: 18px;
        width: 100%;
        color: #000;
        line-height: 18px;
        margin-bottom: 10px;
    }
    .name {
        font-size: 12px;
        color: #747474;  
    }
  }
}
</style>
