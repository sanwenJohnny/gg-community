<template>
<div class="order_nav">
    <!-- tab -->
    <div v-if="tabType=='tradeRecord'" class="tab" v-for="(name,i) in navName" :key="i" :class="{active: sTradeRecordType == i}" @click="changeTab(i)">
      <!-- 字段 -->
      <div class="f_sub text">{{name}}</div>
      <!-- 下划线 -->
      <div class="underline"></div>
    </div>

    <div v-if="tabType=='salesCenter'" class="tab" v-for="(name,i) in navName" :key="i" :class="{active: (sSalesCenterType-1) == i}" @click="changeTab(i)">
      <!-- 字段 -->
      <div class="f_sub text">{{name}}</div>
      <!-- 下划线 -->
      <div class="underline"></div>
    </div>

    <div v-if="tabType=='afterSales'" class="tab" v-for="(name,i) in navName" :key="i" :class="{active: sAfterSalesType == i}" @click="changeTab(i)">
      <!-- 字段 -->
      <div class="f_sub text">{{name}}</div>
      <!-- 下划线 -->
      <div class="underline"></div>
    </div>
</div>

</template>

<script>
import { mapState, mapActions } from 'vuex'
import constants from "@/utils/constants"
const consts = constants.consts

export default {
  name:'navTab',
  props:{
      // tab名称
      navName:{
        type: Array,
        default:[]          
      },
      // 哪个组件的tab
      tabType:{
        type: String,
        default:''
      }
  },
  data () {
    return {
      activeIndex: 0,
      tabList: []
    }
  },
  computed:{
    ...mapState('modHouse', ['sTradeRecordType', 'sSalesCenterType', 'sAfterSalesType']),  
  },
  methods: {
    ...mapActions('modHouse', ['setTradeRecordTypeAction', 'setSalesCenterTypeAction', 'setAfterSalesTypeAction']),
    changeTab(i) {
        this.activeIndex = i    
        switch(this.tabType) {
            // 交易记录            
            case 'tradeRecord':
                this.setTradeRecordTypeAction({
                    status: consts.tradeRecordType[this.navName[i]]
                })
                this.$emit('getTradeRecord')
                this.$emit('clearSearch')
                break;
            // 商品销售中心                
            case 'salesCenter':
                this.setSalesCenterTypeAction({
                    type: consts.salesCenterType[this.navName[i]]
                })
                this.$emit("getSalesCenter")              
                break;
            // 售后   
            case 'afterSales':
                this.setAfterSalesTypeAction({
                    type: consts.afterSalesType[this.navName[i]]
                })
                this.$emit('getAfterSales')                
                this.$emit('clearSearch')                
                break;
            default:
                break;
        }
    }
  },
  mounted () { 
  }
}
</script>

<style scoped lang="scss">
.order_nav {
  display: flex;
  justify-content: space-around;
  background: #fff;
  height: 44px;
  box-sizing: border-box;
  padding-top: 16px;
  padding-bottom: 8px;
  // tab
  .tab {
    // 选中
    &.active {
      .text {
        color: #000;
      }
      .underline {
        opacity: 1;
      }
    }
    // 文字
    .text {
      font-size: 14px;
      margin-bottom: 6px;
    }
    // 下划线
    .underline {
      width: 100%;
      height: 2px;
      background: #000;
      opacity: 0;
    }
  }
}
</style>
