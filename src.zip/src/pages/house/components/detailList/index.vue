<template>
    <div class="container b_bottom item">
        <!-- 商品图 -->
        <div class="goods-thumbnail">
            <img class="good-pic" :src="detailInfo.productImg" alt="" />
        </div>
        <!-- 右侧商品信息 -->
        <div class="goods-right">
            <!-- 商品详情 -->
            <div class="goods-title">{{ detailInfo.productName }}</div>
            <div class="goods-amount">
                <div class="goods-prive">
                    <span class="unit">￥</span><span class="number">{{ detailInfo.memberPrice || '0' }}</span>
                </div>
                <div class="goods-count">x{{ detailInfo.productCount }}</div>                
            </div>
        </div>
    </div>
 
</template>

<script>
export default {
  name:'detailList',
  props: {
    // 售后列表信息
    detailInfo: {
        type: Object,
        defalut: {}
    },
  },
  data () {
    return {
    }
  },
  computed:{
  },
  methods: {
  },
  mounted () {
  }
}
</script>

<style scoped lang="scss">
.container {
    box-sizing: border-box;
    padding: 12px 0;
    height: 86px;
    box-shadow: inset 0 0 0 0 #EEE;
    display: flex;
    justify-content: space-between;
    width: 100%;
    .goods-thumbnail {
        position: relative;
        width: 62px;
        height: 62px;
        overflow: hidden;
        margin-right: 8px;
        background: #ccc;
        img {
            position: absolute;
            width: 100%;
            height: 100%;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
        }
    }
    .goods-right {  
        flex: 1;
        display: flex;
        justify-content: flex-start;       
        .goods-title {
            display: inline-block;                 
            font-size: 14px;
            line-height: 16px;
            width: 60%;              
        }
        .goods-amount {
            display: inline-block;
            flex: 1;
            margin-right:10px;
            font-size: 14px;
            color: #333;
            text-align: right;
            .unit {
                margin: 0 -3px;
            }
            .goods-count {
                margin-top: 4px;             
                font-size: 14px;
                color: #C2C2C2;
                text-align: right;
                line-height: 14px;
            }
        }
    }
}
</style>
