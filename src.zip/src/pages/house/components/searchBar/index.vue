<template>
 <div class="search-bar">
    <input type="text" class="search-input" placeholder="订单号/用户ID" v-model="value"/>
    <span class="search-click" @click="search()">{{ operaText }}</span>		
 </div>
</template>

<script>
export default {
  name:'searchBar',
  props:{
    // 哪个组件seearch
    searchType:{
      type: String,
      default:''
    }
  },
  data () {
    return {
      value: '',
      operaText: '搜索'
    }
  },
  computed:{
  },
  watch: {
    'value' (newValue, oldValue) {
      this.operaText = '搜索'      
    }
  },
  methods: {
    // 清空搜索
    clearSearchValue() {
      this.value = ''
      this.operaText = '搜索'
    },
    // 点击搜索
    search() {
      let isNumber = /^[0-9]+$/
      if (isNumber.test(this.value)) {
        if(this.operaText === '搜索' ) {
          this.operaText = '取消'
        } else {
          this.operaText = '搜索'   
          this.value = ''
        }
        this.$emit('getList', this.value)                  
      } else {
        this.$wxComps.toast('请输入正确的订单号或用户ID');
      }
         
    },
  },
  mounted() {
  }
}
</script>

<style scoped lang="scss">
.search-bar {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  height: 40px;
  align-items: center;
  line-height: 32px;
  .search-input {
    padding:0 16px;
    width: 100%;
    background: #F3F3F3;
    border-radius: 16px;
    font-size: 14px;
    color: #747474;
    letter-spacing: 0;
    line-height: 32px;
    height: 32px;
  }
  .search-click {
    font-size: 14px;
    color: #333;
    letter-spacing: 0;
    margin-left: 12px;
    width: 10%;
  }
}
</style>
