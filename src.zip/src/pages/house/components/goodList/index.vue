<template>
 <div class="container b_bottom item">
     <!-- 商品图 -->
     <div class="goods-thumbnail">
         <img class="good-pic" :src="goodInfo.skuImg" alt="" />
     </div>
      <!-- 右侧商品信息 -->
     <div class="goods-right">
        <!-- 商品详情 -->
        <div class="goods-detail">
            <!-- 标题 -->
            <div class="title">{{ goodInfo.skuName }}</div>
        </div>
        <!-- 价格和数量 -->
        <div class="p_n">
            <!-- 价格 -->
            <div class="price">
                <span class="unit_1">￥</span><span class="number">{{ goodInfo.nonMemberPrice }}</span>
                <span class="unit_2">￥</span><span class="discount">{{ goodInfo.memberPrice }}</span>
                <span class="vip">会员价</span>
            </div>
            <!-- 销量 -->
            <div class="sales">
              <span class="text">销量</span><span class="text_number">{{ goodInfo.salesAmount }}</span>
            </div>
        </div>
     </div>
 </div>
</template>

<script>
import imgApi from "@/utils/imgApi"
export default {
  name:'goodList',
  props: {
    goodInfo: {
      type: Object,
      default: {}
    }
  },
  data () {
    return {
      
    }
  },
  computed:{
  },
  methods: {
  },
  mounted () {
    
  }
}
</script>

<style scoped lang="scss">
.container {
  width: 100%;
  height: 100px;
  box-shadow: inset 0 0 0 0 #EEE;
  display: flex;
  justify-content: space-between;
  padding: 14px 0;
  .goods-thumbnail {
    position: relative;
    width: 72px;
    height: 72px;
    overflow: hidden;
    margin-right: 10px;
    background: #ccc;
    img {
      position: absolute;
      width: 100%;
      height: 100%;
      left: 0;
      top: 50%;
      transform: translateY(-50%);
    }
  }
  .goods-right {
    flex: 1;
    width: 100%;
    .goods-detail {
      height: 32px;
      .title {
        font-size: 14px;
        line-height: 16px;
      }
    }
    .p_n {
      display: flex;
      align-items: center;
      padding: 23px 10px 0 0;
      .price {
        display: inline-block;
        flex: 1;
        .unit_1,.unit_2 {
          font-size: 16px;           
          margin: 0 -3px;
        }
        .unit_2 {
          color: #FF6052;
        }
        .number {
          font-size: 16px;            
          letter-spacing: -0.3px;
          margin-right: 8px;
        }
        .discount {
          font-size: 16px;            
          margin-right: 2px;
          color: #FF6052;
          line-height: 16px;
        }
        .vip {
          color: #FF6052;
          font-size: 12px;
          height: 12px;
          line-height: 12px;
        }
      }
      .sales {
        display: inline-block;          
        color: #FF6052;
        font-size: 12px;
        position:relative;
        top:2px;
      }
    }
  }
}
</style>
