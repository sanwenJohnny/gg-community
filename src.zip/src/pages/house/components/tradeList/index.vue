<template>
 <div class="container b_top item">
     <!-- 订单左侧 -->
     <div class="trade">
        <!-- 订单详情 -->
        <div class="trade-left">
            <div class="trade-name">
                <span class="trade-number">订单编号: {{ tradeInfo.orderNumber }}</span>
                <span v-if="tradeInfo.orderTag" class="other-arear">{{ tradeInfo.orderTag }}</span>
            </div>
            <div class="trade-name trade-time">{{ tradeInfo.payTime }}</div>
            <div class="trade-name trade-address">{{ tradeInfo.communityName }}</div>
            <div class="trade-name user-id">用户ID: {{ tradeInfo.accountId }}</div>
        </div>
        <div class="trade-right">
            <div class="trade-statu f_bold" :class="{wait: tradeInfo.status === 1}">{{ tradeInfo.statusDesc }}</div>
            <div class="trade-price">
                <span class="unit">￥</span><span class="number">{{ tradeInfo.incoming }}</span>
            </div>
            <div v-if="tradeInfo.remark" class="trade-explain">{{ tradeInfo.remark }}</div>            
        </div>
     </div>
 </div>
</template>

<script>
export default {
  name:'tradeList',
  props: {
    // 交易信息
    tradeInfo: {
      type: Object,
      default: {}
    },
  },
  data () {
    return {
    }
  },
  computed:{
  },
  methods: {
  },
  mounted () {
  }
}
</script>

<style scoped lang="scss">
.container {
  width: 100%;
  height: 104px;
  box-shadow: inset 0 0 0 0 #EEE;
  padding: 0 10px;
  .trade {
    display: flex;
    justify-content: space-between;
    letter-spacing: 0;    
    padding:16px 10px;
    align-items: center;    
    .trade-left {
        .trade-name {
            font-size: 12px;
            color: #6B6B6B;
            line-height: 12px;
            margin-bottom: 8px;
        }
        .other-arear {
            margin-left: 6px;
        }
    }
    .trade-left > div:last-child {
        margin-bottom: 0;
    }
    .trade-right {
        flex: 1;
        text-align: right;        
        .trade-statu {
            font-size: 14px;
            color: #747474;
            line-height: 14px;
            margin-bottom: 10px;            
            &.wait{
                color: #FF6052;
            }
        }
        .trade-price {
            font-size: 18px;
            color: #1A1A1A;
            text-align: right;
            line-height: 18px;
            .unit {
                margin: 0 -3px;
            }
        }
        .trade-explain {
            font-size: 12px;
            color: #C2C2C2;
            line-height: 12px
        }
    }
  }
}
</style>
