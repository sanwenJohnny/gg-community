<template>
<div class="after-list">
    <!-- 头部部分 -->
    <div class="top-content">
        <span class="order-status b_right wait">{{ afterInfo.statusDesc }}</span>
        <span class="order-number">{{ afterInfo.refundNumber }}</span>
        <span class="order-time">{{ afterInfo.applyTime }}</span>      
    </div>
    <!-- 商品信息 -->
    <div class="container b_top item">
        <!-- 商品图 -->
        <div class="goods-thumbnail">
            <img class="good-pic" :src="afterInfo.productImg" alt="" />
        </div>
        <!-- 右侧商品信息 -->
        <div class="goods-right">
            <!-- 商品详情 -->
            <div class="goods-detail">
                <div class="goods-title">{{ afterInfo.productName }}</div>
                <div class="goods-count">x{{ afterInfo.refundCount }}</div>
            </div>
            <div class="refund-amount">
                <span>退款金额: </span><span class="unit">￥</span><span class="number">{{ afterInfo.refundMoney }}</span>
            </div>
        </div>
    </div>
</div>
 
</template>

<script>
import imgApi from "@/utils/imgApi"
export default {
  name:'afterList',
  props: {
    // 售后列表信息
    afterInfo: {
        type: Object,
        defalut: {}
    },
  },
  data () {
    return {
      transOrderImg: imgApi.getRes("afterList","transOrder"),
      typeName: ['', '申请中', '退款成功', '退款拒绝','退款取消'],     
    }
  },
  computed:{
  },
  methods: {
  },
  mounted () {
  }
}
</script>

<style scoped lang="scss">
.after-list {
    height: 132px;
    background-color: #fff;
    letter-spacing: 0;
    .top-content {
        padding: 0 10px;        
        height: 38px;
        line-height: 38px;
        .order-status {
            display: inline-block;
            font-size: 14px;
            color: #333;
            height: 38px;
            padding-right: 10px;
        }
        // 申请中
        .wait {
            color: #FF6052;            
        }
        .order-number {
            padding-left: 10px; 
            font-size: 14px;
            color: #747474;
        }
        .order-time {
            float:right;
            font-size: 12px;
            color: #C2C2C2;
            text-align: right;
        }
    }
    .container {
        padding: 16px 10px 0 10px;
        width: 100%;
        height: 94px;
        box-shadow: inset 0 0 0 0 #EEE;
        display: flex;
        justify-content: space-between;
        .goods-thumbnail {
            position: relative;
            width: 62px;
            height: 62px;
            overflow: hidden;
            margin-right: 8px;
            background: #ccc;
            img {
                position: absolute;
                width: 100%;
                height: 100%;
                left: 0;
                top: 50%;
                transform: translateY(-50%);
            }
        }
        .goods-right {
            flex: 1;
            .goods-detail {
                height: 32px;
                .goods-title {
                    display: inline-block;                    
                    font-size: 14px;
                    line-height: 16px;
                    width: 89%;                    
                }
                .goods-count {
                    float: right;              
                    font-size: 14px;
                    color: #C2C2C2;
                    text-align: right;
                    line-height: 14px;
                }
            }
            .refund-amount {
                height: 46px;
                line-height: 46px;
                font-size: 12px;
                color: #333;
                text-align: left;
                .unit {      
                    margin: 0 -3px;
                }
            }
        }
    }
}
</style>
