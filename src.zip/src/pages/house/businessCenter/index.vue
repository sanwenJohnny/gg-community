<template>
  <div class="business-center">
    <!-- 地区 -->
    <div class="data-list" v-for="(item, i) in todaySummary" :key="i">
        <data-center :type="1" :staticData="item"></data-center>
    </div>
    <!-- 销售概括 -->
    <div class="data-list" v-for="(item, i) in allProfits" :key="i">
        <data-center :type="0" :staticData="item"></data-center>
    </div>
    <!-- 月访问量 -->
    <div class="data-list" v-for="(item, i) in monthProfit" :key="i">
        <data-center :type="0" :staticData="item"></data-center>
    </div>
  </div>
</template>

<script>
import dataCenter from "@/pages/house/components/dataCenter/index"
import { mapState, mapActions } from 'vuex'
import utils from 'u'

export default {
  name:'businessCenter',    
  data () {
    return {
      // 地区
      todaySummary: [],
      // 销售概括
      allProfits:[],
      // 月访问量
      monthProfit:[]
    }
  },
  components: {
    dataCenter
  },
  computed:{

  },
  // 下拉刷新
  onPullDownRefresh(){
    this.initPage()
  },
  onShow () {
    this.initPage(
    utils.loading()            
    )
  },
  methods: {
    ...mapActions('modHouse', ['getBusinessCenterDataAction']),      
    // 初始化页面
    initPage() {
        this.getBusinessCenterDataAction().then(res => {
            utils.loaded()                                       
            wx.stopPullDownRefresh()                                
            this.todaySummary = res.todaySummary || []
            this.allProfits = [{
              ...res.allProfits,
              communityName: '销售概括'         
            }]
            this.monthProfit = res.monthProfit || []
        });
    },
  },

  created() {

  },

  mounted() {
  }
}
</script>

<style scoped lang="scss">

</style>
