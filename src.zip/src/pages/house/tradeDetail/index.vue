<template>
  <div class="trade-detail">
    <!-- 交易信息 -->
    <div class="trade-info info">
        <div class="info-title">订单信息</div>
        <div class="trade-content content">
            <div class="row">
                <span class="name">订单编号</span>
                <span class="text">{{ tradeDetailInfo.orderNumber }}</span> 
            </div>
            <div class="row">
                <span class="name">订单状态</span>
                <span class="text">{{ tradeDetailInfo.statusDesc }}</span> 
            </div>
            <div class="row">
                <span class="name">付款时间</span>
                <span class="text">{{ tradeDetailInfo.payTime }}</span> 
            </div>
            <div v-if="tradeDetailInfo.confirmTime" class="row">
                <span class="name">发货时间</span>
                <span class="text">{{ tradeDetailInfo.confirmTime }}</span> 
            </div>
            <div v-if="tradeDetailInfo.finishTime" class="row">
                <span class="name">交易成功时间</span>
                <span class="text">{{ tradeDetailInfo.finishTime }}</span> 
            </div>
            <div class="row">
                <span class="name">总金额</span>
                <span class="text">¥{{ tradeDetailInfo.totalPrice }}</span> 
            </div>
            <div class="row last-row">
                <span class="name">实付金额</span>
                <span class="text real-prive">¥{{ tradeDetailInfo.realPrice }}</span>
            </div>
        </div>
    </div>
    <!-- 物流信息 -->
    <div v-if="tradeDetailInfo.logisticsInfo" class="express-info info">
        <div class="info-title">物流信息</div>
        <div class="express-content content">
            <div class="row">
                <span class="name">物流公司</span>
                <span class="text">{{ tradeDetailInfo.logisticsInfo.logisticsCompany }}</span> 
            </div>
            <div class="row last-row">
                <span class="name">物流单号</span>
                <span class="text">{{ tradeDetailInfo.logisticsInfo.logisticsNumber }}</span>
            </div>
        </div>
    </div>
    <!-- 人的信息 -->
    <div class="person-info info">
        <div class="info-title">{{ receiveInfo.type === 1 ? '收货人信息': '提货人信息' }}</div>
        <div class="person-content content">
            <div class="row">
                <span class="name">姓名</span>
                <span class="text">{{ receiveInfo.receiver }}</span>
            </div>
            <div class="row">
                <span class="name">手机号</span>
                <span class="text">{{ receiveInfo.mobileNumber }}</span>
            </div>
            <div class="row last-row">
                <span class="name">{{ receiveInfo.type === 1 ? '地址': '备注' }}</span>
                <span class="text textarea">{{ receiveInfo.receiveAddress || '无' }}</span>
            </div>
        </div>
    </div>
    <!-- 商品列表 -->    
    <div class="goods-list info">
        <div class="info-title">商品列表</div>
        <div class="goods-content">
            <div class="detail" v-for="(item,i) in detailLists" :key="i">
                <detail-list :detailInfo="item"></detail-list>
            </div>
        </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import detailList from "@/pages/house/components/detailList/index"

export default {
  name:'tradeDetail',
  data () {
    return {
      detailLists: [],
      orderStatu:['待发货','待结算','已结算','已取消'],
      tradeDetailInfo: '',
      // 收货人、提货人信息
      receiveInfo: ''
    }
  },
  components: {
    detailList    
  },
  computed: {
  },
  methods: {
    ...mapActions('modHouse', ['getTradeDetailListAction']),      
  },
  mounted() {
  },
  onShow () {
    const orderNumber = this.$root.$mp.query.orderNumber || ''      
    const data = { orderNumber: orderNumber }
    this.getTradeDetailListAction({data,showLoading:true}).then(res => {
      this.detailLists = res.productInfo || []
      this.receiveInfo = res.receiveInfo || ''
      this.tradeDetailInfo = res
    })
  },
}
</script>

<style scoped lang="scss">
.trade-detail {
    letter-spacing: 0;    
    font-size: 14px;
    line-height: 14px;
    box-sizing: border-box;
    width: 100%;
    .info {
        box-sizing: border-box;
        .info-title {
            height: 28px;
            line-height: 28px;
            padding-left: 10px;
            box-sizing: border-box;            
            width: 100%;
            background: #F5F5F5;
            font-size: 12px;
            color: #858585;
        }
        .content {
            padding: 14px 14px 15px 14px;
            background: #fff;
            .row {
                margin-bottom: 15px;
                display: flex;
                .name {
                    color: #747474;
                    width: 30%;
                }
                .text {
                    flex: 1;
                    color: #333;
                    text-align: right;
                }
                .real-prive {
                    font-size: 16px;
                    color: #FF6052;
                    font-weight: bold;
                }
                .textarea {
                    height: auto;
                    line-height: 16px;
                }
            }
            .last-row {
                margin-bottom: 0;
            }
        }
        .goods-content {
            box-sizing: border-box;
            width: 100%;
            background: #fff;            
            padding-left: 10px;
        }
    }
    
}
</style>
