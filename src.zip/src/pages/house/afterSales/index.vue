<template>
  <div class="after-sales">
    <!-- 售后头部内容 -->
    <div class="after-top">
        <div class="search-content">
            <search-bar ref="searchBar" @getList="getList"></search-bar>
        </div>
        <!--  售后状态切换 -->
        <nav-tab @clearSearch="clearSearchValue" @getAfterSales="init" :tabType="tabType" :navName="tabList"></nav-tab>
    </div>
    <!-- 售后信息列表 -->
    <div class="after-content">
        <div v-if="afterLists.length>0">
          <div class="after-list" v-for="(item,i) in afterLists" :key="i" @tap="toAfterDetail(item)">
              <after-list :afterInfo="item"></after-list>
          </div>
        </div>
        <div class="empty" v-show="!afterLists.length && showEmpty">
            <v-empty :image="emptyImg">您还没有相关的订单哟~</v-empty>            
        </div>
        <!-- 底部提示 -->
        <load-more v-if="loading"></load-more>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import utils from 'u'
import searchBar from "@/pages/house/components/searchBar/index"
import afterList from "@/pages/house/components/afterList/index"
import navTab from "@/pages/house/components/navTab/index"
import loadMore from '@/components/loadMore'
import vEmpty from "@/components/empty"
import imgApi from "@/utils/imgApi"

export default {
  name:'afterSales',   
  components: {
    searchBar,
    afterList,
    navTab,
    vEmpty,
    loadMore
  },
  data () {
    return {
      emptyImg: imgApi.getRes("empty","order"),      
      afterLists: [],
      tabType: 'afterSales',
      tabList: ['全部', '申请中', '退款成功', '退款拒绝'],
      page:1,
      pageSize:20,
      total:0,
      loading:false,
      showEmpty:false
    }
  },
  computed: {
    ...mapState('modHouse', ['sAfterSalesType']),      
  },
  methods: {
    ...mapActions('modHouse', ['getAfterSalesListAction']),
    init() {
      this.page = 1
      this.afterLists = []
      this.showEmpty = false
      this.getList()
    },
    getList(searchValue) {
      let data = {
        managerCode: this.code,
        page: this.page,
        pageSize: this.pageSize,
        type: this.sAfterSalesType,
        queryId: searchValue || ''     
      }
      if(!this.loading){
        utils.loading()   
      }             
      if (searchValue) {
        this.showEmpty = false        
        this.afterLists = []
      }      
      this.getAfterSalesListAction({data}).then(res => {
        utils.loaded()                             
        wx.stopPullDownRefresh()                                        
        this.afterLists = [
          ...this.afterLists,
          ...res.list
        ]
        this.showEmpty = this.afterLists.length>0 ? false : true
        this.total = res.total
        this.loading = false     
      })
    },
    // 进入售后详情并清空搜索值
    toAfterDetail(item) {
        this.clearSearchValue()
        this.$router.push({
            url: `/pages/house/afterDetail/main?refundNumber=${item.refundNumber}`       
        })
    },
    // 清空搜索值
    clearSearchValue() {
      this.$refs.searchBar.clearSearchValue()
    }
  },
  // 下拉刷新
  onPullDownRefresh(){
    this.init()
  },
  // 上拉加载
  onReachBottom(){
    if(Math.ceil(this.total / this.pageSize) > this.page) {
      this.page++
      this.loading = true
      setTimeout(()=> {
        this.getList()
      },200)
    }
  },
  mounted() {
    this.clearSearchValue()
    this.init()
  },
  onShow () {
  },
}
</script>

<style scoped lang="scss">
.empty {
  box-sizing: border-box;
  height: 100%;
  padding-bottom: 56px;
  overflow-y: auto;
  background: $lightWhiteBase;
}
.after-sales {
    .after-top {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 9;
        width: 100%;
        height: 84px;
        background-color: #fff;
        .search-content {
            height: 40px;
            line-height: 40px;
            padding: 0 10px;
        }
    }
    .after-content {
        width: 100%;
        position: absolute;
        top: 84px;
        left: 0;
        .after-list {
            margin-top: 8px;
        }
    }
}

</style>
