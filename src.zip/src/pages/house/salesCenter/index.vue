<template>
  <div class="sales-center">
    <!--上半内容部分 -->
    <div class="sales-up">
        <!-- 近交易日状态切换 -->
        <nav-tab :tabType="tabType" @getSalesCenter="init" :navName="tabList"></nav-tab>
    </div>
    <!-- 商品销量部分 -->
    <div class="goods-content" :class="{hideLeft:!showEmpty}">
        <div v-if="goodLists.length>0">
          <div class="goods-list" v-for="(item, i) in goodLists" :key="i">
              <good-list :goodInfo='item'></good-list>            
          </div>
        </div>
        <div class="empty" v-show="!goodLists.length && showEmpty">
            <v-empty :image="emptyImg">没有相关的销量~</v-empty>            
        </div>
        <!-- 底部提示 -->
        <load-more v-if="loading"></load-more>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import utils from 'u'
import goodList from "@/pages/house/components/goodList/index"
import navTab from "@/pages/house/components/navTab/index"
import loadMore from '@/components/loadMore'
import vEmpty from "@/components/empty"
import imgApi from "@/utils/imgApi"
export default {
  name:'salesCenter',
  components: {
    goodList,
    navTab,
    loadMore,
    vEmpty
  },   
  data () {
    return {
      emptyImg: imgApi.getRes("empty","order"),                          
      activeIndex: 0,
      tabType: 'salesCenter',
      tabList: ['昨日销量', '近7日销量', '近30日销量'],
      // 商品列表
      goodLists: [],
      page:1,
      pageSize:20,
      total:0,
      loading:false,
      showEmpty:false      
    }
  },
  computed: {
    ...mapState('modHouse', ['sSalesCenterType']),  
  },
  methods: {
    ...mapActions('modHouse', ['getSalesCenterListAction']),
    init() {
      this.page = 1
      this.goodLists = []
      this.showEmpty = false            
      this.getList()
    },
    getList() {
      let data = {
        managerCode: this.code,
        page: this.page,
        pageSize: this.pageSize,
        type: this.sSalesCenterType
      }
      if(!this.loading){
        utils.loading()   
      }
      this.getSalesCenterListAction({data}).then(res => {
        utils.loaded()  
        wx.stopPullDownRefresh()                    
        this.goodLists = [
          ...this.goodLists,
          ...res.list
        ]
        this.showEmpty = this.goodLists.length>0?false:true               
        this.total = res.total
        this.loading = false
      })
    },
  },
  // 下拉刷新
  onPullDownRefresh(){
    this.init()
  },
  // 上拉加载
  onReachBottom(){
    if(Math.ceil(this.total / this.pageSize) > this.page) {
      this.page++
      this.loading = true
      setTimeout(()=> {
        this.getList()
      },200)
    }
  },
  mounted() {
    this.init()    
  },
  onShow () {
  },
}
</script>

<style scoped lang="scss">
.empty {
  box-sizing: border-box;
  height: 100%;
  width: 100%;
  padding-bottom: 56px;
  background: $lightWhiteBase;
}
.sales-center {
    height: 100%;
    width: 100%;
    .sales-up {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 9;
        width: 100%;
        background-color: #fff;
    } 
    .goods-content {
        box-sizing: border-box; 
        width: 100%;     
        margin-top:8px;
        background-color:#fff;
        position: absolute;
        top: 44px;
        left: 0;
    }
    .hideLeft {
        padding-left: 10px;
    }
    .content-foot {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
    }
}

</style>
