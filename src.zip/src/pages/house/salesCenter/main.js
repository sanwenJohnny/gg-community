import Vue from 'vue'
import App from './index'

const app = new Vue(App)
app.$mount()

export default {
    config: {
        navigationBarTitleText: '商品销售中心',
        enablePullDownRefresh: false,
        backgroundTextStyle: 'dark'                              
    }
}