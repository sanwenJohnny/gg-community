<template>
  <div class="buyModel">
    <div class="mask" @click="closeBuyModel"></div>
    <div class="content" :class="{isIphoneX: isIphoneX}">
      <div class="header line">
        <img class="skuImg" :src="skuImg" mode="aspectFill">
        <div class="price">
          <p class="current-price">￥{{price}}</p>
        </div>
        <div class="cancle" @click="closeBuyModel"></div>
      </div>
      <div class="edit-productNum line">
        <div class="title">数量</div>
        <div class="inputNumber">
          <div class="sub" :class="{gray: productCount == 1}" @click="subProduct">-</div>
          <div class="num">{{productCount}}</div>
          <div class="add" :class="{gray: productCount == stockCount || productCount == limitCount}" @click="addProduct">+</div>
        </div>
      </div>
      <div class="buyBtn" @click="goOrderSunmit">确定</div>
    </div>
  </div>
</template>
<script>
export default {
  props: [
    "skuImg",
    "price",
    "stockCount",
    "pid",
    "limitCount",
    "isIphoneX"
  ],
  data(){
    return {
      productCount: "1"
    }
  },
  methods: {
    closeBuyModel(){
      this.$emit("closeBuyModel")
    },
    // 添加商品
    addProduct(){
      if(this.productCount === this.stockCount){
         wx.showToast({
          title: `库存不足`,
          icon: 'none',
          duration: 2000
        })
        return
      }
      if(this.productCount === this.limitCount){
        wx.showToast({
          title: `该商品限购${this.limitCount}件`,
          icon: 'none',
          duration: 2000
        })
        return
      }
      this.productCount ++
    },
    // 减少商品
    subProduct(){
      if(this.productCount == 1) return
      this.productCount --
    },
    // 购买商品
    goOrderSunmit(){
      this.closeBuyModel()
      this.$router.push({
        url: `/pages/order/submit/main?productId=${this.pid}&count=${this.productCount}`
      })
    },
  }
}
</script>
<style lang="scss" scoped>
.gray{
  color: #eee !important;
}
.isIphoneX{
  padding-bottom: 52px !important; 
}
// 购买弹框
.buyModel{
  position: fixed;
  z-index: 100;
  .mask{
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba($color: #000000, $alpha: .4)
  }
  .content{
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    padding: 14px 18px 18px;
    box-sizing: border-box;
    background: #fff;
    .header{
      position: relative;
      padding: 0 20px 16px 128px;
      height: 56px;
      .skuImg{
        position: absolute;
        left: 0;
        bottom: 16px;
        width: 116px;
        height: 116px;
        background-color: #ccc;
      }
      .price{
        .current-price{
          color: $darkOrangeBase;
          font-size: 20px;
          font-weight: bold;
        }
      }
      .cancle{
        position: absolute;
        top: 0;
        right: 0;
        width: 15px;
        height: 15px;
        transform: rotate(45deg);
        &::before{
          content: "";
          position: absolute;
          top: 50%;
          left: 0;
          transform: translateY(-50%);
          width: 15px;
          height: 1px;
          background: #747474
        }
        &::after{
          content: "";
          position: absolute;
          top: 0;
          left: 50%;
          transform: translateX(-50%);
          width: 1px;
          height: 15px;
          background: #747474;
        }
      }
    }
    .edit-productNum{
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 0;
      .title{
        font-size: 14px;
        color: $lightBlackBase;
      }
      .inputNumber{
        border: 1px solid #e0e0e0;
        display: flex;
        height: 24px;
        text-align: center;
        color: $darkBlackBase;
        .sub{
          width: 26px;
          height: 100%;
          line-height: 22px;
        }
        .num{
          min-width: 22px;
          padding: 0 5px;
          border-left: 1px solid #e0e0e0;
          border-right: 1px solid #e0e0e0;
          font-size: 14px;
          line-height: 24px;
        }
        .add{
          width: 26px;
          height: 100%;
          line-height: 22px;
        }
      }
    }
    .buyBtn{
      margin-top: 16px;
      width: 100%;
      height: 44px;
      text-align: center;
      line-height: 44px;
      color: #333;
      font-size: 16px;
      background-color: $orangeBase;
      border-radius: 22px;
    }
  }
}
</style>
