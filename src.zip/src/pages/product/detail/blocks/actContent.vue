<template>
  <div class="product-content" :class="{activity: detail.promotionInfo.remainSecond > -1}">
    <div class="countdown" :class="{baseLine: detail.promotionInfo.remainSecond > -1}">
      <div class="price flex" v-if="detail.promotionInfo.remainSecond > -1">
        <span class="current-price">¥{{detail.accountInfo.isMember?detail.memberPrice : detail.salesPrice}}</span>
        <div class="sub">
          <span class="origin-price">￥{{detail.marketPrice}}</span>
          <div class="icon">
            <img v-if="detail.accountInfo && detail.accountInfo.isMember" :src="vipPriceImg">
            <img v-else :src="groupPriceImg">
          </div>
        </div>
      </div>
      <div class="price" v-else>
        <span class="current-price">¥{{detail.accountInfo.isMember?detail.memberPrice : detail.salesPrice}}</span>
        <span class="origin-price">￥{{detail.marketPrice}}</span>
        <img v-if="detail.accountInfo && detail.accountInfo.isMember" :src="vipPriceImg">
        <img v-else :src="groupPriceImg" >
      </div>
      <div class="time" v-if="(detail.status === 1 || detail.status === 2) && detail.promotionInfo.remainSecond !== -1">
        {{detail.status === 1?"距结束":"距开始"}}:
        <actTimer :timestamp="detail.promotionInfo.remainSecond" @timerOver="timerOver"/>
      </div>
    </div>
    <div class="product-generalize baseLine" v-if="detail.recentBuy && detail.recentBuy.length > 0">
      <ul class="generalize-list">
        <li class="item" v-for="(item, index) in detail.recentBuy" :key="index">
          <img class="people-logo" :src="item.image">
          <span class="people-name ellipsis">{{item.name}}</span>
        </li>
      </ul>
      <span class="tip">等刚刚购买了此商品</span>
    </div>
    <div class="other-info">
      <div class="communityer repertory" v-if="detail.accountInfo && detail.accountInfo.isManager">
        <img class="generalize" :src="generalizeImg" mode="widthFix">
        <span v-if="detail.commissionInfo">推广最多可赚{{detail.commissionInfo.income}}元佣金</span>
      </div>
      <div class="repertory">
        <img :src="inventoryImg" mode="widthFix">
        <span>商品库存{{detail.stockCount}}件</span>
      </div>
    </div>
  </div>
</template>

<script>
import imgApi from "@/utils/imgApi";
import actTimer from "@/components/actTimer";

export default {
  props: ["detail"],
  components: {
    actTimer
  },
  data(){
    return {
      vipPriceImg: imgApi.getRes("detail","vipPrice"),
      groupPriceImg: imgApi.getRes("detail","groupPrice"),
      inventoryImg: imgApi.getRes("detail","inventory"),
      generalizeImg: imgApi.getRes("detail","generalize"),
    }
  },
  methods: {
    // 倒计时结束
    timerOver(){
      this.$emit("timerOver")
    }
  }
}
</script>

<style lang="scss" scoped>
// 商品内容
.product-content{
  background-color: #fff;
  padding: 0 10px;
  border-bottom: 8px solid #f5f5f5;
  .baseLine{
    position: relative;
    &::after{
      content: "";
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 1px;
      background-color: #eee;
      transform: scaleY(0.5)
    }
  }
  .countdown{
    display: flex;
    justify-content: center;
    align-items: center;
    // padding-bottom: 10px;
    .flex{
      display: flex;
      align-items: center;
    }
    .price{
      .current-price{
        font-size: 20px;
        color: $darkOrangeBase;
        font-weight: bold;
      }
      .sub{
        .icon{
          margin-top: -3px;
        }
      }
      .origin-price{
        display: inline-block;
        line-height: 12px;
        margin: 0 3px;
        font-size: 12px;
        color: #C0C0C0;
        text-decoration: line-through;
      }
      img{
        width: 50px;
        height: 14px;
        vertical-align: middle;
      }
    }
    .time{
      font-size: 12px;
      text-align: center;
      padding: 15px 0;
    }
  }
  .product-generalize{
    padding: 15px 0 10px;
    display: flex;
    align-items: center;
    // justify-content: center;
    color: $lightBlackBase;
    font-size: 12px;
    .generalize-list{
      .item{
        display: inline-block;
        .people-logo{
          width: 22px;
          height: 22px;
          border-radius: 50%;
          background-color: #ccc;
          vertical-align: middle;
        }
        .people-name{
          margin-left: 3px;
          vertical-align: middle;
          display: inline-block;
          width: 40px;
        }
      }
    }
  }
  .other-info{
    display: flex;
    justify-content: space-between;
    .repertory{
      height: 30px;
      line-height: 30px;
      img{
        width: 11px;
        height: auto;
        margin-right: 3px;
        vertical-align: middle;
      }
      .generalize{
        vertical-align: middle;
      }
      span{
        font-size: 12px;
        color: $lightBlackBase;
        display: inline-block;
      }
    }
  }
}
.activity{
  background-color: #F9FFEA;
  .countdown{
    justify-content: space-between;
  }
  .baseLine{
    position: relative;
    &::after{
      content: "";
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 1px;
      background-color: #ECF9C9;
      transform: scaleY(0.5)
    }
  }
}
</style>

