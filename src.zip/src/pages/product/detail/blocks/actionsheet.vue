<template>
  <div class="actionsheet">
    <div class="mask" @click="closeActionsheet"></div>
    <div class="content">
      <div class="panel line">
        发送给朋友
        <button class="share" open-type="share">分享</button>
      </div>
      <div class="panel" @click="getShareQrcode">生成卡片保存分享</div>
      <div class="panel" :class="{isIphoneX: isIphoneX}" @click="closeActionsheet">取消</div>
    </div>
  </div>
</template>
<script>
import { mapActions } from 'vuex';
export default {
  props: [
    "communityInfo",
    "pid",
    "skuName",
    "skuImage",
    "skuName",
    "salesPrice",
    "marketPrice",
    "isIphoneX"
  ],
  methods:{
    ...mapActions("modProduct",["getShareQrcodeAction"]),
    // 关闭actionsheet
    closeActionsheet(){
      this.$emit("closeActionsheet")
    },
     // 获取分享卡片
    getShareQrcode (){
      const data = {
        page: "pages/product/detail/main",
        scene: `c=${this.communityInfo.cityCode}&p=${this.pid}&i=${this.communityInfo.communityId||0}`,
        skuId: this.pid,
        skuName:this.skuName,
        skuImage:this.skuImage,
        salesPrice:this.salesPrice,
        marketPrice:this.marketPrice
      }
      this.getShareQrcodeAction({
        data
      }).then(data=>{
        this.closeActionsheet()
        wx.previewImage({
          current: data, // 当前显示图片的http链接
          urls: [data] // 需要预览的图片http链接列表
        })
      })
    },
  }
}
</script>
<style lang="scss" scoped>
.isIphoneX{
  padding-bottom: 34px;
}
// actionsheet
.actionsheet{
  position: fixed;
  z-index: 99;
  .mask{
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba($color: #000000, $alpha: .6)
  }
  .content{
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    .panel{
      position: relative;
      background-color: #fff;
      height: 54px;
      line-height: 54px;
      text-align: center;
      font-size: 16px;
      color: $darkBlackBase;
      &:last-child{
        margin-top: 8px;
      }
      .share{
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        opacity: 0;
      }
    }
  }
}
</style>

