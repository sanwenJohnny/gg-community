<template>
  <div class="footerBar" :class="{phoneX: isIphoneX}">
    <div class="other">
      <div class="item" v-for="(item, index) in footArr" :key="index" @click="footClick(index)">
        <img :src="item.img">
        <p class="title">{{item.title}}</p>
        <div v-if="index === 1 && cartCount > 0" class="bridge">{{cartCount}}</div>
      </div>
    </div>
    <div class="btn-group">
      <div class="buyType" v-if="status === 1">
        <div class="joinCart" @click="addCart">加入购物车</div>
        <div class="buy" @click="openBuyModel">立即购买</div>
      </div>
      <div class="pre-begin" v-else-if="status === 2">即将开始</div>
      <div class="disbuy" v-else>已抢完</div>
    </div>
  </div>
</template>
<script>
import imgApi from "@/utils/imgApi";
import mixin from "@/mixin/checkSession";
import { mapActions } from 'vuex';
import utils from 'u'
import db from 'ss'
export default {
  props: ["cartCount","status","phone","isLogin","pid","communityInfo","isIphoneX","cacheCommunityInfo","cityName"],
  mixins: [mixin],
  data (){
    return {
      footArr: [
        {
          img: imgApi.getRes("detail","home"),
          title: "首页"
        },
        {
          img: imgApi.getRes("detail","cart"),
          title: "购物车"
        },
        {
          img: imgApi.getRes("detail","contact"),
          title: "联系商家"
        }
      ]
    }
  },
  methods: {
    ...mapActions("modProduct",["getAddCartAction"]),
    // 底部点击
    footClick(index){
      if(index === 0){
        this.$router.reLaunch({
          url: "/pages/index/main"
        })
      }else if(index === 1){
        this.$router.reLaunch({
          url: "/pages/shoppingCart/main"
        })
      }else{
        wx.makePhoneCall({
          phoneNumber: this.phone //仅为示例，并非真实的电话号码
        })
      }
    },
    // 添加购物车
    addCart (){
      if(!this.isLogin){
        this.toLoginMix()
        return
      }
      if(this.cacheCommunityInfo.cityCode != this.communityInfo.cityCode){
        wx.showToast({
          title: `请切换至${this.cityName}后加购商品`,
          icon: 'none',
          duration: 2000
        })
        return
      }
      const data = {
        cityCode: this.cacheCommunityInfo.cityCode,
        skuId: this.pid
      }
      this.getAddCartAction({
        data
      }).then(data=>{
        // 设置购物车默认商品
        let chooses = utils.get(db.CART_CHOOSES)
        if(! chooses) chooses = {}
        chooses[this.pid] = {}
        utils.set(db.CART_CHOOSES, chooses)
        console.log(222222)
        wx.showToast({
          title: '已加入购物车',
          icon: 'none',
          duration: 2000
        })
        this.$emit("getCartCount")
      })
    },
    // 打开购买弹窗
    openBuyModel(){
      if(!this.isLogin){
        this.toLoginMix()
        return
      }
      this.$emit("openBuyModel")
    },
  },
}
</script>
<style lang="scss" scoped>
// 底部样式
  .footerBar{
    background-color: #fff;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 10;
    height: 34px;
    padding: 10px 224px 10px 10px;
    .other{
      width: 100%;
      height: 100%;
      margin-top: -5px;
      padding-right: 5px;
      box-sizing: border-box;
      display: flex;
      justify-content: space-between;
      .item{
        position: relative;
        width: 40px;
        text-align: center;
        // line-height: 17px;
        .bridge{
          position: absolute;
          top: 0;
          right: 7px;
          font-size: 10px;
          min-width: 11px;
          padding: 0 3px;
          height: 15px;
          line-height: 15px;
          transform: translate(50%,-20%);
          border-radius: 9px;
          background-color: red;
          color: #fff;
        }
        img{
          width: 26px;
          height: 26px;
        }
        .title{
          font-size: 10px;
          // margin-top: -3px;
          color: $lightBlackBase;
        }
      }
    }
    .btn-group{
      position: absolute;
      top: 0px;
      right: 0px;
      width: 224px;
      height: 54px;
      overflow: hidden;
      div{
        height: 100%;
        color: #fff;
        text-align: center;
        font-size: 14px;
        line-height: 54px;
      }
      .buyType{
        display: flex;
        width: 100%;
        height: 100%;
        .joinCart{
          width: 50%;
          flex: 1;
          background-color: $orangeBase;
          color: #333;
        }
        .buy{
          width: 50%;
          background-color: $darkOrangeBase;
          color: #fff;
        }
      }
      .disbuy{
        width: 100%;
        background-color: #747474;
      }
      .pre-begin{
        width: 100%;
        color: #333;
        background-color: $orangeBase;
      }
    }
  }
  .phoneX{
    padding-bottom: 44px
  }
</style>

