<template>
  <div class="product-info">
    <p class="product-name ellipsis"> {{name}}</p>
    <p class="product-desc ellipsis">{{description}}</p>
  </div>
</template>

<script>
import imgApi from "@/utils/imgApi";

export default {
  props: ["name","description"]
}
</script>

<style lang="scss" scoped>
// 商品信息
.product-info{
  padding: 20px 0;
  text-align: center;
  .product-name{
    width: 100%;
    font-size: 17px;
    color: $darkBlackBase;
    font-weight: bold;
  }
  .product-desc{
    width: 100%;
    font-size: 14px;
    color: $lightBlackBase;
  }
}
</style>

