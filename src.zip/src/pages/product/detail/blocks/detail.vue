<template>
  <div class="detail">
    <div class="tip line"></div>
    <img v-for="(item, index) in detailImages" :key="index" :src="item" mode="widthFix">
  </div>
</template>

<script>
import imgApi from "@/utils/imgApi";

export default {
  props: ["detailImages"]
}
</script>

<style lang="scss" scoped>
// 商品详情
.detail{
  position: relative;
  padding: 50px 10px 5px;
  font-size: 0;
  .tip{
    position: absolute;
    top: 25px;
    left: 10px;
    right: 10px;
    &::before{
      content: "商品简介";
      position: absolute;
      top: 50%;
      left: 50%;
      width: 100px;
      font-size: 12px;
      color: $lightBlackBase;
      background-color: #fff;
      text-align: center;
      transform: translate(-50%,-50%);
      z-index: 1;
    }
  }
  img{
    width: 100%;
  }
}
</style>

