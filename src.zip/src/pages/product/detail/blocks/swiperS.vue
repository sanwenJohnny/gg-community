<template>
  <div class="swiper-box" :style="{height: screenWidth+'px'}">
    <swiper 
      class="swiper" 
      :indicator-dots="swiperDotShow"
      autoplay="true"
      circular="true">
      <block v-for="(item,index) in headImages" :key="index">
        <swiper-item>
          <image :src="item" mode="aspectFill" class="slide-image" />
        </swiper-item>
      </block>
    </swiper>
    <div class="share">
      <div class="sell" v-if="status !== 2">
        <img :src="fireImg" mode="widthFix">
        <span>已售{{salesCount}}件</span>
      </div>
      <div v-else></div>
      <div class="share-btn" @click="share" :style="{top: screenWidth-59+'px'}">
        <img :src="shareImg" mode="widthFix">
      </div>
    </div>
  </div>
</template>

<script>
import imgApi from "@/utils/imgApi";

export default {
  props: ["headImages","salesCount","status"],
  data(){
    return {
      fireImg: imgApi.getRes("detail","fire"),
      shareImg: imgApi.getRes("detail","share"),
      screenWidth: ""
    }
  },
  mounted(){
    this.getMobieInfo()
  },
  methods: {
    // 获取手机信息
    getMobieInfo (){
      const {screenWidth} = wx.getSystemInfoSync()
      this.screenWidth = screenWidth
    },
    // 分享
    share(){
      this.$emit("share")
    }
  }
}
</script>

<style lang="scss" scoped>
// 轮播图样式开始
.swiper-box{
  position: relative;
  .swiper{
    height: 100%;
    image{
      width: 100%;
      height: 100%;
    }
  }
  .share{
    position: absolute;
    padding: 0 18px;
    bottom: 9px;
    left: 0;
    right: 0;
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    .sell{
      padding: 0 8px;
      background-color: rgba($color: #000000, $alpha: .6);
      border-radius: 31px;
      height: 22px;
      // margin-top: 23px;
      line-height: 19px;
      img{
        width: 10px;
        height: 0;
        margin-right: 3px;
        vertical-align: -2px;
      }
      span{
        display: inline-block;
        vertical-align: middle;
        font-size: 12px;
        color: #fff;
      }
    }
    .share-btn{
      font-size: 0;
      position: fixed;
      right: 18px;
      z-index: 4;
      img{
        width: 50px;
        height: 0;
      }
    }
  }
}
</style>
