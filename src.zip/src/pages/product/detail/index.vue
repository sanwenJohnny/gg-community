<template>
  <div class="container" :class="{isIphoneX: isIphoneX}" v-if="pageShow">
     <!-- 轮播图 -->
    <swiper-s 
      :headImages="detail.headImages" 
      :salesCount="detail.salesCount"
      :status="detail.status"
      @share="actionsheetShow = true">
    </swiper-s>
    <!-- 商品介绍 -->
    <intro 
      :name="detail.name" 
      :description="detail.description">
    </intro>
    <!-- 活动情况展示 -->
    <act-content 
    :detail="detail"
    @timerOver="timerOver">
    </act-content>
    <!-- 商品详情 -->
    <detail 
      v-if="detail.detailImages && detail.detailImages.length >0" 
      :detailImages="detail.detailImages">
    </detail>
    <!-- 底部栏 -->
    <footer-bar 
      :cartCount="cartCount" 
      :status="detail.status" 
      :isLogin="isLogin"
      :pid="pid"
      :communityInfo="communityInfo"
      :cacheCommunityInfo="cacheCommunityInfo"
      :cityName="detail.areaInfo && detail.areaInfo.cityName"
      :phone="detail.sellerInfo.linkTel"
      :isIphoneX="isIphoneX"
      @openBuyModel="buyModelShow = true"
      @getCartCount="getCartCount">
    </footer-bar>
    <!-- 立即购买弹窗 -->
    <buy-model 
      v-if="buyModelShow"
      :skuImg="detail.headImages[0]" 
      :price="detail.accountInfo.isMember?detail.memberPrice : detail.salesPrice"
      :stockCount="detail.stockCount"
      :pid="pid"
      :limitCount="detail.limitCount"
      :isIphoneX="isIphoneX"
      @closeBuyModel="closeBuyModel">
    </buy-model>
    <!-- actionsheet -->
    <v-actionsheet 
      v-if="actionsheetShow"
      :pid="pid"
      :communityInfo="communityInfo"
      :skuName="detail.name"
      :skuImage="detail.headImages[0]"
      :salesPrice="detail.salesPrice"
      :marketPrice="detail.marketPrice"
      :isIphoneX="isIphoneX"
      @closeActionsheet="actionsheetShow=false">
    </v-actionsheet>
  </div>
</template>

<script>
import imgApi from "@/utils/imgApi";
import mixin from "@/mixin/checkSession";

import swiperS from "./blocks/swiperS";
import intro from "./blocks/intro";
import actContent from "./blocks/actContent";
import detail from "./blocks/detail";
import footerBar from "./blocks/footerBar";
import buyModel from "./blocks/buyModel";
import vActionsheet from "./blocks/actionsheet";
import { mapActions } from 'vuex';
import { $ } from "@/utils/index";
import tools from "@/utils";


export default {
  mixins: [mixin],
  data () {
    return {
      isIphoneX: tools.isIphoneX(),
      pageShow: false,
      isLogin: false,
      pid: 0,// 商品id
      productCount: 1,
      isLoad: false,
      cartCount: 0,
      actionsheetShow: false,
      buyModelShow: false,
      communityInfo: {},
      timer: null,// 定时器
      time: {}, // 倒计时时间
      detail: {},
      cacheCommunityInfo:{} // 缓存的小区信息
    }
  },
  components: {
    swiperS,
    intro,
    actContent,
    detail,
    footerBar,
    buyModel,
    vActionsheet
  },
  onLoad(options){
    Object.assign(this.$data, this.$options.data())
    this.isLoad = true
    let param = options
    const communityInfo = wx.getStorageSync("communityInfo") || {}
    // 扫小程序码
    if(param.scene){
      var scene = decodeURIComponent(param.scene)
      param = this.parseQueryString(scene)
    }
    // 存在城市id就缓存下来
    if(param.cityCode){  
      const communityId = communityInfo.communityId

      communityInfo.cityCode = param.cityCode
      communityInfo.communityId = param.communityId
      // 分享 缓存不存在  会写入缓存
      if(!communityId){
        wx.setStorageSync("communityInfo", communityInfo)
      }
    }
    this.pid = param.pid
    this.communityInfo = communityInfo
    this.cacheCommunityInfo = wx.getStorageSync("communityInfo") || {}

    console.log(communityInfo,"场景")
    console.log(options,"参数")
    this.initPageData()
  },
  onShow(){
    if(this.isLoad) {
      this.isLoad = false
      return
    }
    // 登录后方能获取购物车数量
    this.checkLoginOnlyMix().then(()=>{
      this.isLogin = true
      this.getCartCount()
    })
  },
  computed:{
    // swiper 单图片不显示原点
    swiperDotShow(){
      if(this.detail.headImages && this.detail.headImages.length > 1){
        return true
      }else{
        return false
      }
    }
  },
  methods: {
    ...mapActions("modProduct",["getDetailAction","getCartCountAction"]),
    //  小程序码参数解析
    parseQueryString(argu){
      var result = {};
      var temp = argu.split('&');
      for(var i=0; i<temp.length; i++)
      {
        var temp2 = temp[i].split('=');
        if(temp2[0] === 'p'){
          temp2[0] = 'pid'
        }else if(temp2[0] === 'c'){
          temp2[0] = 'cityCode'
        }else{
          temp2[0] = 'communityId'
        }
        result[temp2[0]] = temp2[1];
      }
      return result;
    },
    // 初始化页面数据
    initPageData(){
      
      this.getDetailData()
      // 登录后方能获取购物车数量
      this.checkLoginOnlyMix().then(()=>{
        this.isLogin = true
        this.getCartCount()
      })
    },
    // 获取商品信息
    getDetailData(){
      const data = {
        cityCode: this.communityInfo.cityCode,
        skuId: this.pid
      }
      this.getDetailAction({
        data
      }).then( data => {
        this.detail = data
        this.pageShow = true
        // 分享需要从新覆盖城市名
        if(this.cacheCommunityInfo.cityCode == this.communityInfo.cityCode){
          this.cacheCommunityInfo.cityName = data.areaInfo && data.areaInfo.cityName
          wx.setStorageSync("communityInfo",this.cacheCommunityInfo)
        }
        wx.hideLoading()
        wx.stopPullDownRefresh()
      })
    },
    // 定时结束刷新商品信息
    timerOver(){
      this.getDetailData()
    },
    // 获取购物车商品数量
    getCartCount(){
      const data = {
        cityCode: this.cacheCommunityInfo.cityCode
      }
      this.getCartCountAction({
        data
      }).then(data=>{
        this.cartCount = data
      })
    },
    // 关闭购买弹框
    closeBuyModel(){
      this.buyModelShow = false
    }
  },
  // 下拉刷新
  onPullDownRefresh (){
    this.initPageData()
  },
  // 分享
  onShareAppMessage(res){
    if (res.from === 'button') {
      // 来自页面内转发按钮
      this.actionsheetShow = false
    }
    return {
      path: `/pages/product/detail/main?pid=${this.pid}&communityId=${this.communityInfo.communityId||0}&cityCode=${this.communityInfo.cityCode||0}`
    }
  }
}
</script>

<style scoped lang="scss">
.isIphoneX{
  padding-bottom: 90px !important;
}
.container{
  background-color: #fff;
  height: auto;
  padding-bottom: 56px;
}
</style>
