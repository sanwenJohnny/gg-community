<template>
  <div class="container" :class="{isIphoneX: isIphoneX}" v-if="pageShow">
    <!-- 定位小区 -->
    <div class="location" @click="goChooseArea">
      <img class="location-icon" :src="locationImg" alt="">
      <span class="location-text ellipsis">{{communityTitle}}</span>
    </div>
    <!-- 小区已开通 -->
    <template v-if="pageType === 0">
      <!-- 轮播图 -->
      <swiper
        :indicator-dots="swiperDotShow"
        indicator-color="#eee"
        indicator-active-color="#ffe900"
        :autoplay="true"
        circular="true"
        :current="swiperCurrent"
        v-if="homeInfo.banner && homeInfo.banner.length > 0">
        <block v-for="(item,index) in homeInfo.banner" :key="index">
          <swiper-item @click="swiperToProduct(item)">
            <image :src="item.image" mode="aspectFill" class="slide-image" />
          </swiper-item>
        </block>
      </swiper>
      <!-- 限时特卖 -->
      <div class="time-limit product-list" v-if="homeInfo.hot">
        <img class="activity-title" mode="widthFix" :src="groupImg">
        <tab-bar
          :list="tabbarList"
          :tabbarIndex="tabbarIndex"
          @switchHandle="switchTab"/>
        <div class="countdown">
          <div class="tip" v-show="tabbarIndex === 1">
            每日10点更新，距结束:<actTimer v-if="homeInfo.hot.remainSeconds && homeInfo.hot.remainSeconds!== '-1'" :timestamp="homeInfo.hot.remainSeconds" @timerOver="timerOver"/>
          </div>
          <div class="tip" v-show="tabbarIndex === 0">款款精选 不可错过</div>
          <div class="tip" v-show="tabbarIndex === 2">明日10点准时开抢</div>
        </div>
        <!-- 商品组件 -->
        <productItem
          :item="item"
          :isMember="homeInfo.isMember"
          v-for="(item, index) in limitList"
          :key="index"
          @clickHanle="goProductDetail(item.id)" />
      </div>
      <!-- 精选好味 -->
      <div class="time-limit product-list" v-if="goodProductList.length > 0">
        <img class="activity-title" mode="widthFix" :src="choicenessImg">
        <productItem
          :item="item"
          :isMember="homeInfo.isMember"
          v-for="(item, index) in goodProductList"
          :key="index"
          @clickHanle="goProductDetail(item.id)" />
      </div>
      <load-more v-if="!noMore"></load-more>
    </template>
    <!-- 未定位到小区 -->
    <empty v-else-if="pageType === 1" :image="locationFail">
      <div class="slot-msg">
        <p class="tip">定位失败，请选择城市或开启定位授权</p>
        <div class="location-btn" @click="goChooseArea">开通定位</div>
      </div>
    </empty>
    <!-- 城市未开通 -->
    <empty v-else :image="location">
      <div class="slot-msg">
        <p class="tip" @click="apply">当前城市暂未开通服务，请更换城市或<navigator class="jump" url="/pages/house/apply/main">申请开通></navigator></p>
      </div>
    </empty>
    <v-tab :current-page="page" />
  </div>
</template>

<script>
import imgApi from "@/utils/imgApi";
import { mapState, mapActions, mapMutations } from 'vuex';
import { $ } from "@/utils";
import tools from "@/utils";
import actTimer from "@/components/actTimer";
import productItem from "./components/productItem";
import tabBar from "./components/tabBar";
import empty from "@/components/empty";
import loadMore from "@/components/loadMore";
import vTab from '@/components/tab';

export default {
  components: {
    actTimer,
    tabBar,
    productItem,
    loadMore,
    vTab,
    empty
  },
  data () {
    return {
      page:1,
      isIphoneX: tools.isIphoneX(),
      locationImg: imgApi.getRes("index","location"),
      choicenessImg: imgApi.getRes("index","choiceness"),
      locationFail: imgApi.getRes("empty","locationFail"),
      location: imgApi.getRes("empty","location"),
      groupImg: imgApi.getRes("index","group"),
      pageShow: false,
      swiperCurrent: true,
      pageType: 0,// 默认有数据 0 当前城市已开通 1未定位到城市 2当前城市未开通
      communityInfo: {},
      homeInfo: {},
      tabbarList: [
        "上期精选",
        "正在抢购",
        "明日预购"
      ],
      isLoad: false, // 是否第一次打开该页面（执行onload事件）
      isChooseArea: false,//
      tabbarIndex: 1,
      limitList:[],// 限时团购商品
      goodProductList: [],// 好味精选
      goodProductPage: 1, // 好味精选页码
      noMore: false // 好味精选
    }
  },
  computed:{
    ...mapState(["sChooseArea"]),
    // 设置小区名
    communityTitle(){
      const communityInfo = this.communityInfo
      if(communityInfo && communityInfo.communityName){
        return communityInfo.communityName
      }else if(communityInfo && communityInfo.cityName){
        return communityInfo.cityName
      }else{
        return "请选择小区"
      }
    },
    // swiper 单图片不显示原点
    swiperDotShow(){
      if(this.homeInfo.banner && this.homeInfo.banner.length > 1){
        return true
      }else{
        return false
      }
    }
  },
  methods: {
    ...mapActions(["setChooseAreaAction"]),
    ...mapActions("modIndex",["getHomepageLocationAction","getHomeInfoAction","getHomeNormalAction"]),
    initPage(){},
    // 获取首页信息
    getHomeInfo(){
      this.getHomeInfoAction({
        data:{
          cityCode: this.communityInfo.cityCode || "",
          communityId: this.communityInfo.communityId || ""
        }
      })
      .then(data=>{
        this.pageShow = true
        wx.hideLoading()
        wx.stopPullDownRefresh()
        this.pageType = 0
        // 城市未开通
        if(data.cityIsAvailable === 0){
          this.pageType = 2
        }
        // 小区已下架
        if(data.communityIsAvailable === 0){
          const communityInfo = this.communityInfo
          communityInfo.communityId = ""
          communityInfo.communityName = ""
          wx.setStorageSync("communityInfo",communityInfo)
          this.communityInfo = communityInfo
        }
        this.homeInfo = data
        this.swiperCurrent = 0
        this.limitListHandle()
      }).catch(()=>{
        wx.hideLoading()
        wx.stopPullDownRefresh()
      })
    },
    // 获取精选好味数据
    getGoodProductData(){
      this.getHomeNormalAction({
        data:{
          cityCode: this.communityInfo.cityCode || "",
          page: this.goodProductPage,
          pageSize: 10
        }
      })
      .then(data=>{
        if(data.list.length === 10){
          this.noMore = false
        } else {
          this.noMore = true
        }
        if(this.goodProductPage === 1){
          this.goodProductList = data.list
        }else{
          this.goodProductList = [
            ...this.goodProductList,
            ...data.list
          ]
        }
      })
    },
    // 初始化首页数据
    initHomeData(){
      this.goodProductPage = 1
      const communityInfo = wx.getStorageSync("communityInfo") || {}
      this.communityInfo = communityInfo
      if(communityInfo.cityCode){
        this.getHomeInfo()
        this.getGoodProductData()
      }
    },
    // 定时结束刷新限时数据
    timerOver(){
      this.getHomeInfo()
    },
    // banner跳转商品详情
    swiperToProduct(item){
      // 类型为1跳转详情
      if(item.type === 1){
        this.goProductDetail(item.id)
      }
    },
    // 前往详情页
    goProductDetail (id){
      this.$router.push({
        url: "/pages/product/detail/main?pid=" + id
      })
    },
    // 切换tabbar
    switchTab(index){
      this.tabbarIndex = index
      this.limitListHandle()
    },
    // 限时团购列表赋值
    limitListHandle (){
      if(this.tabbarIndex === 0){
        this.limitList = this.homeInfo.hot.previous
      }else if(this.tabbarIndex === 1){
        this.limitList = this.homeInfo.hot.current
      }else{
        this.limitList = this.homeInfo.hot.next
      }
    },
    // 定位
    getLocation(){
      $(wx.getLocation,{type: 'wgs84'}).then(res=>{
        const param = {
          latitude: res.latitude,
          longitude: res.longitude
        }
        this.getHomepageLocation(param)
      }).catch(()=>{
        const param = {
          latitude: "",
          longitude: ""
        }
        this.getHomepageLocation(param)
      })
    },
    // 前往选择地址页面
    goChooseArea (){
      this.$router.push({url:"/pages/address/chooseArea/main"})
    },
    // 获取当前城市定位
    getHomepageLocation(param){
      const communityInfo = wx.getStorageSync("communityInfo") || {}
      const urlCommunityId = this.$root.$mp.query.communityId || ""
      const cachedCommunityId = communityInfo && communityInfo.communityId || ""
      this.getHomepageLocationAction({
        data:{
          ...param,
          urlCommunityId,
          cachedCommunityId,
        }
      })
      .then(data=>{
        this.communityInfo = data
        wx.setStorageSync("communityInfo",{
          ...data
        })
        // 未定位到城市
        if(!data.cityCode) {
          this.pageType = 1
          this.pageShow = true
          wx.hideLoading()
          wx.stopPullDownRefresh()
          return
        }
        // 定位到城市后 请求首页数据
       this.initHomeData()
      })
    }
  },

  // 下拉刷新
  onPullDownRefresh (){
    this.initHomeData()
  },
  // 上拉加载
  onReachBottom(){
    if(this.noMore) return
    this.goodProductPage ++
    this.getGoodProductData()
  },
  // 分享
  onShareAppMessage(res){
    const communityId = this.communityInfo.communityId
    return {
      path: '/pages/index/main?communityId=' + communityId
    }
  },
  onLoad(option){
    console.log(option)
    // 目前点击底部tab不请求数据
    if(option.refreshType && option.refreshType === "noRefresh"){
      return
    }
    // Object.assign(this.$data, this.$options.data())
    this.isLoad = true
     wx.showLoading({
      title: "加载中"
    })
    this.getLocation()
  },
  onShow () {
    if(this.isLoad || !this.sChooseArea) return
    this.setChooseAreaAction(false)
    wx.showLoading({
      title: "加载中"
    })
    this.initHomeData()
  },
  onHide(){
    this.isLoad = false
  }
}
</script>

<style scoped lang="scss">
page{
  background-color: #fff;
}
.isIphoneX{
  padding-bottom: 84px !important;
}
.container{
  height: auto;
  min-height: 100%;
  padding-bottom: 50px;
  // 定位小区
  .location{
    height: 40px;
    line-height: 40px;
    text-align: center;
    .location-icon{
      width: 15px;
      height: 15px;
      vertical-align: middle;
      margin-right: 7px;
    }
    .location-text{
      position: relative;
      display: inline-block;
      vertical-align: middle;
      max-width: 166px;
      font-size: 17px;
      color: $blackBase;
      padding-right: 12px;
      &::before{
        position: absolute;
        top: 50%;
        right: -4px;
        transform: translateY(-50%);
        content: "";
        border-style: solid;
        border-width: 6px;
        border-color: transparent transparent transparent $darkBlackBase;
        width: 0px;
        height: 0px;
      }
    }
  }
  // 轮播图
  swiper{
    height: 120px;
    padding: 0 10px;
    .slide-image{
      width: 100%;
      height: 100%;
    }
  }
  // 限时特卖
  .product-list{
    .activity-title{
      width: 100%;
      height: auto;
    }

    .countdown{
      font-size: 14px;
      text-align: center;
      padding: 0;
      height: 53px;
      line-height: 53px;
      color: #000;
    }
  }
  // 空白页面 样式
  .slot-msg{
    .location-btn{
      margin: 16px auto;
      width: 200px;
      height: 44px;
      border-radius: 22px;
      background-color: $orangeBase;
      color: $darkBlackBase;
      line-height: 44px;
    }
    .jump{
      color: $hyperlink;
      display: inline;
    }
  }
}
</style>
