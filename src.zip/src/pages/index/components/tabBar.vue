<template>
  <div class="tabbar">
    <div class="tabbar-item"  
      :class="{active: index === tabbarIndex}" 
      v-for="(item, index) in list" 
      :key="index"
      @click="$emit('switchHandle',index)">{{item}}</div>
  </div>
</template>

<script>
export default {
  props: ["list","tabbarIndex"]
}
</script>

<style lang="scss" scoped>
.tabbar{
  display: flex;
  width: 246px;
  height: 32px;
  margin: 0 auto;
  border-radius: 54px;
  background-color: #eee;

  .tabbar-item{
    width: 82px;
    height: 100%;
    border-radius: 54px;
    text-align: center;
    line-height: 32px;
    font-size: 13px;
  }
  .active{
    background-color: $orangeBase;
    font-weight: bold;
    z-index: 5;
  }
}
</style>

