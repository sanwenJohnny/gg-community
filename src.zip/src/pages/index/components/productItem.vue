<template>
  <div class="product line" @click="clickHanle">
    <div class="product-content">
      <div class="product-img">
        <img :src="item.image" mode="aspectFill">
        <img class="logoImg" :src="item.logoImage" mode="aspectFill">
        <div class="sell" v-if="item.saleAmount > 0">已售{{item.saleAmount}}件</div>
      </div>
      <div class="product-info">
        <p class="product-name ellipsis">{{item.name}}</p>
        <p class="product-desc ellipsis">{{item.desc}}</p>
        <div class="product-price">
          <div class="price">
            <p class="price-type">{{isMember?"会员":""}}团购价</p>
            <div class="price-group">
              <span class="current-price">¥{{item.lowPrice}}</span>
              <span class="origin-price">￥{{item.highPrice}}</span>
            </div>
          </div>
          <div class="btn" v-if="item.status === 1">立即抢购</div>
          <div class="btn pre" v-else-if="item.status === 2">即将开抢</div>
          <div class="over" v-else-if="item.status === 3">已抢完</div>
        </div>
      </div>
    </div>
    <div class="product-generalize" v-if="item.recentBuy && item.recentBuy.length > 0">
      <ul class="generalize-list">
        <li class="item" v-for="(ite, ide) in item.recentBuy" :key="ide">
          <img class="people-logo" :src="ite.image">
          <span class="people-name ellipsis">{{ite.name}}</span>
        </li>
      </ul>
      <span class="tip">等刚刚购买了此商品</span>
    </div>
  </div>
</template>
<script>
export default {
  props: ["item","isMember"],
  methods: {
    clickHanle(){
      this.$emit("clickHanle")
    }
  }
}
</script>

<style lang="scss" scoped>
.product{
  padding: 0 6px;
  .product-content{
    padding-top: 12px;
    padding-left: 126px;
    padding-bottom: 12px;
    position: relative;
    height: 120px;
    .product-img{
      position: absolute;
      top: 12px;
      left: 0;
      width: 120px;
      height: 120px;
      // background-color: #ccc;
      img{
        width: 100%;
        height: 100%;
      }
      .logoImg{
        position: absolute;
        top: 0;
        left: 0;
        width: 42px;
        height: 46px;
      }
      .sell{
        position: absolute;
        bottom: 0;
        left: 0;
        background-color: rgba($color: #000000, $alpha: .25);
        color: #fff;
        height: 17px;
        font-size: 12px;
        line-height: 17px;
        padding: 0 3px;
        // &::before{
        //   content: "";
        //   position: absolute;
        //   top: 0;
        //   right: -8px;
        //   width:0;
        //   height:0;
        //   border-width:0 0 17px 8px;
        //   border-style:solid;
        //   border-color:transparent transparent transparent rgba($color: #000000, $alpha: .25);
        // }
      }
    }
    .product-info{
      position: relative;
      width: 100%;
      height: 100%;
      .product-name{
        padding-top: 4px;
        width: 100%;
        font-size: 15px;
        color: $blackBase;
        line-height: 18px;
        font-weight: bold;
      }
      .product-desc{
        width: 100%;
        padding-top: 4px;
        font-size: 15px;
        line-height: 18px;
        color: $lightBlackBase;
      }
    }
    .product-price{
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      display: flex;
      .price{
        flex: 1;
        .price-type{
          color: $darkOrangeBase;
          font-size: 12px;
          line-height: 17px;
          margin-bottom: -2px;
        }
        .price-group{
          .current-price{
            display: inline-block;
            color: $darkOrangeBase;
            font-size: 19px;
            line-height: 20px;
            margin-right: 3px;
            font-weight: bold;
          }
          .origin-price{
            text-decoration: line-through;
            font-size: 13px;
            color: $moreLightBlackBase;
          }
        }
      }
      .btn{
        width: 80px;
        height: 30px;
        line-height: 30px;
        border-radius: 32px;
        text-align: center;
        color: #fff;
        font-size: 12px;
        margin-top: 10px;
        background-color: $darkOrangeBase;
      }
      .pre{
        background-color: $orangeBase;
        color: #333;
      }
      .over{
        width: 80px;
        height: 30px;
        line-height: 30px;
        border-radius: 32px;
        text-align: center;
        color: #fff;
        font-size: 12px;
        margin-top: 10px;
        background-color: #c0c0c0;
      }
    }
  }
  .product-generalize{
    padding: 15px 0 10px;
    display: flex;
    align-items: center;
    // justify-content: center;
    color: $lightBlackBase;
    background-color: #F9FFEA;
    font-size: 12px;
    .generalize-list{
      .item{
        display: inline-block;
        .people-logo{
          width: 22px;
          height: 22px;
          border-radius: 50%;
          background-color: #ccc;
          vertical-align: middle;
        }
        .people-name{
          margin-left: 3px;
          vertical-align: middle;
          display: inline-block;
          width: 40px;
        }
      }
    }
  }
}
</style>
