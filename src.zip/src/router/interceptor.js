import {loginHandle} from '../utils/sessionAuth'

export default {
  name:'interceptor',
  authList:{
    '/pages/shoppingCart/main':'/pages/shoppingCart/main',
    '/pages/mine/center/main':'/pages/mine/center/main'
  },
  auth(opts) {
    return new Promise((resolve,reject) => {
      if(this.authList[opts.url]){
        const _url = opts.url
        loginHandle(_url).then(status => {
          if(status === 1) {
            //登录成功
            resolve()
          }
        })
      }else{
        resolve()
      }
    })
  },

  use(opts) {

  }
}
