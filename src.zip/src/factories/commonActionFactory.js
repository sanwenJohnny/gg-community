import types from 'sm/types'
const createRequest = require('f/requestActionFactory').default

const commonActionFactory = api => {
    return {
        getPageDataAction: createRequest(api, 'data'),
        setPageDataAction(context, data) {
            context.commit(types.SET_PAGE_DATA, data)
            return context.state.pageData
        },
        resetPageDataAction(context, opt = {}) {
            return context.dispatch('getPageDataAction', opt).then(res => {
                context.commit(types.SET_PAGE_DATA, res)
                return context.state.pageData
            })
        },
        setInitedAction(context, inited) {
            context.commit(types.SET_INITED, inited)
            return inited
        },
    }
}

export default commonActionFactory