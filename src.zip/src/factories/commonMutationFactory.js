import types from 'sm/types'
const commonMutationFactory = api => {
    return {
        [types.SET_PAGE_DATA](state, data = {}) {
            state.pageData = data
        },
        [types.SET_PARAMS](state, payload = {}) {
            const { path, params, replaceOldParam } = payload
            if (replaceOldParam) {
                state.params[api[path]] = params
            } else {
                Object.assign(state.params[api[path]], params)
            }
        },
        [types.SET_INITED](state, inited) {
            state.inited = inited
        },
    }
}

export default commonMutationFactory