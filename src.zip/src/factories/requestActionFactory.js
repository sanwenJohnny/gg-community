import request from "r"
import types from 'sm/types'

const requestActionFactory = (api, path) => {
    const fn = (context, opts = {}) => {
        const { params, showLoading, replaceOldParam } = opts
        context.commit(types.SET_PARAMS, {
            path,
            params,
            replaceOldParam
        })
        return request.post({
            url: api[path],
            data: context.state.params[api[path]],
            showLoading
        })
    }
    return fn
}

export default requestActionFactory