import _store from '../store'
/**
 * 路由
 */
class router {
  //跳转
  static push (opts) {
    const { url } = opts

    // _store.state.$$route
    wx.navigateTo({
      url
    })
  }

  //返回上一页
  static back (opts) {
    wx.navigateBack(opts)
  }

  //替换重定向
  static replace (opts) {
    const { url } = opts
    wx.redirectTo({
      url
    })
  }

  //跳转
  static reLaunch (opts) {
    const { url } = opts
    wx.reLaunch({
      url
    })
  }

}

export default router
