import user from '@/service/user'
import {
  TOKEN,BINDMOBILE
} from '@/utils/constants'
import {
  $
} from "@/utils"
import { vueRouter } from '../main'

export const checkLoginStatus = (url) => {
  const token = wx.getStorageSync(TOKEN)
  const needBindMobile = wx.getStorageSync(BINDMOBILE)

  return new Promise((resolve, reject) => {
    $(wx.checkSession)
      .then(() => { // session可用
        if (token && needBindMobile === 0) {
          resolve()
        } else {
          reject()
        }
      })
      .catch(() => { // 已过期，重新登录
        reject()
      })
  })
}

export const toLogin = (redirectUrl) => {
  const _redirect = redirectUrl ? `?redirectUrl=${redirectUrl}` : ''
  return new Promise((resolve,reject) => {
    $(wx.getSetting).then(res => {
      if (res.authSetting["scope.userInfo"]) {
        //已授权过直接登录
        $(wx.login).then(res => {
          $(wx.getUserInfo).then(info => {
            const data = {
              code: res.code,
              encryptedData: info.encryptedData,
              iv: info.iv
            }
            //获取登录token
            user.login(
              data,
              {
                showLoading: true
              }
            ).then(res => {
              wx.setStorageSync(TOKEN, res.token)
              if (res.needBindMobile === 1) {
                //跳转绑定手机号
                wx.setStorageSync(BINDMOBILE, 1)
                vueRouter.push({
                  url: `/pages/auth/bindMobile/main${_redirect}`
                })
              } else if (res.token) {
                //登录成功调用onSessionChecked
                wx.setStorageSync(BINDMOBILE, 0)
                resolve(1)
              }
            })
          })
        })

      } else { // 未授权跳授权页面
        vueRouter.push({
          url: `/pages/auth/login/main${_redirect}`
        })
      }
    })
  })
}

export const loginHandle = (url) => {
  return new Promise((resolve, reject) => {
    checkLoginStatus().then(() => {
      resolve(1)
    }).catch(() => { // 已过期，重新登录
      return toLogin(url)
    })
  })
}
