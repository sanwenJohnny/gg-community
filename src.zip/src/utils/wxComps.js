/**
 * 微信原生组件封装
 */
class WechatComponents {

  static toast (title, icon = 1) {
    wx.showToast({
      title,
      icon: ['success', 'none'][icon],
      duration: 2000
    })
  }

  static warn (content, title = '提示') {
    wx.showModal({
      title,
      content,
      showCancel:false,
      success: function (res) {

      }
    })
  }

  static confirm (content, title = '提示') {
    return new Promise((resolve,reject) => {
      wx.showModal({
        title,
        content,
        success: function (res) {
          if (res.confirm) {
            resolve(true)
          } else if (res.cancel) {
            resolve(false)
          }
        }
      })
    })
  }

  static showLoading ( title='' ) {
    wx.showLoading({
      title: '加载中'
    })
  }

  static hideLoading () {
    wx.hideLoading()
  }
}

export default WechatComponents
