const res = {}
let {pixelRatio} = wx.getSystemInfoSync()
pixelRatio = pixelRatio > 2 ? 3 : 2

const utils = {
  setRes: (pageId, imgKey, value) => {
    if (!res[pageId]) {
      res[pageId] = {}
    }
    res[pageId][imgKey] = value
  },
  getRes: (pageId, imgKey) => res[pageId] && res[pageId][imgKey]
}

export default utils

utils.setRes('empty', 'houseManage', `https://img.gegejia.com/life/miniprogram/local/emptyGoods1_${pixelRatio}x.png`)
utils.setRes('empty', 'order', `https://img.gegejia.com/life/miniprogram/local/emptyOrder_${pixelRatio}x.png`)
utils.setRes('empty', 'cart', `https://img.gegejia.com/life/miniprogram/local/emptyCart_${pixelRatio}x.png`)
utils.setRes('empty', 'community', `https://img.gegejia.com/life/miniprogram/local/emptyCommunity_${pixelRatio}x.png`)
utils.setRes('empty', 'location', `https://img.gegejia.com/life/miniprogram/local/emptyLocation_${pixelRatio}x.png`)
utils.setRes('empty', 'locationFail', `https://img.gegejia.com/life/miniprogram/local/emptyLocationFail_${pixelRatio}x.png`)

utils.setRes('common', 'homeUnsel', `https://img.gegejia.com/life/miniprogram/local/homeUnsel_${pixelRatio}x.png`)
utils.setRes('common', 'homeSel', `https://img.gegejia.com/life/miniprogram/local/homeSel_${pixelRatio}x.png`)
utils.setRes('common', 'cartSel', `https://img.gegejia.com/life/miniprogram/local/cartSel_${pixelRatio}x.png`)
utils.setRes('common', 'cartUnsel', `https://img.gegejia.com/life/miniprogram/local/cartUnsel_${pixelRatio}x.png`)
utils.setRes('common', 'mineUnsel', `https://img.gegejia.com/life/miniprogram/local/mineUnsel_${pixelRatio}x.png`)
utils.setRes('common', 'mineSel', `https://img.gegejia.com/life/miniprogram/local/mineSel_${pixelRatio}x.png`)

utils.setRes('mine', 'mydelivery', `https://img.gegejia.com/life/miniprogram/local/mydelivery_${pixelRatio}x.png`)
utils.setRes('mine', 'myrefund', `https://img.gegejia.com/life/miniprogram/local/myrefund_${pixelRatio}x.png`)
utils.setRes('mine', 'mytrade', `https://img.gegejia.com/life/miniprogram/local/mytrade_${pixelRatio}x.png`)
utils.setRes('mine', 'mywaitpay', `https://img.gegejia.com/life/miniprogram/local/mywaitpay_${pixelRatio}x.png`)
utils.setRes('mine', 'mywaitsend', `https://img.gegejia.com/life/miniprogram/local/mywaitsend_${pixelRatio}x.png`)

utils.setRes('index', 'location', `https://img.gegejia.com/life/miniprogram/local/location1_${pixelRatio}x.png`)
utils.setRes('index', 'group', `https://img.gegejia.com/life/miniprogram/local/group1_${pixelRatio}x.png`)
utils.setRes('index', 'choiceness', `https://img.gegejia.com/life/miniprogram/local/choiceness1_${pixelRatio}x.png`)

utils.setRes('detail', 'fire', `https://img.gegejia.com/life/miniprogram/local/fire_${pixelRatio}x.png`)
utils.setRes('detail', 'vipPrice', `https://img.gegejia.com/life/miniprogram/local/vipPrice1_${pixelRatio}x.png`)
utils.setRes('detail', 'groupPrice', `https://img.gegejia.com/life/miniprogram/local/groupPrice2_${pixelRatio}x.png`)
utils.setRes('detail', 'share', `https://img.gegejia.com/life/miniprogram/local/share_${pixelRatio}x.png`)
utils.setRes('detail', 'inventory', `https://img.gegejia.com/life/miniprogram/local/inventory1_${pixelRatio}x.png`)
utils.setRes('detail', 'generalize', `https://img.gegejia.com/life/miniprogram/local/generalize1_${pixelRatio}x.png`)
utils.setRes('detail', 'cart', `https://img.gegejia.com/life/miniprogram/local/cart1_${pixelRatio}x.png`)
utils.setRes('detail', 'contact', `https://img.gegejia.com/life/miniprogram/local/contact1_${pixelRatio}x.png`)
utils.setRes('detail', 'home', `https://img.gegejia.com/life/miniprogram/local/home1_${pixelRatio}x.png`)

utils.setRes('chooseArea', 'arrow', `https://img.gegejia.com/life/miniprogram/local/arrow_${pixelRatio}x.png`)
utils.setRes('chooseArea', 'open', `https://img.gegejia.com/life/miniprogram/local/open_${pixelRatio}x.png`)
utils.setRes('chooseArea', 'search', `https://img.gegejia.com/life/miniprogram/local/search_${pixelRatio}x.png`)

utils.setRes('search', 'clear', `https://img.gegejia.com/life/miniprogram/local/clear_${pixelRatio}x.png`)

utils.setRes('shoppingCart', 'delete', `https://img.gegejia.com/life/miniprogram/local/delete_${pixelRatio}x.png`)
utils.setRes('shoppingCart', 'choose', `https://img.gegejia.com/life/miniprogram/local/choose1_${pixelRatio}x.png`)

utils.setRes('orderSubmit', 'local', `https://img.gegejia.com/life/miniprogram/local/local_${pixelRatio}x.png`)
utils.setRes('orderSubmit', 'r_arrow', `https://img.gegejia.com/life/miniprogram/local/r_arrow_${pixelRatio}x.png`)

utils.setRes('orderDetail', 'waitPay', `https://img.gegejia.com/life/miniprogram/local/waitPay1_${pixelRatio}x.png`)
utils.setRes('orderDetail', 'waitSend', `https://img.gegejia.com/life/miniprogram/local/waitSend1_${pixelRatio}x.png`)
utils.setRes('orderDetail', 'waitReceive', `https://img.gegejia.com/life/miniprogram/local/waitReceive2_${pixelRatio}x.png`)
utils.setRes('orderDetail', 'deal', `https://img.gegejia.com/life/miniprogram/local/deal1_${pixelRatio}x.png`)
utils.setRes('orderDetail', 'timeout', `https://img.gegejia.com/life/miniprogram/local/timeout1_${pixelRatio}x.png`)
utils.setRes('orderDetail', 'lightPhone', `https://img.gegejia.com/life/miniprogram/local/lightPhone1_${pixelRatio}x.png`)
utils.setRes('orderDetail', 'lightLocal', `https://img.gegejia.com/life/miniprogram/local/lightLocal1_${pixelRatio}x.png`)
utils.setRes('orderDetail', 'lightThump', `https://img.gegejia.com/life/miniprogram/local/lightThump1_${pixelRatio}x.png`)
utils.setRes('orderDetail', 'stripe', `https://img.gegejia.com/life/miniprogram/local/stripe_${pixelRatio}x.png`)
utils.setRes('orderDetail', 'refund', `https://img.gegejia.com/life/miniprogram/local/refund_${pixelRatio}x.png`)

utils.setRes('houseManage', 'transOrder', `https://img.gegejia.com/life/miniprogram/local/transOrder2_${pixelRatio}x.png`)
utils.setRes('houseManage', 'jumpArrow', `https://img.gegejia.com/life/miniprogram/local/jumpArrow2_${pixelRatio}x.png`)
utils.setRes('houseManage', 'afterSales', `https://img.gegejia.com/life/miniprogram/local/afterSales1_${pixelRatio}x.png`)
