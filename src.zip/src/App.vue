<script>
import utils from "u"
import { $ } from "u"
export default {
  created() {
    // utils.set('token','eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxMjc1MDY1ODUxIiwiZXhwIjoxNTMzMjY5NDk1fQ.cFsau0MuLh3m5oKyMPqs7JU-egVBza8c9Dk8BA0BqlHSV5OT_H689UbY3JyrUw_74DWa9KxmYLdejGV2y68-9Q')
    // test utils.set('token','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjg3NDA1NjMwIiwiZXhwIjoxNTM0MjI2OTEzfQ.O_kb899ZBDhzlh65XbdZSVc9fXuc6mGs2qe6fXGQVD0')

    // 调用API从本地缓存中获取数据
    const logs = wx.getStorageSync("logs") || []
    logs.unshift(Date.now())
    wx.setStorageSync("logs", logs)
  }
}
</script>

<style lang="scss">
@import "./css/common";
</style>
