<template>
  <div class="i_t">
    <!-- icon -->
    <div class="icon" :style="{marginRight: space || '7px', width:iconWidth || '16px'}">
        <img mode="widthFix" :src="iconSrc">
    </div>
    <!-- 文字 -->
    <div v-if="text" class="text f_title" :style="{fontSize: fontSize || '16px',color: fontColor || '#333', height: fontSize || '16px'}">{{text}}</div>
  </div>
</template>

<script>
export default {
  name: "iconText",
  props: ["iconSrc", "iconWidth", "fontSize", "fontColor", "text", "space"],
  data() {
    return {};
  }
};
</script>

<style scoped lang="scss">
.i_t {
  display: flex;
  align-items: center;
  height: 100%;
  // icon
  .icon {
    width: 16px;
    height: 100%;
    display: flex;
    align-items: center;
    img {
      width: 100%;
    }
  }
}
</style>
