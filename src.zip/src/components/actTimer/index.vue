<template>
  <div class="countDown">
    <span>{{time.h}}</span>时<span>{{time.m}}</span>分<span>{{time.s}}</span>秒
  </div>
</template>
<script>

export default {
  name: "actCountDown",
  props: ['timestamp'],
  data() {
    return {
      timer: null,
      time: {}
    }
  },
  watch:{
    // 父组件时间戳变更后刷新子组件状态
    timestamp (newV , olbV) {
      clearTimeout(this.timer)
      this.timerHandle(newV)
    }
  },
  mounted() {
    clearTimeout(this.timer)
    this.timerHandle(this.timestamp)
  },
  onUnload(){
    clearTimeout(this.timer)
  },
  methods: {
    // 定时器处理
    timerHandle (time){
      if (time < 0){
        this.$emit("timerOver")
        return
      } 
      this.time = this.countTime(time)
      this.timer = setTimeout(()=>{
        time --
        this.timerHandle(time)
      },1000)
    },
    // 倒计时
    countTime(timestamp) {
      const d = singleTodouble(Math.floor(timestamp/60/60/24)); 
      const h = singleTodouble(Math.floor(timestamp/60/60%24));
      const m = singleTodouble(Math.floor(timestamp/60%60));
      const s = singleTodouble(Math.floor(timestamp%60));
      function singleTodouble(num){
        if(num < 10){
          return `0${num}`
        }else{
          return num
        }
      }
      // console.log(`${d}:${h}:${m}:${s}`)
      return { d,h,m,s }
    },
  }
}
</script>

<style scoped lang="scss">
.countDown{
  display: inline-block;
  font-size: 14px;
  text-align: center;
  // padding: 15px 0;
  span{
    display: inline-block;
    margin-right: 3px;
    width: 20px;
    height: 18px;
    text-align: center;
    line-height: 18px;
    color: #fff;
    background-color: $blackBase;
    border-radius: 4px;
    font-size: 12px;
    transform: translateY(-1px)
  }
}
</style>
