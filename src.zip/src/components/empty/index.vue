<template>
  <div class="empty-view">
    <div class="logo" :style="{backgroundImage: 'url('+ image + ')',marginTop: topHeight+'px'}" v-if="image">
    </div>
    <div class="msg" v-if="!message">
      <slot></slot>
    </div>
    <div class="msg" v-else>
      <span>{{message}}</span>
    </div>
  </div>
</template>

<script>
export default {
  name: "empty",
  props:{
    image:{
      type:String,
      default:''
    },
    message:{
      type:String,
      default:''
    },
    topHeight:{
      type:String,
      default:'114'
    }
  },
  data() {
    return {
    }
  },
  methods: {
  },
};
</script>

<style scoped lang="scss">
.empty-view{
  width: 100%;
  overflow: hidden;
  text-align: center;
  .logo{
    width: 130px;
    height: 130px;
    margin-left: auto;
    margin-right: auto;
    background-image: image();
    background-repeat: no-repeat;
    background-size: 100%;
  }
  .msg{
    width: 100%;
    margin-top: 20px;
    font-size: 14px;
    color: $darkBlackBase;
    text-align: center;
  }
}
</style>
