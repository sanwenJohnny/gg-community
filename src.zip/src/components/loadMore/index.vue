<template>
    <div class="loading-circles">
        <i class="icon"></i>
        <span>加载中...</span>
    </div>
</template>

<script>
export default {
  name: "load-more",
  data() {
    return {
    }
  },
  methods: {
  }
};
</script>

<style scoped lang="scss">
.loading-circles {
  display: flex;
  align-items: center;
  justify-content:center;
  width: 100%;
  height: 36px;
  color: $moreLightBlackBase;
  font-size: 12px;
  .icon{
    width: 15px;
    height: 15px;
    background-image: url('./loading.png');
    background-repeat: no-repeat;
    background-size: 100%;
    margin-right: 5px;
    animation:rotation 1s infinite linear ;
  }
}
@-webkit-keyframes rotation {
	from { -webkit-transform: rotate(0deg); }
	to { -webkit-transform: rotate(360deg); }
}

@keyframes rotation {
	from { transform: rotate(0deg); }
	to { transform: rotate(360deg); }
}
</style>
