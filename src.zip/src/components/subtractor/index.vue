<template>
  <div class="b_all counter" data-role="subtractor">
    <!-- 减 -->
    <div class="b_right minus" @click="minus" data-role="minus">-</div>
    <!-- 数量 -->
    <div class="f_title count">{{count}}</div>
    <!-- 加 -->
    <div class="b_left add" @click="add" data-role="add">+</div>
  </div>
</template>

<script>
export default {
  name: 'subtractor',
  props: ['count', 'max', 'id'],
  data() {
    return {}
  },
  methods: {
    minus() {
      if (this.count - 1 < 1) {
        this.$emit('crossMin', this.id)
        return
      }
      this.$emit('updateCount', this.count - 1, this.id)
    },
    add() {
      if (this.count + 1 > this.max) {
        this.$emit('crossMax', this.id)
        return
      }
      this.$emit('updateCount', this.count + 1, this.id)
    }
  }
}
</script>

<style scoped lang="scss">
.counter {
  display: flex;
  align-items: flex-end;
  width: 85px;
  height: 24px;
  .minus,
  .add {
    width: 26px;
    height: 24px;
    line-height: 24px;
    text-align: center;
    font-size: 20px;
    z-index: 99;
  }
  .minus {
    font-size: 20px;
  }
  .count {
    width: 33px;
    height: 24px;
    line-height: 24px;
    text-align: center;
  }
}
</style>
