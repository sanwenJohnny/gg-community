<template>
<div class="">
  <div class="tab-view" :class="computedClass" :style="{position: pos}">
    <div class="item" @tap="switchTab(1)">
      <img :src="homeImg" alt="">
      <p :class="{'selected': currentPage===1}">精选</p>
    </div>
    <div class="item pos-rela" @tap="switchTab(2)">
      <img :src="cartImg" alt="">
      <p :class="{'selected': currentPage===2}">购物车</p>
      <span class="number-pointer" v-if="sCartNumber > 0">{{sCartNumber}}</span>
    </div>
    <div class="item" @tap="switchTab(3)">
      <img :src="mineImg" alt="">
      <p :class="{'selected': currentPage===3}">我的</p>
    </div>
  </div>
</div>
</template>

<script>
import {
  mapState,
  mapActions
} from 'vuex'
import imgApi from '@/utils/imgApi'
import tools from '@/utils'
import {
  checkLoginStatus
} from '@/utils/sessionAuth'
export default {
  name: "tab",
  props: {
    currentPage: {
      type: Number,
      default: 1
    },
    pos: {
      type: String,
      default: 'fixed'
    }
  },
  data() {
    return {
      cartNumber: 0,
      homeSelImg: imgApi.getRes('common', 'homeSel'),
      homeUnselImg: imgApi.getRes('common', 'homeUnsel'),
      cartSelImg: imgApi.getRes('common', 'cartSel'),
      cartUnselImg: imgApi.getRes('common', 'cartUnsel'),
      mineSelImg: imgApi.getRes('common', 'mineSel'),
      mineUnselImg: imgApi.getRes('common', 'mineUnsel'),
    }
  },
  computed: {
    ...mapState(['sCartNumber']),
    computedClass() {
      return tools.isIphoneX() ? 'iphonex' : ''
    },
    homeImg() {
      return this.currentPage === 1 ? this.homeSelImg : this.homeUnselImg
    },
    cartImg() {
      return this.currentPage === 2 ? this.cartSelImg : this.cartUnselImg
    },
    mineImg() {
      return this.currentPage === 3 ? this.mineSelImg : this.mineUnselImg
    }
  },
  watch: {
    'currentPage' (newV, oldV) {}
  },
  mounted() {
    this.getCartCount()
  },
  onShow() {
    this.getCartCount()
  },
  methods: {
    ...mapActions('modProduct', ['getCartCountAction']),
    ...mapActions(['setCartNumberAction']),
    getCartCount() {
      checkLoginStatus().then(() => {
        const communityInfo = wx.getStorageSync("communityInfo") || {}
        const data = {
          cityCode: communityInfo.cityCode
        }
        this.getCartCountAction({
          data
        }).then(res => {
          this.setCartNumberAction(res)
        })
      }).catch(() => {
        this.setCartNumberAction(0)
      })
    },
    updateNumber() {
      this.getCartCount()
    },
    switchTab(page) {
      if (page === this.currentPage) return
      switch (page) {
        case 1:
          this.$router.reLaunch({
            url: '/pages/index/main?refreshType=noRefresh'
          })
          break;
        case 2:
          this.$router.reLaunch({
            url: '/pages/shoppingCart/main'
          })
          break;
        case 3:
          this.$router.reLaunch({
            url: '/pages/mine/center/main'
          })
          break;
        default:

      }
    }
  }
};
</script>

<style scoped lang="scss">
.tab-view {
    position: fixed;
    bottom: 0;
    display: flex;
    align-items: center;
    width: 100%;
    height: 49px;
    background-color: $whiteBase;
    z-index: 9999999;
    .item {
        width: 33%;
        height: 100%;
        flex-grow: 1;
        text-align: center;
        p {
            font-size: 10px;
            color: #c0c0c0;
            &.selected {
                color: $darkBlackBase;
            }
        }
    }
}
img {
    display: block;
    width: 30px;
    height: 26px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 5px;
}
.pos-rela {
    position: relative;
}
.number-pointer {
    position: absolute;
    top: 2px;
    left: 69px;
    display: inline-block;
    min-width: 14px;
    height: 14px;
    line-height: 14px;
    background-color: #ff0000;
    color: $whiteBase;
    font-size: 9px;
    border-radius: 50%;
    text-align: center;
}
</style>
