<template>
  <span :style="{color, fontWeight}">{{time}}</span>
</template>

<script>
import utils from 'u'
export default {
  name: 'countDown',
  props: ['restTime', 'id'],
  props: {
    restTime: [String, Number],
    id: [String, Number],
    color: {
      type: String,
      default: '#000'
    },
    fontWeight: {
      type: String,
      default: 'normal'
    }
  },
  data() {
    return {
      time: ''
    }
  },
  mounted() {
    let timer = setInterval(() => {
      this.restTime -= 1000
      if (this.restTime >= 0) {
        this.time = utils.formatTime(this.restTime, 'mm:ss')
      } else {
        clearInterval(timer)
        this.$emit('countEnd', this.id)
      }
    }, 1000)
  }
}
</script>

<style scoped lang="scss">
</style>
