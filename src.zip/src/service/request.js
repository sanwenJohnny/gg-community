import wxComps from '../utils/wxComps'
import { TOKEN } from '@/utils/constants'
import config from '@/config'
import apiContext from '@/static/apiContext'
/**
 * 网络请求封装
 */
const token = wx.getStorageSync(TOKEN)
const API_PATH = apiContext[config.env]
class Request {

  static get({
    url,
    data = {},
    header = {},
    showLoading = false
  }) {
    const method = 'GET'
    return http({
      url,
      data,
      method,
      header,
      showLoading
    })
  }

  static post({
    url,
    data = {},
    header = {},
    showLoading = false
  }) {
    const method = 'POST'
    return http({
      url,
      data,
      method,
      header,
      showLoading
    })
  }

}

//网络请求
function http({
  url,
  data,
  method,
  header,
  showLoading
}) {
  const token = wx.getStorageSync(TOKEN)

  return checkNetWork().then(netWorkStatus => {

    if (!netWorkStatus) {
      wxComps.toast('网络异常')
      return false
    }
    let _header = header
    if (token) {
      _header = Object.assign({
        token: token
      }, header)
    }
    showLoading && wx.showLoading({
      title: '加载中...'
    })
    return new Promise((resolve, reject) => {

      wx.request({
        url: `${API_PATH}${url}`,
        header: _header,
        method,
        data,
        dataType: 'json',
        success: (res) => {
          showLoading && wx.hideLoading()
          res = res.data
          if (res.errorCode === 0) {
            resolve(res.data)
          } else {
            errorHandle(res.errorCode, res.errorMessage)
            reject(res.data)
          }
        },
        fail: res => {
          showLoading && wx.hideLoading()
          if(res) {
            errorHandle(null, res.errMsg)
            reject(res)
          }
        },
        complete: res => {
          // console.log('request url:', `${API_PATH}${url}`)
          // console.log('request data:', res)
        }
      })
    })
  })
}

function checkNetWork() {
  return new Promise(resolve => {
    wx.getNetworkType({
      success: res => {
        let networkType = res.networkType
        if (networkType === 'none' || networkType === 'unknown') {
          resolve(false)
        } else {
          resolve(true)
        }
      },
      fail: () => {
        resolve(false)
      }
    })
  })
}
/**
 * 异常处理
 * @param  {Object} [error={errorCode] [description]
 * @param  {[type]} message            [description]
 * @return {[type]}                    [description]
 */
function errorHandle(errorCode, errorMessage) {
  switch (errorCode) {
    case 502:
      wxComps.toast('服务器异常')
      break
    default:
      errorMessage && wxComps.toast(errorMessage)
      break
  }
}

export default Request
