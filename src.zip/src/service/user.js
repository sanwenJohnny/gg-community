import { $ } from "@/utils"
import request from './request'
import { TOKEN } from '@/utils/constants'

export default {
  /**
   * 登录
   * @param {Boolean}} showLoading
   */
  login (data, showLoading) {
    return request.post({ url: '/account/login', data, showLoading })
  }
}
