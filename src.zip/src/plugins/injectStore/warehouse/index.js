function rootStateFilter(state, modules) {
    let rootState = {}
    for (let key in state) {
        if (!modules[key]) {
            rootState[key] = state[key]
        }
    }
    return rootState
}

class Warehouse {
    constructor() {
        this.root = null
        this.modules = null
        this.rootActions = null
        this.rootState = null
        this.mixinsCache = {}
    }

    init(store) {
        this.root = store._modules.root
        this.modules = this.root._children
        this.rootActions = this.root._rawModule.actions
        this.rootState = rootStateFilter(this.root._rawModule.state, this.modules)
    }

    addToCache(mod, mixin) {
        this.mixinsCache[mod] = mixin
    }
}

export default new Warehouse()