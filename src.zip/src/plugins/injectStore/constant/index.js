export default {
    ROOT_MOUDLE: '$root'
}