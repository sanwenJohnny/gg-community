import warehouse from './warehouse'
import inject from './inject'

function processApp(Vue) {
    Vue.prototype.orgInit = Vue.prototype._init
    Vue.prototype._init = function (opt) {
        inject(opt)
        this.orgInit(opt)
    }
}

function processComponent(Vue) {
    Vue.orgExtend = Vue.extend
    Vue.extend = function (opt) {
        inject(opt)
        return Vue.orgExtend(opt)
    }
}

function injectStore(Vue, store) {
    warehouse.init(store)
    processApp(Vue)
    processComponent(Vue)
}
export default injectStore