import warehouse from './warehouse'
import utils from './utils'
import constant from './constant'
import { mapState, mapActions } from 'vuex'

let _mixins = null //options.mixins
let _group = null //  mods will be cached

function resolveStringOption(mod) {

    if (mod) {

        let state = null, actions = null, stateMapList = [], actionMapList = []

        if (!warehouse.mixinsCache[mod]) { // caching res

            if (mod === constant.ROOT_MOUDLE) { // if root moudle

                state = warehouse.rootState
                actions = warehouse.rootActions

            } else if (warehouse.modules[mod]) { // ensure module exist

                state = warehouse.modules[mod].state
                actions = warehouse.modules[mod]._rawModule.actions
            }else {

                return
            }

            for (let key in state) {
                stateMapList.push(key)
            }

            for (let key in actions) {
                actionMapList.push(key)
            }

            warehouse.addToCache(mod, {
                computed: {
                    ...mapState(mod, stateMapList)
                },
                methods: {
                    ...mapActions(mod, actionMapList)
                }
            })
        }

        const mixin = warehouse.mixinsCache[mod]

        // If want to 主动 use caching, must pass { use: 'id' }
        _mixins.push(mixin)

        if (_group) {
            _group.push(mixin)
        }
    }
}

function resolveObjectOption(opt) {
    let mixin
    const use = opt.use
    const mod = opt.mod
    const mods = opt.mods
    const id = opt.id
    if (use) { // use cache
        mixin = warehouse.mixinsCache[use]
        if (mixin) {
            if (Array.isArray(mixin)) {
                for (let i = 0; i < mixin.length; i++) {
                    _mixins.push(mixin[i])
                }
            } else {
                _mixins.push(mixin)
            }
        }

    } else if (mod && warehouse.modules[mod] || mod === constant.ROOT_MOUDLE) { // { mod, state, actions, id } 

        const stateMapList = opt.state
        const actionMapList = opt.actions

        if (stateMapList && stateMapList.length || (actionMapList && actionMapList.length)) { // must has [state] or [actions] param, also length > 0

            mixin = {}

            if (Array.isArray(stateMapList)) {
                let stateMap
                if (mod === constant.ROOT_MOUDLE) {
                    stateMap = mapState(stateMapList)
                }else {
                    stateMap = mapState(mod, stateMapList)
                }
                mixin.computed = {
                    ...stateMap
                }
            }

            if (Array.isArray(actionMapList)) {
                let actionMap
                if (mod === constant.ROOT_MOUDLE) {
                    actionMap = mapActions(actionMapList)
                } else {
                    actionMap = mapActions(mod, actionMapList)
                }
                mixin.methods = {
                    ...actionMap
                }
            }

            _mixins.push(mixin)

            if (id) {
                warehouse.addToCache(id, mixin)
            }

            if (_group) {
                _group.push(mixin)
            }
        }
    } else if (mods) { // { mods: [ { mod, state, actions, id } ], id }

        if (id) {
            _group = []
        }

        resolveArrayOption(mods)

        if (id) {
            warehouse.addToCache(id, _group)
            _group = null
        }
    }
}

function resolveArrayOption(opt) {
    for (let i = 0; i < opt.length; i++) {
        resolveOption(opt[i])
    }
}

function resolveOption(opt) {
    if (typeof opt == 'string') {
        resolveStringOption(opt)
    } else if (utils.isPlainObject(opt)) {
        resolveObjectOption(opt)
    } else if (Array.isArray(opt)) {
        resolveArrayOption(opt)
    }
}

function inject(opt) {
    if (!opt.injected && opt.ivs) {
        if (!opt.mixins) {
            opt.mixins = []
        }
        _mixins = opt.mixins
        const _opt = opt.ivs
        resolveOption(_opt)
        opt.injected = true
    }
}

export default inject