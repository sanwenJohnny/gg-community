import Vue from 'vue'
import App from './App'
import '@/libs'
import store from './store'
import wxComps from './utils/wxComps'
import regExps from './utils/regExps'
import router from './router'
import utils from 'u'
import injectStore from '@/plugins/injectStore'


const systemInfo = wx.getSystemInfoSync()
store.state.sSystemInfo = systemInfo
Vue.prototype.$worker = wx.canIUse('createWorker') ? wx.createWorker('workers/index.js') : {}
Vue.prototype.$wxComps = wxComps
Vue.prototype.$regExps = regExps
Vue.prototype.$store = store
Vue.prototype.isx = utils.isIphoneX()
const vueRouter = new router('/pages/index/main')
Vue.prototype.$router = vueRouter
export { vueRouter }

injectStore(Vue, store)

const routeMap = new Map()

Vue.prototype.__mount = Vue.prototype.$mount
Vue.prototype.$mount = function(el, hydrating) {
  if(this.$root.$mp && this.$root.$mp.mpType === 'page') {

    const url = this.$root.$options.__file.replace('src','').replace('index.vue','main')+''
    this.$router.routerMap.set(url, {
      url,
      vm:this.$root
    })
  }
  this.__mount()
}

Vue.prototype.q = function () {
  return this.$root.$mp.query
}

Vue.config.productionTip = false
App.mpType = 'app'

const app = new Vue(App)
app.$mount()
export default {
  // 这个字段走 app.json
  config: {
    // 页面前带有 ^ 符号的，会被编译成首页，其他页面可以选填，我们会自动把 webpack entry 里面的入口页面加进去
    pages: ['^pages/index/main'],
    window: {
      backgroundTextStyle: 'light',
      navigationBarBackgroundColor: '#fff',
      navigationBarTitleText: 'WeChat',
      navigationBarTextStyle: 'black'
    },
    networkTimeout: {
      request: 10000
    },
    workers: "workers"
  }
}
